const fs = require('fs');

// 1. IOrganizationRepository
let repoIf = fs.readFileSync('server/domain/repositories/IOrganizationRepository.ts', 'utf8');
repoIf = repoIf.replace('findById(id: string): Promise<Organization | null>;', 'findAll(): Promise<Organization[]>;\n  findById(id: string): Promise<Organization | null>;');
fs.writeFileSync('server/domain/repositories/IOrganizationRepository.ts', repoIf);

// 2. InMemoryOrganizationRepository
let repoImpl = fs.readFileSync('server/infrastructure/database/OrganizationRepository.ts', 'utf8');
repoImpl = repoImpl.replace('async findById(id: string): Promise<Organization | null> {', 'async findAll(): Promise<Organization[]> {\n    return Array.from(this.organizations.values());\n  }\n\n  async findById(id: string): Promise<Organization | null> {');
fs.writeFileSync('server/infrastructure/database/OrganizationRepository.ts', repoImpl);

// 3. OrganizationService
let svc = fs.readFileSync('server/application/services/OrganizationService.ts', 'utf8');
svc = svc.replace('async getOrganizationById(id: string) {', 'async getAllOrganizations() {\n    return this.repository.findAll();\n  }\n\n  async getOrganizationById(id: string) {');
fs.writeFileSync('server/application/services/OrganizationService.ts', svc);

// 4. OrganizationController
let ctrl = fs.readFileSync('server/presentation/controllers/OrganizationController.ts', 'utf8');
ctrl = ctrl.replace('static async getById(req: Request, res: Response, next: NextFunction) {', 'static async getAll(req: Request, res: Response, next: NextFunction) {\n    try {\n      const orgs = await organizationService.getAllOrganizations();\n      return sendApiResponse({\n        res,\n        req,\n        message: "Organizations retrieved successfully",\n        data: orgs,\n      });\n    } catch (error) {\n      next(error);\n    }\n  }\n\n  static async getById(req: Request, res: Response, next: NextFunction) {');
fs.writeFileSync('server/presentation/controllers/OrganizationController.ts', ctrl);

// 5. organization.routes.ts
let routes = fs.readFileSync('server/presentation/routes/organization.routes.ts', 'utf8');
routes = routes.replace('router.get("/:id", OrganizationController.getById);', 'router.get("/", OrganizationController.getAll);\nrouter.get("/:id", OrganizationController.getById);');
fs.writeFileSync('server/presentation/routes/organization.routes.ts', routes);

console.log('Done');
