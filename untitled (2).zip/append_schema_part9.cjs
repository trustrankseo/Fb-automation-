const fs = require('fs');

const schemaAdditions = `

export const securityPolicies = pgTable("security_policies", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  policyName: varchar("policy_name", { length: 255 }).notNull(),
  policyCode: varchar("policy_code", { length: 100 }).notNull().unique(),
  policyCategory: varchar("policy_category", { length: 100 }),
  description: text("description"),
  policyDefinition: jsonb("policy_definition").default({}),
  enforcementMode: varchar("enforcement_mode", { length: 50 }),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('spol_org_idx').on(t.organizationId),
  index('spol_code_idx').on(t.policyCode)
]);

export const complianceFrameworks = pgTable("compliance_frameworks", {
  id: uuid("id").primaryKey(),
  frameworkName: varchar("framework_name", { length: 255 }).notNull(),
  frameworkCode: varchar("framework_code", { length: 100 }).notNull().unique(),
  frameworkVersion: varchar("framework_version", { length: 50 }),
  description: text("description"),
  requirements: jsonb("requirements").default({}),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('cfwk_code_idx').on(t.frameworkCode)
]);

export const organizationCompliance = pgTable("organization_compliance", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  frameworkId: uuid("framework_id").references(() => complianceFrameworks.id, { onDelete: 'cascade' }).notNull(),
  complianceStatus: varchar("compliance_status", { length: 50 }),
  lastAudit: timestamp("last_audit", { withTimezone: true }),
  nextAudit: timestamp("next_audit", { withTimezone: true }),
  score: integer("score"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ocomp_org_idx').on(t.organizationId),
  index('ocomp_fwk_idx').on(t.frameworkId)
]);

export const encryptionKeys = pgTable("encryption_keys", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  keyName: varchar("key_name", { length: 255 }).notNull(),
  keyType: varchar("key_type", { length: 100 }),
  keyProvider: varchar("key_provider", { length: 100 }),
  keyVersion: varchar("key_version", { length: 50 }),
  rotationIntervalDays: integer("rotation_interval_days"),
  lastRotatedAt: timestamp("last_rotated_at", { withTimezone: true }),
  nextRotationAt: timestamp("next_rotation_at", { withTimezone: true }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ekey_org_idx').on(t.organizationId),
  index('ekey_name_idx').on(t.keyName)
]);

export const backupJobs = pgTable("backup_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupType: varchar("backup_type", { length: 50 }),
  storageProvider: varchar("storage_provider", { length: 100 }),
  backupLocation: text("backup_location"),
  backupSize: integer("backup_size"),
  compressionEnabled: boolean("compression_enabled").default(false),
  encryptionEnabled: boolean("encryption_enabled").default(false),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  verificationStatus: varchar("verification_status", { length: 50 }),
  status: varchar("status", { length: 30 }).default('PENDING'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('bjob_org_idx').on(t.organizationId),
  index('bjob_type_idx').on(t.backupType),
  index('bjob_status_idx').on(t.status)
]);

export const backupArchives = pgTable("backup_archives", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupJobId: uuid("backup_job_id").references(() => backupJobs.id, { onDelete: 'cascade' }).notNull(),
  archiveName: varchar("archive_name", { length: 255 }).notNull(),
  archiveChecksum: varchar("archive_checksum", { length: 255 }),
  storageObjectId: varchar("storage_object_id", { length: 255 }),
  retentionUntil: timestamp("retention_until", { withTimezone: true }),
  verified: boolean("verified").default(false),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('barch_org_idx').on(t.organizationId),
  index('barch_job_idx').on(t.backupJobId)
]);

export const restoreJobs = pgTable("restore_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupArchiveId: uuid("backup_archive_id").references(() => backupArchives.id, { onDelete: 'cascade' }).notNull(),
  restoreType: varchar("restore_type", { length: 50 }),
  requestedBy: uuid("requested_by").references(() => users.id, { onDelete: 'set null' }),
  approvedBy: uuid("approved_by").references(() => users.id, { onDelete: 'set null' }),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  restoreStatus: varchar("restore_status", { length: 50 }),
  validationReport: jsonb("validation_report").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('rjob_org_idx').on(t.organizationId),
  index('rjob_status_idx').on(t.restoreStatus)
]);

export const ipAllowlists = pgTable("ip_allowlists", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  cidrBlock: varchar("cidr_block", { length: 50 }).notNull(),
  description: text("description"),
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ipa_org_idx').on(t.organizationId),
  index('ipa_cidr_idx').on(t.cidrBlock)
]);

export const securityIncidents = pgTable("security_incidents", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  incidentType: varchar("incident_type", { length: 100 }),
  severity: varchar("severity", { length: 50 }),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  detectedAt: timestamp("detected_at", { withTimezone: true }),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  assignedTo: uuid("assigned_to").references(() => users.id, { onDelete: 'set null' }),
  resolutionNotes: text("resolution_notes"),
  status: varchar("status", { length: 30 }).default('OPEN'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('sinc_org_idx').on(t.organizationId),
  index('sinc_sev_idx').on(t.severity),
  index('sinc_status_idx').on(t.status)
]);

export const dataRetentionPolicies = pgTable("data_retention_policies", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  resourceType: varchar("resource_type", { length: 100 }),
  retentionDays: integer("retention_days"),
  archiveAfterDays: integer("archive_after_days"),
  deleteAfterDays: integer("delete_after_days"),
  legalHold: boolean("legal_hold").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('drp_org_idx').on(t.organizationId),
  index('drp_res_idx').on(t.resourceType)
]);
`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 9 appended.');
