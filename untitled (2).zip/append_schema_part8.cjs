const fs = require('fs');

const schemaAdditions = `

export const plugins = pgTable("plugins", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  pluginName: varchar("plugin_name", { length: 255 }).notNull(),
  pluginSlug: varchar("plugin_slug", { length: 255 }).notNull().unique(),
  pluginVersion: varchar("plugin_version", { length: 50 }),
  pluginAuthor: varchar("plugin_author", { length: 255 }),
  pluginType: varchar("plugin_type", { length: 100 }),
  pluginCategory: varchar("plugin_category", { length: 100 }),
  minimumPlatformVersion: varchar("minimum_platform_version", { length: 50 }),
  maximumPlatformVersion: varchar("maximum_platform_version", { length: 50 }),
  installationPath: text("installation_path"),
  configuration: jsonb("configuration").default({}),
  permissions: jsonb("permissions").default({}),
  enabled: boolean("enabled").default(false),
  verified: boolean("verified").default(false),
  ...commonColumns
}, (t) => [
  index('plug_org_idx').on(t.organizationId),
  index('plug_slug_idx').on(t.pluginSlug),
  index('plug_status_idx').on(t.status)
]);

export const pluginVersions = pgTable("plugin_versions", {
  id: uuid("id").primaryKey(),
  pluginId: uuid("plugin_id").references(() => plugins.id, { onDelete: 'cascade' }).notNull(),
  version: varchar("version", { length: 50 }),
  releaseNotes: text("release_notes"),
  checksum: varchar("checksum", { length: 255 }),
  downloadUrl: text("download_url"),
  installedAt: timestamp("installed_at", { withTimezone: true }),
  installedBy: uuid("installed_by").references(() => users.id, { onDelete: 'set null' }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('pver_plug_idx').on(t.pluginId),
  index('pver_version_idx').on(t.version)
]);

export const pluginHooks = pgTable("plugin_hooks", {
  id: uuid("id").primaryKey(),
  pluginId: uuid("plugin_id").references(() => plugins.id, { onDelete: 'cascade' }).notNull(),
  hookName: varchar("hook_name", { length: 255 }),
  eventName: varchar("event_name", { length: 255 }),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('phook_plug_idx').on(t.pluginId),
  index('phook_name_idx').on(t.hookName)
]);

export const webhooks = pgTable("webhooks", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  targetUrl: text("target_url"),
  httpMethod: varchar("http_method", { length: 20 }),
  secret: varchar("secret", { length: 255 }),
  enabled: boolean("enabled").default(true),
  retryPolicy: varchar("retry_policy", { length: 100 }),
  timeoutSeconds: integer("timeout_seconds"),
  headers: jsonb("headers").default({}),
  events: jsonb("events").default({}),
  lastDelivery: timestamp("last_delivery", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('wh_org_idx').on(t.organizationId),
  index('wh_enabled_idx').on(t.enabled)
]);

export const webhookDeliveries = pgTable("webhook_deliveries", {
  id: uuid("id").primaryKey(),
  webhookId: uuid("webhook_id").references(() => webhooks.id, { onDelete: 'cascade' }).notNull(),
  eventName: varchar("event_name", { length: 255 }),
  requestBody: jsonb("request_body").default({}),
  responseCode: integer("response_code"),
  responseBody: text("response_body"),
  attemptCount: integer("attempt_count").default(0),
  deliveryTimeMs: integer("delivery_time_ms"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('whd_wh_idx').on(t.webhookId),
  index('whd_event_idx').on(t.eventName),
  index('whd_status_idx').on(t.status)
]);

export const apiClients = pgTable("api_clients", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  clientId: varchar("client_id", { length: 255 }).notNull().unique(),
  clientSecretHash: text("client_secret_hash"),
  redirectUri: text("redirect_uri"),
  allowedScopes: jsonb("allowed_scopes").default({}),
  allowedOrigins: jsonb("allowed_origins").default({}),
  rateLimit: integer("rate_limit"),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('apic_id_idx').on(t.clientId),
  index('apic_org_idx').on(t.organizationId)
]);

export const apiTokens = pgTable("api_tokens", {
  id: uuid("id").primaryKey(),
  clientId: varchar("client_id", { length: 255 }).notNull(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text("token_hash"),
  refreshTokenHash: text("refresh_token_hash"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  revoked: boolean("revoked").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('apit_client_idx').on(t.clientId),
  index('apit_user_idx').on(t.userId),
  index('apit_expires_idx').on(t.expiresAt)
]);

export const integrationProviders = pgTable("integration_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  authenticationMethod: varchar("authentication_method", { length: 50 }),
  baseUrl: text("base_url"),
  apiVersion: varchar("api_version", { length: 50 }),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('iprov_name_idx').on(t.providerName),
  index('iprov_org_idx').on(t.organizationId)
]);

export const integrationConnections = pgTable("integration_connections", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerId: uuid("provider_id").references(() => integrationProviders.id, { onDelete: 'cascade' }).notNull(),
  connectionName: varchar("connection_name", { length: 255 }),
  externalAccountId: varchar("external_account_id", { length: 255 }),
  encryptedCredentials: text("encrypted_credentials"),
  lastSync: timestamp("last_sync", { withTimezone: true }),
  syncStatus: varchar("sync_status", { length: 50 }),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('iconn_org_idx').on(t.organizationId),
  index('iconn_prov_idx').on(t.providerId)
]);

export const integrationLogs = pgTable("integration_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerId: uuid("provider_id").references(() => integrationProviders.id, { onDelete: 'cascade' }),
  connectionId: uuid("connection_id").references(() => integrationConnections.id, { onDelete: 'cascade' }),
  operation: varchar("operation", { length: 255 }),
  requestId: varchar("request_id", { length: 255 }),
  responseStatus: varchar("response_status", { length: 50 }),
  executionTimeMs: integer("execution_time_ms"),
  errorMessage: text("error_message"),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ilog_prov_idx').on(t.providerId),
  index('ilog_conn_idx').on(t.connectionId),
  index('ilog_op_idx').on(t.operation),
  index('ilog_created_idx').on(t.createdAt)
]);
`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 8 appended.');
