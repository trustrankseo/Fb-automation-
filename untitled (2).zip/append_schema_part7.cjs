const fs = require('fs');

const schemaAdditions = `

export const subscriptionPlans = pgTable("subscription_plans", {
  id: uuid("id").primaryKey(),
  planName: varchar("plan_name", { length: 255 }).notNull(),
  planCode: varchar("plan_code", { length: 100 }).notNull().unique(),
  description: text("description"),
  billingCycle: varchar("billing_cycle", { length: 50 }),
  price: bigint("price", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  trialDays: integer("trial_days"),
  storageLimit: bigint("storage_limit", { mode: 'number' }),
  projectLimit: integer("project_limit"),
  userLimit: integer("user_limit"),
  apiLimit: bigint("api_limit", { mode: 'number' }),
  aiTokenLimit: bigint("ai_token_limit", { mode: 'number' }),
  workerLimit: integer("worker_limit"),
  supportLevel: varchar("support_level", { length: 100 }),
  isPublic: boolean("is_public").default(false),
  features: jsonb("features").default({}),
  ...commonColumns
}, (t) => [
  index('subplan_code_idx').on(t.planCode),
  index('subplan_status_idx').on(t.status)
]);

export const subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull().unique(),
  planId: uuid("plan_id").references(() => subscriptionPlans.id, { onDelete: 'restrict' }),
  subscriptionNumber: varchar("subscription_number", { length: 255 }),
  billingProvider: varchar("billing_provider", { length: 100 }),
  providerSubscriptionId: varchar("provider_subscription_id", { length: 255 }),
  startDate: timestamp("start_date", { withTimezone: true }),
  renewalDate: timestamp("renewal_date", { withTimezone: true }),
  expirationDate: timestamp("expiration_date", { withTimezone: true }),
  trialEnd: timestamp("trial_end", { withTimezone: true }),
  cancelAt: timestamp("cancel_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  autoRenew: boolean("auto_renew").default(true),
  currentPeriodStart: timestamp("current_period_start", { withTimezone: true }),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('sub_org_idx').on(t.organizationId),
  index('sub_plan_idx').on(t.planId),
  index('sub_status_idx').on(t.status)
]);

export const invoices = pgTable("invoices", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  subscriptionId: uuid("subscription_id").references(() => subscriptions.id, { onDelete: 'cascade' }),
  invoiceNumber: varchar("invoice_number", { length: 255 }).notNull().unique(),
  billingPeriodStart: timestamp("billing_period_start", { withTimezone: true }),
  billingPeriodEnd: timestamp("billing_period_end", { withTimezone: true }),
  subtotal: bigint("subtotal", { mode: 'number' }),
  tax: bigint("tax", { mode: 'number' }),
  discount: bigint("discount", { mode: 'number' }),
  grandTotal: bigint("grand_total", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  paymentStatus: varchar("payment_status", { length: 50 }),
  dueDate: timestamp("due_date", { withTimezone: true }),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  pdfFileId: uuid("pdf_file_id").references(() => files.id, { onDelete: 'set null' }),
  ...commonColumns
}, (t) => [
  index('inv_org_idx').on(t.organizationId),
  index('inv_num_idx').on(t.invoiceNumber),
  index('inv_status_idx').on(t.paymentStatus)
]);

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  invoiceId: uuid("invoice_id").references(() => invoices.id, { onDelete: 'set null' }),
  provider: varchar("provider", { length: 100 }),
  providerTransactionId: varchar("provider_transaction_id", { length: 255 }).unique(),
  paymentMethod: varchar("payment_method", { length: 100 }),
  amount: bigint("amount", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  paymentStatus: varchar("payment_status", { length: 50 }),
  failureReason: text("failure_reason"),
  processedAt: timestamp("processed_at", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('pay_inv_idx').on(t.invoiceId),
  index('pay_tx_idx').on(t.providerTransactionId)
]);

export const licenses = pgTable("licenses", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  licenseKey: varchar("license_key", { length: 255 }).notNull().unique(),
  licenseType: varchar("license_type", { length: 100 }),
  issuedAt: timestamp("issued_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  activatedAt: timestamp("activated_at", { withTimezone: true }),
  deviceLimit: integer("device_limit"),
  seatLimit: integer("seat_limit"),
  licenseStatus: varchar("license_status", { length: 50 }),
  ...commonColumns
}, (t) => [
  index('lic_org_idx').on(t.organizationId),
  index('lic_key_idx').on(t.licenseKey)
]);

export const featureFlags = pgTable("feature_flags", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  featureKey: varchar("feature_key", { length: 100 }).notNull(),
  featureName: varchar("feature_name", { length: 255 }),
  enabled: boolean("enabled").default(false),
  rolloutPercentage: integer("rollout_percentage"),
  minimumPlan: varchar("minimum_plan", { length: 100 }),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('ff_org_idx').on(t.organizationId),
  unique('ff_org_key_unq').on(t.organizationId, t.featureKey)
]);

export const usageTracking = pgTable("usage_tracking", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  metricName: varchar("metric_name", { length: 100 }).notNull(),
  currentUsage: bigint("current_usage", { mode: 'number' }).default(0),
  maximumAllowed: bigint("maximum_allowed", { mode: 'number' }),
  warningThreshold: bigint("warning_threshold", { mode: 'number' }),
  resetPeriod: varchar("reset_period", { length: 50 }),
  lastReset: timestamp("last_reset", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('ut_org_idx').on(t.organizationId),
  index('ut_metric_idx').on(t.metricName)
]);

export const quotaEvents = pgTable("quota_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  usageTrackingId: uuid("usage_tracking_id").references(() => usageTracking.id, { onDelete: 'cascade' }).notNull(),
  eventType: varchar("event_type", { length: 100 }),
  oldValue: bigint("old_value", { mode: 'number' }),
  newValue: bigint("new_value", { mode: 'number' }),
  triggeredBy: varchar("triggered_by", { length: 255 }),
  notes: text("notes"),
  ...commonColumns
}, (t) => [
  index('qe_usage_idx').on(t.usageTrackingId),
  index('qe_created_idx').on(t.createdAt)
]);

export const billingEvents = pgTable("billing_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  subscriptionId: uuid("subscription_id").references(() => subscriptions.id, { onDelete: 'cascade' }),
  eventName: varchar("event_name", { length: 255 }),
  provider: varchar("provider", { length: 100 }),
  providerReference: varchar("provider_reference", { length: 255 }),
  payload: jsonb("payload").default({}),
  ...commonColumns
}, (t) => [
  index('bev_org_idx').on(t.organizationId),
  index('bev_sub_idx').on(t.subscriptionId),
  index('bev_event_idx').on(t.eventName)
]);
`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 7 appended.');
