import type { Config } from 'drizzle-kit';
export default {
  schema: './server/infrastructure/database/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
} satisfies Config;
