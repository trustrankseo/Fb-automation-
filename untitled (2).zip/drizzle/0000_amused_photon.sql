CREATE TABLE "api_keys" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"user_id" uuid,
	"name" varchar(255),
	"api_key_hash" text,
	"prefix" varchar(50),
	"permissions" jsonb DEFAULT '[]'::jsonb,
	"expires_at" timestamp with time zone,
	"last_used_at" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "api_keys_prefix_unique" UNIQUE("prefix")
);
--> statement-breakpoint
CREATE TABLE "attachments" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"file_id" uuid NOT NULL,
	"entity_type" varchar(100) NOT NULL,
	"entity_id" uuid NOT NULL,
	"attached_by" uuid,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"user_id" uuid,
	"request_id" uuid,
	"correlation_id" uuid,
	"resource" varchar(255),
	"resource_id" uuid,
	"action" varchar(255),
	"before" jsonb,
	"after" jsonb,
	"ip_address" varchar(45),
	"user_agent" text,
	"severity" varchar(50),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "download_jobs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"requested_by" uuid,
	"source_id" uuid,
	"queue_id" varchar(255),
	"worker_id" varchar(255),
	"download_url" text NOT NULL,
	"media_type" varchar(50),
	"quality" varchar(50),
	"priority" integer DEFAULT 0,
	"retry_count" integer DEFAULT 0,
	"max_retries" integer DEFAULT 3,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"failed_at" timestamp with time zone,
	"processing_time_ms" integer,
	"failure_reason" text,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "download_sources" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" varchar(255) NOT NULL,
	"provider_type" varchar(100),
	"base_url" text,
	"authentication_type" varchar(50),
	"rate_limit" integer,
	"supports_video" boolean DEFAULT false,
	"supports_image" boolean DEFAULT false,
	"supports_audio" boolean DEFAULT false,
	"supports_metadata" boolean DEFAULT false,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "downloaded_assets" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"download_job_id" uuid,
	"file_id" uuid,
	"provider_asset_id" varchar(255),
	"title" text,
	"description" text,
	"author" varchar(255),
	"license" varchar(255),
	"source_url" text,
	"thumbnail_url" text,
	"preview_url" text,
	"duration" integer,
	"width" integer,
	"height" integer,
	"fps" integer,
	"codec" varchar(50),
	"bitrate" integer,
	"language" varchar(50),
	"checksum" varchar(255),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "files" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"folder_id" uuid,
	"owner_id" uuid,
	"filename" varchar(255) NOT NULL,
	"original_filename" varchar(255),
	"extension" varchar(20),
	"mime_type" varchar(100),
	"size_bytes" bigint,
	"checksum" varchar(255),
	"storage_provider" varchar(50),
	"storage_key" text,
	"public_url" text,
	"thumbnail_url" text,
	"width" integer,
	"height" integer,
	"duration" integer,
	"is_processed" boolean DEFAULT false,
	"processing_status" varchar(50),
	"virus_scan_status" varchar(50),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "folders" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"parent_folder_id" uuid,
	"name" varchar(255) NOT NULL,
	"path" text,
	"depth" integer DEFAULT 0,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "media_processing_jobs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"file_id" uuid NOT NULL,
	"worker_id" varchar(255),
	"operation" varchar(100),
	"input_format" varchar(50),
	"output_format" varchar(50),
	"resolution" varchar(50),
	"processing_engine" varchar(100),
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"duration_ms" integer,
	"error_message" text,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "media_versions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"file_id" uuid NOT NULL,
	"version_number" integer NOT NULL,
	"parent_version" integer,
	"editor" varchar(255),
	"change_summary" text,
	"storage_object_id" uuid,
	"checksum" varchar(255),
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "organizations" (
	"id" uuid PRIMARY KEY NOT NULL,
	"name" varchar(255) NOT NULL,
	"slug" varchar(120) NOT NULL,
	"legal_name" varchar(255),
	"email" varchar(255),
	"phone" varchar(40),
	"website" varchar(255),
	"country_code" char(2),
	"timezone" varchar(100),
	"language" varchar(30),
	"currency" varchar(10),
	"logo_url" text,
	"primary_color" varchar(20),
	"subscription_id" uuid,
	"license_id" uuid,
	"storage_limit" bigint,
	"storage_used" bigint,
	"user_limit" integer,
	"project_limit" integer,
	"ai_enabled" boolean DEFAULT false,
	"branding" jsonb DEFAULT '{}'::jsonb,
	"settings" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "organizations_slug_unique" UNIQUE("slug"),
	CONSTRAINT "organizations_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "permissions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"resource" varchar(255) NOT NULL,
	"action" varchar(255) NOT NULL,
	"permission_key" varchar(255) NOT NULL,
	"description" text,
	"category" varchar(255),
	"risk_level" varchar(50),
	"is_system" boolean DEFAULT false,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "permissions_permission_key_unique" UNIQUE("permission_key")
);
--> statement-breakpoint
CREATE TABLE "project_members" (
	"project_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role_id" uuid,
	"permissions" jsonb DEFAULT '[]'::jsonb,
	"joined_at" timestamp with time zone DEFAULT now(),
	"invited_by" uuid,
	"status" varchar(30) DEFAULT 'ACTIVE',
	CONSTRAINT "pm_project_user_unq" UNIQUE("project_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "project_settings" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"download_settings" jsonb DEFAULT '{}'::jsonb,
	"publish_settings" jsonb DEFAULT '{}'::jsonb,
	"storage_settings" jsonb DEFAULT '{}'::jsonb,
	"notification_settings" jsonb DEFAULT '{}'::jsonb,
	"automation_settings" jsonb DEFAULT '{}'::jsonb,
	"ai_settings" jsonb DEFAULT '{}'::jsonb,
	"security_settings" jsonb DEFAULT '{}'::jsonb,
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "project_settings_project_id_unique" UNIQUE("project_id")
);
--> statement-breakpoint
CREATE TABLE "project_tags" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"name" varchar(100) NOT NULL,
	"color" varchar(20),
	"description" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "project_versions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid NOT NULL,
	"version_number" integer NOT NULL,
	"change_summary" text,
	"created_by" uuid,
	"commit_hash" varchar(100),
	"snapshot" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "projects" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"workspace_id" uuid NOT NULL,
	"owner_id" uuid,
	"name" varchar(255) NOT NULL,
	"slug" varchar(120) NOT NULL,
	"description" text,
	"category" varchar(100),
	"thumbnail" text,
	"visibility" varchar(50),
	"project_type" varchar(100),
	"priority" integer DEFAULT 0,
	"progress" integer DEFAULT 0,
	"health_score" integer DEFAULT 100,
	"current_version" integer DEFAULT 1,
	"default_language" varchar(30),
	"storage_used" bigint DEFAULT 0,
	"storage_limit" bigint,
	"ai_enabled" boolean DEFAULT false,
	"settings" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "proj_workspace_slug_unq" UNIQUE("workspace_id","slug")
);
--> statement-breakpoint
CREATE TABLE "role_permissions" (
	"role_id" uuid NOT NULL,
	"permission_id" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "role_permissions_role_id_permission_id_pk" PRIMARY KEY("role_id","permission_id")
);
--> statement-breakpoint
CREATE TABLE "roles" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"name" varchar(255) NOT NULL,
	"slug" varchar(255) NOT NULL,
	"description" text,
	"is_system" boolean DEFAULT false,
	"priority" integer DEFAULT 0,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "roles_org_slug_unq" UNIQUE("organization_id","slug")
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"user_id" uuid NOT NULL,
	"organization_id" uuid,
	"refresh_token_hash" text,
	"device_name" varchar(255),
	"browser" varchar(255),
	"operating_system" varchar(255),
	"ip_address" varchar(45),
	"country" varchar(255),
	"city" varchar(255),
	"last_activity_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"revoked" boolean DEFAULT false,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "storage_objects" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"file_id" uuid,
	"provider" varchar(100),
	"bucket" varchar(255),
	"region" varchar(100),
	"storage_key" text NOT NULL,
	"object_url" text,
	"public_url" text,
	"encrypted" boolean DEFAULT false,
	"compressed" boolean DEFAULT false,
	"replication_status" varchar(50),
	"checksum" varchar(255),
	"storage_class" varchar(100),
	"size_bytes" bigint,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "sobj_storage_key_unq" UNIQUE("storage_key")
);
--> statement-breakpoint
CREATE TABLE "storage_providers" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_type" varchar(100),
	"endpoint" text,
	"region" varchar(100),
	"default_bucket" varchar(255),
	"encryption_enabled" boolean DEFAULT false,
	"compression_enabled" boolean DEFAULT false,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "thumbnails" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"file_id" uuid NOT NULL,
	"width" integer,
	"height" integer,
	"format" varchar(50),
	"storage_object_id" uuid,
	"generated_by" varchar(100),
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_roles" (
	"user_id" uuid NOT NULL,
	"role_id" uuid NOT NULL,
	"assigned_by" uuid,
	"assigned_at" timestamp with time zone DEFAULT now(),
	"expires_at" timestamp with time zone,
	CONSTRAINT "user_roles_user_id_role_id_pk" PRIMARY KEY("user_id","role_id")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"first_name" varchar(255),
	"last_name" varchar(255),
	"display_name" varchar(255),
	"email" varchar(255) NOT NULL,
	"phone" varchar(40),
	"avatar" text,
	"password_hash" text,
	"password_algorithm" varchar(50),
	"email_verified" boolean DEFAULT false,
	"phone_verified" boolean DEFAULT false,
	"two_factor_enabled" boolean DEFAULT false,
	"two_factor_secret" text,
	"last_login_at" timestamp with time zone,
	"last_login_ip" varchar(45),
	"failed_login_count" integer DEFAULT 0,
	"locked_until" timestamp with time zone,
	"locale" varchar(30),
	"timezone" varchar(100),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "workspace_members" (
	"workspace_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role_id" uuid,
	"joined_at" timestamp with time zone DEFAULT now(),
	"invited_by" uuid,
	"is_owner" boolean DEFAULT false,
	"status" varchar(30) DEFAULT 'ACTIVE',
	CONSTRAINT "wm_workspace_user_unq" UNIQUE("workspace_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "workspaces" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" varchar(255) NOT NULL,
	"slug" varchar(120) NOT NULL,
	"description" text,
	"icon" text,
	"color" varchar(20),
	"visibility" varchar(50),
	"owner_id" uuid,
	"default_language" varchar(30),
	"default_timezone" varchar(100),
	"settings" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "workspace_org_slug_unq" UNIQUE("organization_id","slug")
);
--> statement-breakpoint
ALTER TABLE "api_keys" ADD CONSTRAINT "api_keys_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "api_keys" ADD CONSTRAINT "api_keys_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "attachments" ADD CONSTRAINT "attachments_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "attachments" ADD CONSTRAINT "attachments_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "download_jobs" ADD CONSTRAINT "download_jobs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "download_jobs" ADD CONSTRAINT "download_jobs_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "download_jobs" ADD CONSTRAINT "download_jobs_requested_by_users_id_fk" FOREIGN KEY ("requested_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "download_jobs" ADD CONSTRAINT "download_jobs_source_id_download_sources_id_fk" FOREIGN KEY ("source_id") REFERENCES "public"."download_sources"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "download_sources" ADD CONSTRAINT "download_sources_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "downloaded_assets" ADD CONSTRAINT "downloaded_assets_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "downloaded_assets" ADD CONSTRAINT "downloaded_assets_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "downloaded_assets" ADD CONSTRAINT "downloaded_assets_download_job_id_download_jobs_id_fk" FOREIGN KEY ("download_job_id") REFERENCES "public"."download_jobs"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "downloaded_assets" ADD CONSTRAINT "downloaded_assets_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_folder_id_folders_id_fk" FOREIGN KEY ("folder_id") REFERENCES "public"."folders"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "folders" ADD CONSTRAINT "folders_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "folders" ADD CONSTRAINT "folders_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_processing_jobs" ADD CONSTRAINT "media_processing_jobs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_processing_jobs" ADD CONSTRAINT "media_processing_jobs_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_processing_jobs" ADD CONSTRAINT "media_processing_jobs_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_versions" ADD CONSTRAINT "media_versions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_versions" ADD CONSTRAINT "media_versions_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "media_versions" ADD CONSTRAINT "media_versions_storage_object_id_storage_objects_id_fk" FOREIGN KEY ("storage_object_id") REFERENCES "public"."storage_objects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_members" ADD CONSTRAINT "project_members_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_members" ADD CONSTRAINT "project_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_members" ADD CONSTRAINT "project_members_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_settings" ADD CONSTRAINT "project_settings_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_settings" ADD CONSTRAINT "project_settings_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_tags" ADD CONSTRAINT "project_tags_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_tags" ADD CONSTRAINT "project_tags_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_versions" ADD CONSTRAINT "project_versions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_versions" ADD CONSTRAINT "project_versions_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_workspace_id_workspaces_id_fk" FOREIGN KEY ("workspace_id") REFERENCES "public"."workspaces"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_permission_id_permissions_id_fk" FOREIGN KEY ("permission_id") REFERENCES "public"."permissions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roles" ADD CONSTRAINT "roles_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "storage_objects" ADD CONSTRAINT "storage_objects_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "storage_objects" ADD CONSTRAINT "storage_objects_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "storage_providers" ADD CONSTRAINT "storage_providers_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "thumbnails" ADD CONSTRAINT "thumbnails_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "thumbnails" ADD CONSTRAINT "thumbnails_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "thumbnails" ADD CONSTRAINT "thumbnails_storage_object_id_storage_objects_id_fk" FOREIGN KEY ("storage_object_id") REFERENCES "public"."storage_objects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "workspace_members" ADD CONSTRAINT "workspace_members_workspace_id_workspaces_id_fk" FOREIGN KEY ("workspace_id") REFERENCES "public"."workspaces"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "workspace_members" ADD CONSTRAINT "workspace_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "workspace_members" ADD CONSTRAINT "workspace_members_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "workspaces" ADD CONSTRAINT "workspaces_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "workspaces" ADD CONSTRAINT "workspaces_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "apikeys_org_idx" ON "api_keys" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "apikeys_user_idx" ON "api_keys" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "att_entity_type_idx" ON "attachments" USING btree ("entity_type");--> statement-breakpoint
CREATE INDEX "att_entity_id_idx" ON "attachments" USING btree ("entity_id");--> statement-breakpoint
CREATE INDEX "att_file_idx" ON "attachments" USING btree ("file_id");--> statement-breakpoint
CREATE INDEX "audit_org_idx" ON "audit_logs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "audit_resource_idx" ON "audit_logs" USING btree ("resource");--> statement-breakpoint
CREATE INDEX "audit_action_idx" ON "audit_logs" USING btree ("action");--> statement-breakpoint
CREATE INDEX "audit_created_idx" ON "audit_logs" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "djob_org_idx" ON "download_jobs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "djob_project_idx" ON "download_jobs" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "djob_worker_idx" ON "download_jobs" USING btree ("worker_id");--> statement-breakpoint
CREATE INDEX "djob_status_idx" ON "download_jobs" USING btree ("status");--> statement-breakpoint
CREATE INDEX "djob_priority_idx" ON "download_jobs" USING btree ("priority");--> statement-breakpoint
CREATE INDEX "djob_created_idx" ON "download_jobs" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "dsource_org_idx" ON "download_sources" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "dsource_ptype_idx" ON "download_sources" USING btree ("provider_type");--> statement-breakpoint
CREATE INDEX "dsource_status_idx" ON "download_sources" USING btree ("status");--> statement-breakpoint
CREATE INDEX "dasset_org_idx" ON "downloaded_assets" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "dasset_project_idx" ON "downloaded_assets" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "dasset_job_idx" ON "downloaded_assets" USING btree ("download_job_id");--> statement-breakpoint
CREATE INDEX "dasset_checksum_idx" ON "downloaded_assets" USING btree ("checksum");--> statement-breakpoint
CREATE INDEX "file_org_idx" ON "files" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "file_project_idx" ON "files" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "file_folder_idx" ON "files" USING btree ("folder_id");--> statement-breakpoint
CREATE INDEX "file_checksum_idx" ON "files" USING btree ("checksum");--> statement-breakpoint
CREATE INDEX "file_mimetype_idx" ON "files" USING btree ("mime_type");--> statement-breakpoint
CREATE INDEX "file_procstatus_idx" ON "files" USING btree ("processing_status");--> statement-breakpoint
CREATE INDEX "folder_project_idx" ON "folders" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "folder_parent_idx" ON "folders" USING btree ("parent_folder_id");--> statement-breakpoint
CREATE INDEX "folder_path_idx" ON "folders" USING btree ("path");--> statement-breakpoint
CREATE INDEX "mpjob_org_idx" ON "media_processing_jobs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "mpjob_project_idx" ON "media_processing_jobs" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "mpjob_worker_idx" ON "media_processing_jobs" USING btree ("worker_id");--> statement-breakpoint
CREATE INDEX "mpjob_operation_idx" ON "media_processing_jobs" USING btree ("operation");--> statement-breakpoint
CREATE INDEX "mpjob_status_idx" ON "media_processing_jobs" USING btree ("status");--> statement-breakpoint
CREATE INDEX "mver_file_idx" ON "media_versions" USING btree ("file_id");--> statement-breakpoint
CREATE INDEX "mver_version_idx" ON "media_versions" USING btree ("version_number");--> statement-breakpoint
CREATE INDEX "org_status_idx" ON "organizations" USING btree ("status");--> statement-breakpoint
CREATE INDEX "org_country_idx" ON "organizations" USING btree ("country_code");--> statement-breakpoint
CREATE INDEX "org_created_idx" ON "organizations" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "perm_category_idx" ON "permissions" USING btree ("category");--> statement-breakpoint
CREATE INDEX "pm_project_idx" ON "project_members" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "pm_user_idx" ON "project_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "pm_role_idx" ON "project_members" USING btree ("role_id");--> statement-breakpoint
CREATE INDEX "ptag_project_idx" ON "project_tags" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "ptag_name_idx" ON "project_tags" USING btree ("name");--> statement-breakpoint
CREATE INDEX "pver_project_idx" ON "project_versions" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "pver_version_idx" ON "project_versions" USING btree ("version_number");--> statement-breakpoint
CREATE INDEX "proj_org_idx" ON "projects" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "proj_workspace_idx" ON "projects" USING btree ("workspace_id");--> statement-breakpoint
CREATE INDEX "proj_owner_idx" ON "projects" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "proj_status_idx" ON "projects" USING btree ("status");--> statement-breakpoint
CREATE INDEX "proj_priority_idx" ON "projects" USING btree ("priority");--> statement-breakpoint
CREATE INDEX "proj_created_idx" ON "projects" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "roles_org_idx" ON "roles" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "roles_slug_idx" ON "roles" USING btree ("slug");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "sessions" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "sessions_org_idx" ON "sessions" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "sessions_expires_idx" ON "sessions" USING btree ("expires_at");--> statement-breakpoint
CREATE INDEX "sobj_provider_idx" ON "storage_objects" USING btree ("provider");--> statement-breakpoint
CREATE INDEX "sobj_bucket_idx" ON "storage_objects" USING btree ("bucket");--> statement-breakpoint
CREATE INDEX "sprov_name_idx" ON "storage_providers" USING btree ("provider_name");--> statement-breakpoint
CREATE INDEX "sprov_org_idx" ON "storage_providers" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "thumb_file_idx" ON "thumbnails" USING btree ("file_id");--> statement-breakpoint
CREATE INDEX "user_org_idx" ON "users" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "user_status_idx" ON "users" USING btree ("status");--> statement-breakpoint
CREATE INDEX "user_lastlogin_idx" ON "users" USING btree ("last_login_at");--> statement-breakpoint
CREATE INDEX "wm_workspace_idx" ON "workspace_members" USING btree ("workspace_id");--> statement-breakpoint
CREATE INDEX "wm_user_idx" ON "workspace_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "wm_role_idx" ON "workspace_members" USING btree ("role_id");--> statement-breakpoint
CREATE INDEX "workspace_org_idx" ON "workspaces" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "workspace_owner_idx" ON "workspaces" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "workspace_slug_idx" ON "workspaces" USING btree ("slug");--> statement-breakpoint
CREATE INDEX "workspace_status_idx" ON "workspaces" USING btree ("status");