CREATE TABLE "ai_agents" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" varchar(255) NOT NULL,
	"agent_type" varchar(100),
	"description" text,
	"default_provider_id" uuid,
	"default_model_id" uuid,
	"system_prompt" text,
	"temperature" integer,
	"max_tokens" integer,
	"tool_access" jsonb DEFAULT '{}'::jsonb,
	"permission_profile" varchar(100),
	"approval_required" boolean DEFAULT false,
	"memory_enabled" boolean DEFAULT false,
	"enabled" boolean DEFAULT true,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "ai_conversations" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid,
	"user_id" uuid NOT NULL,
	"title" text,
	"summary" text,
	"last_message_at" timestamp with time zone,
	"message_count" integer DEFAULT 0,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_feedback" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"request_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"rating" integer,
	"feedback_text" text,
	"accepted" boolean DEFAULT false,
	"reviewed" boolean DEFAULT false,
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_memory" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"conversation_id" uuid NOT NULL,
	"memory_type" varchar(50),
	"importance_score" integer,
	"memory_content" text,
	"embedding_id" varchar(255),
	"expires_at" timestamp with time zone,
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_models" (
	"id" uuid PRIMARY KEY NOT NULL,
	"provider_id" uuid NOT NULL,
	"model_name" varchar(255) NOT NULL,
	"model_version" varchar(100),
	"context_window" integer,
	"max_output_tokens" integer,
	"supports_reasoning" boolean DEFAULT false,
	"supports_tools" boolean DEFAULT false,
	"supports_images" boolean DEFAULT false,
	"supports_audio" boolean DEFAULT false,
	"supports_video" boolean DEFAULT false,
	"cost_input" bigint,
	"cost_output" bigint,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_providers" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_type" varchar(100),
	"provider_version" varchar(50),
	"api_endpoint" text,
	"authentication_type" varchar(50),
	"default_model" varchar(255),
	"supports_streaming" boolean DEFAULT false,
	"supports_function_calling" boolean DEFAULT false,
	"supports_images" boolean DEFAULT false,
	"supports_video" boolean DEFAULT false,
	"supports_audio" boolean DEFAULT false,
	"supports_embeddings" boolean DEFAULT false,
	"priority" integer DEFAULT 0,
	"enabled" boolean DEFAULT true,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "ai_requests" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid,
	"user_id" uuid,
	"agent_id" uuid,
	"provider_id" uuid,
	"model_id" uuid,
	"conversation_id" uuid,
	"prompt_version" integer,
	"input_tokens" integer,
	"output_tokens" integer,
	"execution_time_ms" integer,
	"cost" bigint,
	"request_payload" jsonb DEFAULT '{}'::jsonb,
	"response_payload" jsonb DEFAULT '{}'::jsonb,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_tool_calls" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"request_id" uuid NOT NULL,
	"tool_name" varchar(255) NOT NULL,
	"tool_version" varchar(50),
	"parameters" jsonb DEFAULT '{}'::jsonb,
	"execution_result" jsonb DEFAULT '{}'::jsonb,
	"execution_time_ms" integer,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "knowledge_base" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid,
	"title" text NOT NULL,
	"content_type" varchar(100),
	"source" varchar(255),
	"storage_file_id" uuid,
	"embedding_status" varchar(50),
	"vector_id" varchar(255),
	"language" varchar(30),
	"checksum" varchar(255),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "prompt_templates" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" varchar(255) NOT NULL,
	"category" varchar(100),
	"version_number" integer NOT NULL,
	"system_prompt" text,
	"user_prompt" text,
	"variables" jsonb DEFAULT '{}'::jsonb,
	"approval_required" boolean DEFAULT false,
	"active" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "ai_agents" ADD CONSTRAINT "ai_agents_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_agents" ADD CONSTRAINT "ai_agents_default_provider_id_ai_providers_id_fk" FOREIGN KEY ("default_provider_id") REFERENCES "public"."ai_providers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_agents" ADD CONSTRAINT "ai_agents_default_model_id_ai_models_id_fk" FOREIGN KEY ("default_model_id") REFERENCES "public"."ai_models"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_conversations" ADD CONSTRAINT "ai_conversations_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_conversations" ADD CONSTRAINT "ai_conversations_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_conversations" ADD CONSTRAINT "ai_conversations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_feedback" ADD CONSTRAINT "ai_feedback_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_feedback" ADD CONSTRAINT "ai_feedback_request_id_ai_requests_id_fk" FOREIGN KEY ("request_id") REFERENCES "public"."ai_requests"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_feedback" ADD CONSTRAINT "ai_feedback_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_memory" ADD CONSTRAINT "ai_memory_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_memory" ADD CONSTRAINT "ai_memory_conversation_id_ai_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."ai_conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_models" ADD CONSTRAINT "ai_models_provider_id_ai_providers_id_fk" FOREIGN KEY ("provider_id") REFERENCES "public"."ai_providers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_providers" ADD CONSTRAINT "ai_providers_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_agent_id_ai_agents_id_fk" FOREIGN KEY ("agent_id") REFERENCES "public"."ai_agents"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_provider_id_ai_providers_id_fk" FOREIGN KEY ("provider_id") REFERENCES "public"."ai_providers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_model_id_ai_models_id_fk" FOREIGN KEY ("model_id") REFERENCES "public"."ai_models"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_requests" ADD CONSTRAINT "ai_requests_conversation_id_ai_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."ai_conversations"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_tool_calls" ADD CONSTRAINT "ai_tool_calls_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_tool_calls" ADD CONSTRAINT "ai_tool_calls_request_id_ai_requests_id_fk" FOREIGN KEY ("request_id") REFERENCES "public"."ai_requests"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_base" ADD CONSTRAINT "knowledge_base_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_base" ADD CONSTRAINT "knowledge_base_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_base" ADD CONSTRAINT "knowledge_base_storage_file_id_files_id_fk" FOREIGN KEY ("storage_file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prompt_templates" ADD CONSTRAINT "prompt_templates_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "aiagent_org_idx" ON "ai_agents" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "aiagent_type_idx" ON "ai_agents" USING btree ("agent_type");--> statement-breakpoint
CREATE INDEX "aiagent_enabled_idx" ON "ai_agents" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "aiconv_org_idx" ON "ai_conversations" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "aiconv_user_idx" ON "ai_conversations" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "aifb_req_idx" ON "ai_feedback" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "aifb_rating_idx" ON "ai_feedback" USING btree ("rating");--> statement-breakpoint
CREATE INDEX "aimem_conv_idx" ON "ai_memory" USING btree ("conversation_id");--> statement-breakpoint
CREATE INDEX "aimem_type_idx" ON "ai_memory" USING btree ("memory_type");--> statement-breakpoint
CREATE INDEX "aimod_provider_idx" ON "ai_models" USING btree ("provider_id");--> statement-breakpoint
CREATE INDEX "aimod_name_idx" ON "ai_models" USING btree ("model_name");--> statement-breakpoint
CREATE INDEX "aiprov_name_idx" ON "ai_providers" USING btree ("provider_name");--> statement-breakpoint
CREATE INDEX "aiprov_enabled_idx" ON "ai_providers" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "aiprov_priority_idx" ON "ai_providers" USING btree ("priority");--> statement-breakpoint
CREATE INDEX "aireq_org_idx" ON "ai_requests" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "aireq_proj_idx" ON "ai_requests" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "aireq_agent_idx" ON "ai_requests" USING btree ("agent_id");--> statement-breakpoint
CREATE INDEX "aireq_user_idx" ON "ai_requests" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "aireq_created_idx" ON "ai_requests" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "aitool_req_idx" ON "ai_tool_calls" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "aitool_name_idx" ON "ai_tool_calls" USING btree ("tool_name");--> statement-breakpoint
CREATE INDEX "kb_org_idx" ON "knowledge_base" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "kb_proj_idx" ON "knowledge_base" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "kb_ctype_idx" ON "knowledge_base" USING btree ("content_type");--> statement-breakpoint
CREATE INDEX "promptt_org_idx" ON "prompt_templates" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "promptt_cat_idx" ON "prompt_templates" USING btree ("category");--> statement-breakpoint
CREATE INDEX "promptt_active_idx" ON "prompt_templates" USING btree ("active");