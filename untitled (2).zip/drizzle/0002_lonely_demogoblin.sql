CREATE TABLE "activity_logs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"user_id" uuid,
	"project_id" uuid,
	"activity_type" varchar(100),
	"resource_type" varchar(100),
	"resource_id" uuid,
	"description" text,
	"ip_address" varchar(45),
	"device" varchar(255),
	"browser" varchar(255),
	"country" varchar(255),
	"city" varchar(255),
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "audit_events" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"user_id" uuid,
	"resource_type" varchar(100),
	"resource_id" uuid,
	"event_name" varchar(255),
	"severity" varchar(50),
	"before_state" jsonb DEFAULT '{}'::jsonb,
	"after_state" jsonb DEFAULT '{}'::jsonb,
	"request_id" varchar(255),
	"correlation_id" varchar(255),
	"ip_address" varchar(45),
	"user_agent" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "dashboards" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"owner_id" uuid,
	"name" varchar(255) NOT NULL,
	"layout" jsonb DEFAULT '{}'::jsonb,
	"widgets" jsonb DEFAULT '{}'::jsonb,
	"visibility" varchar(50),
	"default_dashboard" boolean DEFAULT false,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "metrics" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"metric_name" varchar(255) NOT NULL,
	"metric_type" varchar(100),
	"metric_value" bigint,
	"unit" varchar(50),
	"source" varchar(255),
	"tags" jsonb DEFAULT '{}'::jsonb,
	"recorded_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "notification_deliveries" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"notification_id" uuid NOT NULL,
	"provider" varchar(100),
	"destination" text,
	"delivery_status" varchar(50),
	"attempt_count" integer DEFAULT 0,
	"sent_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"failed_at" timestamp with time zone,
	"failure_reason" text,
	"provider_response" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "notification_templates" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"template_name" varchar(255) NOT NULL,
	"channel" varchar(50),
	"subject" text,
	"body" text,
	"variables" jsonb DEFAULT '{}'::jsonb,
	"language" varchar(30),
	"active" boolean DEFAULT true,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"user_id" uuid,
	"project_id" uuid,
	"notification_type" varchar(100),
	"title" text,
	"message" text,
	"priority" varchar(50),
	"channel" varchar(50),
	"icon" text,
	"action_url" text,
	"is_read" boolean DEFAULT false,
	"read_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "report_schedules" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"report_id" uuid,
	"cron_expression" varchar(100),
	"timezone" varchar(100),
	"last_run" timestamp with time zone,
	"next_run" timestamp with time zone,
	"enabled" boolean DEFAULT true,
	"delivery_channels" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "reports" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"project_id" uuid,
	"generated_by" uuid,
	"report_type" varchar(100),
	"report_format" varchar(50),
	"storage_file_id" uuid,
	"generated_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb
);
--> statement-breakpoint
CREATE TABLE "system_logs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid,
	"service_name" varchar(255),
	"module" varchar(255),
	"log_level" varchar(50),
	"request_id" varchar(255),
	"correlation_id" varchar(255),
	"trace_id" varchar(255),
	"message" text,
	"exception" text,
	"stack_trace" text,
	"duration_ms" integer,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_events" ADD CONSTRAINT "audit_events_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_events" ADD CONSTRAINT "audit_events_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dashboards" ADD CONSTRAINT "dashboards_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dashboards" ADD CONSTRAINT "dashboards_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "metrics" ADD CONSTRAINT "metrics_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_deliveries" ADD CONSTRAINT "notification_deliveries_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_deliveries" ADD CONSTRAINT "notification_deliveries_notification_id_notifications_id_fk" FOREIGN KEY ("notification_id") REFERENCES "public"."notifications"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_templates" ADD CONSTRAINT "notification_templates_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_schedules" ADD CONSTRAINT "report_schedules_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_schedules" ADD CONSTRAINT "report_schedules_report_id_reports_id_fk" FOREIGN KEY ("report_id") REFERENCES "public"."reports"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reports" ADD CONSTRAINT "reports_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reports" ADD CONSTRAINT "reports_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reports" ADD CONSTRAINT "reports_generated_by_users_id_fk" FOREIGN KEY ("generated_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reports" ADD CONSTRAINT "reports_storage_file_id_files_id_fk" FOREIGN KEY ("storage_file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "system_logs" ADD CONSTRAINT "system_logs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "actlog_org_idx" ON "activity_logs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "actlog_user_idx" ON "activity_logs" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "actlog_proj_idx" ON "activity_logs" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "actlog_type_idx" ON "activity_logs" USING btree ("activity_type");--> statement-breakpoint
CREATE INDEX "actlog_created_idx" ON "activity_logs" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "aevt_org_idx" ON "audit_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "aevt_name_idx" ON "audit_events" USING btree ("event_name");--> statement-breakpoint
CREATE INDEX "aevt_severity_idx" ON "audit_events" USING btree ("severity");--> statement-breakpoint
CREATE INDEX "aevt_created_idx" ON "audit_events" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "dash_org_idx" ON "dashboards" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "dash_owner_idx" ON "dashboards" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "metric_org_idx" ON "metrics" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "metric_name_idx" ON "metrics" USING btree ("metric_name");--> statement-breakpoint
CREATE INDEX "metric_recorded_idx" ON "metrics" USING btree ("recorded_at");--> statement-breakpoint
CREATE INDEX "ndel_notif_idx" ON "notification_deliveries" USING btree ("notification_id");--> statement-breakpoint
CREATE INDEX "ndel_prov_idx" ON "notification_deliveries" USING btree ("provider");--> statement-breakpoint
CREATE INDEX "ndel_status_idx" ON "notification_deliveries" USING btree ("delivery_status");--> statement-breakpoint
CREATE INDEX "ntmpl_org_idx" ON "notification_templates" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "ntmpl_name_idx" ON "notification_templates" USING btree ("template_name");--> statement-breakpoint
CREATE INDEX "notif_org_idx" ON "notifications" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "notif_user_idx" ON "notifications" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "notif_proj_idx" ON "notifications" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "notif_priority_idx" ON "notifications" USING btree ("priority");--> statement-breakpoint
CREATE INDEX "notif_isread_idx" ON "notifications" USING btree ("is_read");--> statement-breakpoint
CREATE INDEX "notif_created_idx" ON "notifications" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "rsched_org_idx" ON "report_schedules" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "rsched_next_idx" ON "report_schedules" USING btree ("next_run");--> statement-breakpoint
CREATE INDEX "rsched_enabled_idx" ON "report_schedules" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "rep_org_idx" ON "reports" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "rep_proj_idx" ON "reports" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "rep_type_idx" ON "reports" USING btree ("report_type");--> statement-breakpoint
CREATE INDEX "syslog_level_idx" ON "system_logs" USING btree ("log_level");--> statement-breakpoint
CREATE INDEX "syslog_svc_idx" ON "system_logs" USING btree ("service_name");--> statement-breakpoint
CREATE INDEX "syslog_req_idx" ON "system_logs" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "syslog_created_idx" ON "system_logs" USING btree ("created_at");