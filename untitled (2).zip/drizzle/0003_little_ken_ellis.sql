CREATE TABLE "billing_events" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"subscription_id" uuid,
	"event_name" varchar(255),
	"provider" varchar(100),
	"provider_reference" varchar(255),
	"payload" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "feature_flags" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"feature_key" varchar(100) NOT NULL,
	"feature_name" varchar(255),
	"enabled" boolean DEFAULT false,
	"rollout_percentage" integer,
	"minimum_plan" varchar(100),
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "ff_org_key_unq" UNIQUE("organization_id","feature_key")
);
--> statement-breakpoint
CREATE TABLE "invoices" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"subscription_id" uuid,
	"invoice_number" varchar(255) NOT NULL,
	"billing_period_start" timestamp with time zone,
	"billing_period_end" timestamp with time zone,
	"subtotal" bigint,
	"tax" bigint,
	"discount" bigint,
	"grand_total" bigint,
	"currency" varchar(10),
	"payment_status" varchar(50),
	"due_date" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"pdf_file_id" uuid,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "invoices_invoice_number_unique" UNIQUE("invoice_number")
);
--> statement-breakpoint
CREATE TABLE "licenses" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"license_key" varchar(255) NOT NULL,
	"license_type" varchar(100),
	"issued_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"device_limit" integer,
	"seat_limit" integer,
	"license_status" varchar(50),
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "licenses_license_key_unique" UNIQUE("license_key")
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"invoice_id" uuid,
	"provider" varchar(100),
	"provider_transaction_id" varchar(255),
	"payment_method" varchar(100),
	"amount" bigint,
	"currency" varchar(10),
	"payment_status" varchar(50),
	"failure_reason" text,
	"processed_at" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "payments_provider_transaction_id_unique" UNIQUE("provider_transaction_id")
);
--> statement-breakpoint
CREATE TABLE "quota_events" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"usage_tracking_id" uuid NOT NULL,
	"event_type" varchar(100),
	"old_value" bigint,
	"new_value" bigint,
	"triggered_by" varchar(255),
	"notes" text,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "subscription_plans" (
	"id" uuid PRIMARY KEY NOT NULL,
	"plan_name" varchar(255) NOT NULL,
	"plan_code" varchar(100) NOT NULL,
	"description" text,
	"billing_cycle" varchar(50),
	"price" bigint,
	"currency" varchar(10),
	"trial_days" integer,
	"storage_limit" bigint,
	"project_limit" integer,
	"user_limit" integer,
	"api_limit" bigint,
	"ai_token_limit" bigint,
	"worker_limit" integer,
	"support_level" varchar(100),
	"is_public" boolean DEFAULT false,
	"features" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "subscription_plans_plan_code_unique" UNIQUE("plan_code")
);
--> statement-breakpoint
CREATE TABLE "subscriptions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"plan_id" uuid,
	"subscription_number" varchar(255),
	"billing_provider" varchar(100),
	"provider_subscription_id" varchar(255),
	"start_date" timestamp with time zone,
	"renewal_date" timestamp with time zone,
	"expiration_date" timestamp with time zone,
	"trial_end" timestamp with time zone,
	"cancel_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"auto_renew" boolean DEFAULT true,
	"current_period_start" timestamp with time zone,
	"current_period_end" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "subscriptions_organization_id_unique" UNIQUE("organization_id")
);
--> statement-breakpoint
CREATE TABLE "usage_tracking" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"metric_name" varchar(100) NOT NULL,
	"current_usage" bigint DEFAULT 0,
	"maximum_allowed" bigint,
	"warning_threshold" bigint,
	"reset_period" varchar(50),
	"last_reset" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_subscription_id_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "feature_flags" ADD CONSTRAINT "feature_flags_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_subscription_id_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_pdf_file_id_files_id_fk" FOREIGN KEY ("pdf_file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "licenses" ADD CONSTRAINT "licenses_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quota_events" ADD CONSTRAINT "quota_events_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quota_events" ADD CONSTRAINT "quota_events_usage_tracking_id_usage_tracking_id_fk" FOREIGN KEY ("usage_tracking_id") REFERENCES "public"."usage_tracking"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_plan_id_subscription_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."subscription_plans"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "usage_tracking" ADD CONSTRAINT "usage_tracking_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "bev_org_idx" ON "billing_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "bev_sub_idx" ON "billing_events" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "bev_event_idx" ON "billing_events" USING btree ("event_name");--> statement-breakpoint
CREATE INDEX "ff_org_idx" ON "feature_flags" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "inv_org_idx" ON "invoices" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "inv_num_idx" ON "invoices" USING btree ("invoice_number");--> statement-breakpoint
CREATE INDEX "inv_status_idx" ON "invoices" USING btree ("payment_status");--> statement-breakpoint
CREATE INDEX "lic_org_idx" ON "licenses" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "lic_key_idx" ON "licenses" USING btree ("license_key");--> statement-breakpoint
CREATE INDEX "pay_inv_idx" ON "payments" USING btree ("invoice_id");--> statement-breakpoint
CREATE INDEX "pay_tx_idx" ON "payments" USING btree ("provider_transaction_id");--> statement-breakpoint
CREATE INDEX "qe_usage_idx" ON "quota_events" USING btree ("usage_tracking_id");--> statement-breakpoint
CREATE INDEX "qe_created_idx" ON "quota_events" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "subplan_code_idx" ON "subscription_plans" USING btree ("plan_code");--> statement-breakpoint
CREATE INDEX "subplan_status_idx" ON "subscription_plans" USING btree ("status");--> statement-breakpoint
CREATE INDEX "sub_org_idx" ON "subscriptions" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "sub_plan_idx" ON "subscriptions" USING btree ("plan_id");--> statement-breakpoint
CREATE INDEX "sub_status_idx" ON "subscriptions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "ut_org_idx" ON "usage_tracking" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "ut_metric_idx" ON "usage_tracking" USING btree ("metric_name");