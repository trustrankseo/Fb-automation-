CREATE TABLE "api_clients" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"client_name" varchar(255) NOT NULL,
	"client_id" varchar(255) NOT NULL,
	"client_secret_hash" text,
	"redirect_uri" text,
	"allowed_scopes" jsonb DEFAULT '{}'::jsonb,
	"allowed_origins" jsonb DEFAULT '{}'::jsonb,
	"rate_limit" integer,
	"enabled" boolean DEFAULT true,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "api_clients_client_id_unique" UNIQUE("client_id")
);
--> statement-breakpoint
CREATE TABLE "api_tokens" (
	"id" uuid PRIMARY KEY NOT NULL,
	"client_id" varchar(255) NOT NULL,
	"organization_id" uuid NOT NULL,
	"user_id" uuid,
	"token_hash" text,
	"refresh_token_hash" text,
	"expires_at" timestamp with time zone,
	"last_used_at" timestamp with time zone,
	"revoked" boolean DEFAULT false,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "integration_connections" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"provider_id" uuid NOT NULL,
	"connection_name" varchar(255),
	"external_account_id" varchar(255),
	"encrypted_credentials" text,
	"last_sync" timestamp with time zone,
	"sync_status" varchar(50),
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "integration_logs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"provider_id" uuid,
	"connection_id" uuid,
	"operation" varchar(255),
	"request_id" varchar(255),
	"response_status" varchar(50),
	"execution_time_ms" integer,
	"error_message" text,
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "integration_providers" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"provider_name" varchar(255) NOT NULL,
	"provider_type" varchar(100),
	"authentication_method" varchar(50),
	"base_url" text,
	"api_version" varchar(50),
	"enabled" boolean DEFAULT true,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
CREATE TABLE "plugin_hooks" (
	"id" uuid PRIMARY KEY NOT NULL,
	"plugin_id" uuid NOT NULL,
	"hook_name" varchar(255),
	"event_name" varchar(255),
	"priority" integer DEFAULT 0,
	"enabled" boolean DEFAULT true,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "plugin_versions" (
	"id" uuid PRIMARY KEY NOT NULL,
	"plugin_id" uuid NOT NULL,
	"version" varchar(50),
	"release_notes" text,
	"checksum" varchar(255),
	"download_url" text,
	"installed_at" timestamp with time zone,
	"installed_by" uuid,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "plugins" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"plugin_name" varchar(255) NOT NULL,
	"plugin_slug" varchar(255) NOT NULL,
	"plugin_version" varchar(50),
	"plugin_author" varchar(255),
	"plugin_type" varchar(100),
	"plugin_category" varchar(100),
	"minimum_platform_version" varchar(50),
	"maximum_platform_version" varchar(50),
	"installation_path" text,
	"configuration" jsonb DEFAULT '{}'::jsonb,
	"permissions" jsonb DEFAULT '{}'::jsonb,
	"enabled" boolean DEFAULT false,
	"verified" boolean DEFAULT false,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "plugins_plugin_slug_unique" UNIQUE("plugin_slug")
);
--> statement-breakpoint
CREATE TABLE "webhook_deliveries" (
	"id" uuid PRIMARY KEY NOT NULL,
	"webhook_id" uuid NOT NULL,
	"event_name" varchar(255),
	"request_body" jsonb DEFAULT '{}'::jsonb,
	"response_code" integer,
	"response_body" text,
	"attempt_count" integer DEFAULT 0,
	"delivery_time_ms" integer,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "webhooks" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" varchar(255) NOT NULL,
	"target_url" text,
	"http_method" varchar(20),
	"secret" varchar(255),
	"enabled" boolean DEFAULT true,
	"retry_policy" varchar(100),
	"timeout_seconds" integer,
	"headers" jsonb DEFAULT '{}'::jsonb,
	"events" jsonb DEFAULT '{}'::jsonb,
	"last_delivery" timestamp with time zone,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid
);
--> statement-breakpoint
ALTER TABLE "api_clients" ADD CONSTRAINT "api_clients_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "api_tokens" ADD CONSTRAINT "api_tokens_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "api_tokens" ADD CONSTRAINT "api_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_connections" ADD CONSTRAINT "integration_connections_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_connections" ADD CONSTRAINT "integration_connections_provider_id_integration_providers_id_fk" FOREIGN KEY ("provider_id") REFERENCES "public"."integration_providers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_logs" ADD CONSTRAINT "integration_logs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_logs" ADD CONSTRAINT "integration_logs_provider_id_integration_providers_id_fk" FOREIGN KEY ("provider_id") REFERENCES "public"."integration_providers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_logs" ADD CONSTRAINT "integration_logs_connection_id_integration_connections_id_fk" FOREIGN KEY ("connection_id") REFERENCES "public"."integration_connections"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integration_providers" ADD CONSTRAINT "integration_providers_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plugin_hooks" ADD CONSTRAINT "plugin_hooks_plugin_id_plugins_id_fk" FOREIGN KEY ("plugin_id") REFERENCES "public"."plugins"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plugin_versions" ADD CONSTRAINT "plugin_versions_plugin_id_plugins_id_fk" FOREIGN KEY ("plugin_id") REFERENCES "public"."plugins"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plugin_versions" ADD CONSTRAINT "plugin_versions_installed_by_users_id_fk" FOREIGN KEY ("installed_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plugins" ADD CONSTRAINT "plugins_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_deliveries" ADD CONSTRAINT "webhook_deliveries_webhook_id_webhooks_id_fk" FOREIGN KEY ("webhook_id") REFERENCES "public"."webhooks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhooks" ADD CONSTRAINT "webhooks_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "apic_id_idx" ON "api_clients" USING btree ("client_id");--> statement-breakpoint
CREATE INDEX "apic_org_idx" ON "api_clients" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "apit_client_idx" ON "api_tokens" USING btree ("client_id");--> statement-breakpoint
CREATE INDEX "apit_user_idx" ON "api_tokens" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "apit_expires_idx" ON "api_tokens" USING btree ("expires_at");--> statement-breakpoint
CREATE INDEX "iconn_org_idx" ON "integration_connections" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "iconn_prov_idx" ON "integration_connections" USING btree ("provider_id");--> statement-breakpoint
CREATE INDEX "ilog_prov_idx" ON "integration_logs" USING btree ("provider_id");--> statement-breakpoint
CREATE INDEX "ilog_conn_idx" ON "integration_logs" USING btree ("connection_id");--> statement-breakpoint
CREATE INDEX "ilog_op_idx" ON "integration_logs" USING btree ("operation");--> statement-breakpoint
CREATE INDEX "ilog_created_idx" ON "integration_logs" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "iprov_name_idx" ON "integration_providers" USING btree ("provider_name");--> statement-breakpoint
CREATE INDEX "iprov_org_idx" ON "integration_providers" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "phook_plug_idx" ON "plugin_hooks" USING btree ("plugin_id");--> statement-breakpoint
CREATE INDEX "phook_name_idx" ON "plugin_hooks" USING btree ("hook_name");--> statement-breakpoint
CREATE INDEX "pver_plug_idx" ON "plugin_versions" USING btree ("plugin_id");--> statement-breakpoint
CREATE INDEX "plugver_version_idx" ON "plugin_versions" USING btree ("version");--> statement-breakpoint
CREATE INDEX "plug_org_idx" ON "plugins" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "plug_slug_idx" ON "plugins" USING btree ("plugin_slug");--> statement-breakpoint
CREATE INDEX "plug_status_idx" ON "plugins" USING btree ("status");--> statement-breakpoint
CREATE INDEX "whd_wh_idx" ON "webhook_deliveries" USING btree ("webhook_id");--> statement-breakpoint
CREATE INDEX "whd_event_idx" ON "webhook_deliveries" USING btree ("event_name");--> statement-breakpoint
CREATE INDEX "whd_status_idx" ON "webhook_deliveries" USING btree ("status");--> statement-breakpoint
CREATE INDEX "wh_org_idx" ON "webhooks" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "wh_enabled_idx" ON "webhooks" USING btree ("enabled");