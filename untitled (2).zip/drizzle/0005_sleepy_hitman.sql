CREATE TABLE "backup_archives" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"backup_job_id" uuid NOT NULL,
	"archive_name" varchar(255) NOT NULL,
	"archive_checksum" varchar(255),
	"storage_object_id" varchar(255),
	"retention_until" timestamp with time zone,
	"verified" boolean DEFAULT false,
	"verified_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "backup_jobs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"backup_type" varchar(50),
	"storage_provider" varchar(100),
	"backup_location" text,
	"backup_size" integer,
	"compression_enabled" boolean DEFAULT false,
	"encryption_enabled" boolean DEFAULT false,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"verification_status" varchar(50),
	"status" varchar(30) DEFAULT 'PENDING',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "compliance_frameworks" (
	"id" uuid PRIMARY KEY NOT NULL,
	"framework_name" varchar(255) NOT NULL,
	"framework_code" varchar(100) NOT NULL,
	"framework_version" varchar(50),
	"description" text,
	"requirements" jsonb DEFAULT '{}'::jsonb,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "compliance_frameworks_framework_code_unique" UNIQUE("framework_code")
);
--> statement-breakpoint
CREATE TABLE "data_retention_policies" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"resource_type" varchar(100),
	"retention_days" integer,
	"archive_after_days" integer,
	"delete_after_days" integer,
	"legal_hold" boolean DEFAULT false,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "encryption_keys" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"key_name" varchar(255) NOT NULL,
	"key_type" varchar(100),
	"key_provider" varchar(100),
	"key_version" varchar(50),
	"rotation_interval_days" integer,
	"last_rotated_at" timestamp with time zone,
	"next_rotation_at" timestamp with time zone,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ip_allowlists" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"cidr_block" varchar(50) NOT NULL,
	"description" text,
	"enabled" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "organization_compliance" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"framework_id" uuid NOT NULL,
	"compliance_status" varchar(50),
	"last_audit" timestamp with time zone,
	"next_audit" timestamp with time zone,
	"score" integer,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "restore_jobs" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"backup_archive_id" uuid NOT NULL,
	"restore_type" varchar(50),
	"requested_by" uuid,
	"approved_by" uuid,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"restore_status" varchar(50),
	"validation_report" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "security_incidents" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"incident_type" varchar(100),
	"severity" varchar(50),
	"title" varchar(255),
	"description" text,
	"detected_at" timestamp with time zone,
	"resolved_at" timestamp with time zone,
	"assigned_to" uuid,
	"resolution_notes" text,
	"status" varchar(30) DEFAULT 'OPEN',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "security_policies" (
	"id" uuid PRIMARY KEY NOT NULL,
	"organization_id" uuid NOT NULL,
	"policy_name" varchar(255) NOT NULL,
	"policy_code" varchar(100) NOT NULL,
	"policy_category" varchar(100),
	"description" text,
	"policy_definition" jsonb DEFAULT '{}'::jsonb,
	"enforcement_mode" varchar(50),
	"priority" integer DEFAULT 0,
	"enabled" boolean DEFAULT true,
	"version" integer DEFAULT 1,
	"status" varchar(30) DEFAULT 'ACTIVE',
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"deleted_at" timestamp with time zone,
	"created_by" uuid,
	"updated_by" uuid,
	CONSTRAINT "security_policies_policy_code_unique" UNIQUE("policy_code")
);
--> statement-breakpoint
ALTER TABLE "backup_archives" ADD CONSTRAINT "backup_archives_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "backup_archives" ADD CONSTRAINT "backup_archives_backup_job_id_backup_jobs_id_fk" FOREIGN KEY ("backup_job_id") REFERENCES "public"."backup_jobs"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "backup_jobs" ADD CONSTRAINT "backup_jobs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "data_retention_policies" ADD CONSTRAINT "data_retention_policies_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "encryption_keys" ADD CONSTRAINT "encryption_keys_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ip_allowlists" ADD CONSTRAINT "ip_allowlists_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_compliance" ADD CONSTRAINT "organization_compliance_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_compliance" ADD CONSTRAINT "organization_compliance_framework_id_compliance_frameworks_id_fk" FOREIGN KEY ("framework_id") REFERENCES "public"."compliance_frameworks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "restore_jobs" ADD CONSTRAINT "restore_jobs_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "restore_jobs" ADD CONSTRAINT "restore_jobs_backup_archive_id_backup_archives_id_fk" FOREIGN KEY ("backup_archive_id") REFERENCES "public"."backup_archives"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "restore_jobs" ADD CONSTRAINT "restore_jobs_requested_by_users_id_fk" FOREIGN KEY ("requested_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "restore_jobs" ADD CONSTRAINT "restore_jobs_approved_by_users_id_fk" FOREIGN KEY ("approved_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "security_incidents" ADD CONSTRAINT "security_incidents_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "security_incidents" ADD CONSTRAINT "security_incidents_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "security_policies" ADD CONSTRAINT "security_policies_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "barch_org_idx" ON "backup_archives" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "barch_job_idx" ON "backup_archives" USING btree ("backup_job_id");--> statement-breakpoint
CREATE INDEX "bjob_org_idx" ON "backup_jobs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "bjob_type_idx" ON "backup_jobs" USING btree ("backup_type");--> statement-breakpoint
CREATE INDEX "bjob_status_idx" ON "backup_jobs" USING btree ("status");--> statement-breakpoint
CREATE INDEX "cfwk_code_idx" ON "compliance_frameworks" USING btree ("framework_code");--> statement-breakpoint
CREATE INDEX "drp_org_idx" ON "data_retention_policies" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "drp_res_idx" ON "data_retention_policies" USING btree ("resource_type");--> statement-breakpoint
CREATE INDEX "ekey_org_idx" ON "encryption_keys" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "ekey_name_idx" ON "encryption_keys" USING btree ("key_name");--> statement-breakpoint
CREATE INDEX "ipa_org_idx" ON "ip_allowlists" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "ipa_cidr_idx" ON "ip_allowlists" USING btree ("cidr_block");--> statement-breakpoint
CREATE INDEX "ocomp_org_idx" ON "organization_compliance" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "ocomp_fwk_idx" ON "organization_compliance" USING btree ("framework_id");--> statement-breakpoint
CREATE INDEX "rjob_org_idx" ON "restore_jobs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "rjob_status_idx" ON "restore_jobs" USING btree ("restore_status");--> statement-breakpoint
CREATE INDEX "sinc_org_idx" ON "security_incidents" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "sinc_sev_idx" ON "security_incidents" USING btree ("severity");--> statement-breakpoint
CREATE INDEX "sinc_status_idx" ON "security_incidents" USING btree ("status");--> statement-breakpoint
CREATE INDEX "spol_org_idx" ON "security_policies" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "spol_code_idx" ON "security_policies" USING btree ("policy_code");