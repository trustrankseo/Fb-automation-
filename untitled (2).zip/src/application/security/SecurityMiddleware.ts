import { jwtManager } from '../../domain/security/JWTManager';
import { rbacEngine, Permission } from '../../domain/security/RBACEngine';
import { PermissionException } from '../../domain/exceptions/BusinessException';

export const SecurityMiddleware = {
  
  authenticate: async (req: any, res: any, next: any) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or invalid token' });
      }
      
      const token = authHeader.split(' ')[1];
      const payload = await jwtManager.verify(token);
      
      req.user = payload;
      next();
    } catch (error) {
      console.error('Authentication failed:', error);
      res.status(401).json({ error: 'Authentication failed' });
    }
  },

  requirePermission: (permission: Permission) => {
    return async (req: any, res: any, next: any) => {
      try {
        if (!req.user) {
          throw new PermissionException('Not authenticated');
        }
        
        const hasPermission = rbacEngine.hasPermission(req.user.roles || [], permission);
        
        if (!hasPermission) {
          throw new PermissionException(`Missing required permission: ${permission}`);
        }
        
        next();
      } catch (error: any) {
        if (error instanceof PermissionException) {
          res.status(error.statusCode).json({ error: error.message });
        } else {
          res.status(500).json({ error: 'Authorization error' });
        }
      }
    };
  }
};
