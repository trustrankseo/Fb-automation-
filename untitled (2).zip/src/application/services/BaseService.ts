import { UnitOfWork } from '../../db/uow';
import { EventDispatcher, DomainEvent } from '../../domain/events/EventDispatcher';
import { BusinessException } from '../../domain/exceptions/BusinessException';

export abstract class BaseService {
  constructor(
    protected readonly uow: UnitOfWork,
    protected readonly eventDispatcher: EventDispatcher
  ) {}

  protected async executeInTransaction<T>(
    operationName: string,
    operation: (tx: any) => Promise<T>,
    eventsToDispatch: DomainEvent[] = []
  ): Promise<T> {
    try {
      const result = await this.uow.transaction(async (tx) => {
        return await operation(tx);
      });

      // Dispatch events after successful transaction commit
      for (const event of eventsToDispatch) {
        await this.eventDispatcher.dispatch(event);
      }

      return result;
    } catch (error: any) {
      console.error(`[BaseService] Operation ${operationName} failed:`, error);
      if (error instanceof BusinessException) {
        throw error;
      }
      throw new BusinessException('Internal service error', 'INTERNAL_ERROR', 500);
    }
  }
}
