
import { workerManager } from '../../domain/background/workers/WorkerManager';

export const registerDefaultWorkers = () => {
  workerManager.registerWorker('email.send', async (job) => {
    console.log(`Sending email to ${job.payload.to}`);
    // Implement email sending
  });

  workerManager.registerWorker('image.process', async (job) => {
    console.log(`Processing image ${job.payload.imageId}`);
    // Implement image processing
  });

  workerManager.registerWorker('ai.generate', async (job) => {
    console.log(`Running AI task ${job.payload.taskId}`);
    // Implement AI async processing
  });

  workerManager.start();
};
