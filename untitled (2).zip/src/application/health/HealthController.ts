
export class HealthController {
  
  async getLiveness(): Promise<any> {
    // Basic check to see if the app process is running
    return {
      status: 'UP',
      timestamp: new Date().toISOString(),
      uptime: process.uptime()
    };
  }

  async getReadiness(checkDependencies: () => Promise<boolean>): Promise<any> {
    // Check if app is ready to receive traffic (e.g., DB connected, Cache connected)
    try {
      const isReady = await checkDependencies();
      if (isReady) {
        return {
          status: 'READY',
          timestamp: new Date().toISOString()
        };
      }
    } catch (e) {
      // Intentionally fall through to DOWN status
    }
    
    return {
      status: 'DOWN',
      timestamp: new Date().toISOString()
    };
  }
}

export const healthController = new HealthController();
