import { ValidationException } from '../../domain/exceptions/BusinessException';

export abstract class BaseValidator<T> {
  abstract validate(data: T): Record<string, string[]>;

  async validateAndThrow(data: T): Promise<void> {
    const errors = this.validate(data);
    if (Object.keys(errors).length > 0) {
      throw new ValidationException(errors);
    }
  }
}
