import { ThemeProvider } from "./providers/ThemeProvider";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MainLayout } from "./components/layout/MainLayout";
import { Dashboard } from "./features/dashboard/Dashboard";
import { OrganizationsList } from "./features/organizations/OrganizationsList";
import { ProjectsList } from "./features/projects/ProjectsList";
import { SourcesList } from "./features/sources/SourcesList";
import { PublishingList } from "./features/publishing/PublishingList";
import { UsersList } from "./features/users/UsersList";
import { JobsList } from "./features/jobs/JobsList";
import { Settings } from "./features/settings/Settings";
import { NotFound } from "./components/layout/NotFound";

import { AuthLayout } from "./components/layout/AuthLayout";
import { Login } from "./features/auth/Login";
import { Register } from "./features/auth/Register";
import { ForgotPassword } from "./features/auth/ForgotPassword";
import { SettingsLayout } from "./components/layout/SettingsLayout";
import { GeneralSettings } from "./features/settings/GeneralSettings";

import { ProfileSettings } from "./features/settings/ProfileSettings";
import { SecuritySettings } from "./features/settings/SecuritySettings";
import { ApiKeysSettings } from "./features/settings/ApiKeysSettings";
import { OrganizationSettings } from "./features/settings/OrganizationSettings";
import { BillingSettings } from "./features/settings/BillingSettings";
import { AppearanceSettings } from "./features/settings/AppearanceSettings";

import { AdminLayout } from "./components/layout/AdminLayout";
import { AdminDashboard } from "./features/admin/AdminDashboard";

import { WorkspaceHome } from "./features/workspace/WorkspaceHome";
import { ProjectDashboard } from "./features/project/ProjectDashboard";
import { FileManager } from "./features/file-manager/FileManager";
import { StorageDashboard } from "./features/storage/StorageDashboard";
import { DownloadCenter } from "./features/download-center/DownloadCenter";

import { AiCenterHome } from "./features/ai-center/AiCenterHome";
import { AiChat } from "./features/ai-chat/AiChat";
import { PromptStudio } from "./features/prompt-studio/PromptStudio";
import { KnowledgeBase } from "./features/knowledge-base/KnowledgeBase";
import { WorkflowBuilder } from "./features/workflows/WorkflowBuilder";
import { AgentBuilder } from "./features/agents/AgentBuilder";
import { AutomationCenter } from "./features/automation/AutomationCenter";
import { AiAnalytics } from "./features/ai-analytics/AiAnalytics";

import { AnalyticsDashboard } from "./features/analytics/AnalyticsDashboard";
import { ReportCenter } from "./features/reports/ReportCenter";
import { NotificationCenter } from "./features/notifications/NotificationCenter";
import { SystemMonitoring } from "./features/admin/SystemMonitoring";
import { AuditLogViewer } from "./features/admin/AuditLogViewer";





const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system" storageKey="emcas-theme">
      <BrowserRouter>
        
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          
          <Route path="/auth" element={<AuthLayout />}>
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="forgot-password" element={<ForgotPassword />} />
          </Route>

          
          <Route path="/admin" element={<AdminLayout />}>
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="monitoring" element={<SystemMonitoring />} />
            <Route path="audit" element={<AuditLogViewer />} />
            <Route path="*" element={<AdminDashboard />} />
          </Route>


          
          <Route path="/settings" element={<SettingsLayout />}>
            <Route path="general" element={<GeneralSettings />} />
            <Route path="profile" element={<ProfileSettings />} />
            <Route path="security" element={<SecuritySettings />} />
            <Route path="api-keys" element={<ApiKeysSettings />} />
            <Route path="organization" element={<OrganizationSettings />} />
            <Route path="billing" element={<BillingSettings />} />
            <Route path="appearance" element={<AppearanceSettings />} />
            <Route path="*" element={<GeneralSettings />} />
          </Route>


          <Route path="/" element={<MainLayout />}>
            
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="workspace" element={<WorkspaceHome />} />
            <Route path="project/:id" element={<ProjectDashboard />} />
            <Route path="files" element={<FileManager />} />
            
            <Route path="storage" element={<StorageDashboard />} />
            <Route path="downloads" element={<DownloadCenter />} />
            
            <Route path="ai-center" element={<AiCenterHome />} />
            <Route path="chat" element={<AiChat />} />
            <Route path="prompts" element={<PromptStudio />} />
            <Route path="knowledge" element={<KnowledgeBase />} />
            <Route path="workflows" element={<WorkflowBuilder />} />
            <Route path="agents" element={<AgentBuilder />} />
            <Route path="automation" element={<AutomationCenter />} />
            
            <Route path="ai-analytics" element={<AiAnalytics />} />
            
            <Route path="analytics" element={<AnalyticsDashboard />} />
            <Route path="reports" element={<ReportCenter />} />
            <Route path="notifications" element={<NotificationCenter />} />



            <Route path="organizations" element={<OrganizationsList />} />
            <Route path="projects" element={<ProjectsList />} />
            <Route path="sources" element={<SourcesList />} />
            <Route path="publishing" element={<PublishingList />} />
            <Route path="users" element={<UsersList />} />
            <Route path="jobs" element={<JobsList />} />
            {/* Future routes */}
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>

      </BrowserRouter>
          </ThemeProvider>
    </QueryClientProvider>
  );
}
