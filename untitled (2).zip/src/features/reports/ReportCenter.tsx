import React from 'react';
import { FileText, Plus, Search, Filter, Download, MoreVertical, LayoutTemplate } from 'lucide-react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";

export function ReportCenter() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Report Center</h2>
          <p className="text-muted-foreground mt-1">Generate, schedule, and manage custom reports.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Report
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3 mb-6">
        {['AI Usage Overview', 'Monthly Billing Summary', 'Security Audit Trail'].map((t, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-4 shadow-sm hover:border-primary/50 cursor-pointer transition-colors">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <LayoutTemplate className="w-4 h-4" />
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="w-4 h-4" /></Button>
            </div>
            <h3 className="font-semibold">{t}</h3>
            <p className="text-xs text-muted-foreground mt-1">Scheduled: Weekly</p>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border flex items-center justify-between bg-background">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9 w-[300px]" placeholder="Search reports..." />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <Filter className="w-4 h-4" /> Filter
            </Button>
          </div>
        </div>
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              <th className="px-6 py-3 font-medium">Report Name</th>
              <th className="px-6 py-3 font-medium">Type</th>
              <th className="px-6 py-3 font-medium">Generated On</th>
              <th className="px-6 py-3 font-medium">Created By</th>
              <th className="px-6 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {[1, 2, 3, 4, 5].map((i) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4 flex items-center gap-3">
                  <FileText className="w-4 h-4 text-primary" />
                  <span className="font-medium">Q3_Financial_Summary_v{i}</span>
                </td>
                <td className="px-6 py-4 text-muted-foreground">Financial</td>
                <td className="px-6 py-4 text-muted-foreground">Oct 24, 2026</td>
                <td className="px-6 py-4 text-muted-foreground">System</td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                   <Button variant="ghost" size="icon" className="h-8 w-8"><Download className="w-4 h-4" /></Button>
                   <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
