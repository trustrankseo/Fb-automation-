import React from 'react';
import { HardDrive, Server, Cloud, Database } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function StorageDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Storage Management</h2>
          <p className="text-muted-foreground mt-1">Monitor your organization's storage usage and limits.</p>
        </div>
        <Button>Upgrade Storage</Button>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-6">Total Storage</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-medium">4.2 TB Used</span>
            <span className="text-muted-foreground">10 TB Total</span>
          </div>
          <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-primary" style={{ width: '42%' }}></div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
          {[
            { label: 'Images', value: '1.2 TB', color: 'bg-blue-500' },
            { label: 'Videos', value: '2.4 TB', color: 'bg-purple-500' },
            { label: 'Documents', value: '0.4 TB', color: 'bg-emerald-500' },
            { label: 'Other', value: '0.2 TB', color: 'bg-amber-500' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${item.color}`} />
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
