import React from 'react';
import { Bell, CheckCircle, AlertTriangle, Info, Clock, CheckCircle2, Search, Filter } from 'lucide-react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";

export function NotificationCenter() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Notification Center</h2>
          <p className="text-muted-foreground mt-1">Review your alerts and system messages.</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" /> Mark All as Read
        </Button>
      </div>

      <div className="flex gap-4 border-b border-border mb-6">
        <button className="px-4 py-2 border-b-2 border-primary text-sm font-medium text-foreground">All Notifications</button>
        <button className="px-4 py-2 border-b-2 border-transparent text-sm font-medium text-muted-foreground hover:text-foreground">Unread (3)</button>
        <button className="px-4 py-2 border-b-2 border-transparent text-sm font-medium text-muted-foreground hover:text-foreground">System Alerts</button>
      </div>

      <div className="flex items-center justify-between mb-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9 w-[300px]" placeholder="Search notifications..." />
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Filter className="w-4 h-4" /> Filter
          </Button>
      </div>

      <div className="space-y-4">
        {[
          { title: 'Deployment Successful', desc: 'Project Alpha has been successfully deployed to production.', icon: CheckCircle, color: 'text-emerald-500', time: '10m ago', unread: true },
          { title: 'High CPU Usage Detected', desc: 'Worker node-abc-123 is experiencing sustained high CPU load.', icon: AlertTriangle, color: 'text-amber-500', time: '1h ago', unread: true },
          { title: 'New Team Member', desc: 'Sarah Smith has joined your workspace.', icon: Info, color: 'text-blue-500', time: '2h ago', unread: true },
          { title: 'Database Backup Completed', desc: 'Automated backup completed successfully.', icon: CheckCircle, color: 'text-emerald-500', time: 'Yesterday', unread: false },
          { title: 'Billing Update', desc: 'Your invoice for October is now available.', icon: Info, color: 'text-blue-500', time: '2 days ago', unread: false },
        ].map((notif, i) => (
          <div key={i} className={`p-4 rounded-xl border ${notif.unread ? 'border-primary/50 bg-primary/5' : 'border-border bg-card'} shadow-sm flex items-start gap-4 transition-colors`}>
            <div className={`mt-1 ${notif.color}`}>
              <notif.icon className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <h4 className={`text-sm font-semibold ${notif.unread ? 'text-foreground' : 'text-muted-foreground'}`}>{notif.title}</h4>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {notif.time}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{notif.desc}</p>
            </div>
            {notif.unread && <div className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0"></div>}
          </div>
        ))}
      </div>
    </div>
  );
}
