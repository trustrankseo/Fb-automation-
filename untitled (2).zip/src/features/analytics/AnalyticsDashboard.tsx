import React from 'react';
import { BarChart3, TrendingUp, Users, HardDrive, Activity, DollarSign, Calendar } from 'lucide-react';
import { Button } from "../../components/ui/Button";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

const data = [
  { name: 'Mon', usage: 4000, cost: 2400 },
  { name: 'Tue', usage: 3000, cost: 1398 },
  { name: 'Wed', usage: 2000, cost: 9800 },
  { name: 'Thu', usage: 2780, cost: 3908 },
  { name: 'Fri', usage: 1890, cost: 4800 },
  { name: 'Sat', usage: 2390, cost: 3800 },
  { name: 'Sun', usage: 3490, cost: 4300 },
];

export function AnalyticsDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Executive Analytics</h2>
          <p className="text-muted-foreground mt-1">Real-time insights across your organization.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" /> Last 7 Days
          </Button>
          <Button>Export Report</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Total Revenue', icon: DollarSign, value: '$45,231.89', trend: '+20.1%' },
          { label: 'Active Users', icon: Users, value: '2350', trend: '+180.1%' },
          { label: 'Storage Used', icon: HardDrive, value: '12.5 TB', trend: '+19%' },
          { label: 'System Health', icon: Activity, value: '99.9%', trend: '+0.1%' },
        ].map((stat, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 shadow-sm flex flex-col gap-2">
             <div className="flex items-center justify-between">
               <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
               <stat.icon className="w-4 h-4 text-muted-foreground" />
             </div>
             <div>
               <h3 className="text-2xl font-bold">{stat.value}</h3>
               <p className="text-xs text-emerald-500 mt-1 flex items-center gap-1">
                 <TrendingUp className="w-3 h-3" /> {stat.trend} from last month
               </p>
             </div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Resource Usage Trends</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
                <Tooltip />
                <Area type="monotone" dataKey="usage" stroke="#3b82f6" fillOpacity={1} fill="url(#colorUsage)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Cost Analysis</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                <Tooltip />
                <Bar dataKey="cost" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
