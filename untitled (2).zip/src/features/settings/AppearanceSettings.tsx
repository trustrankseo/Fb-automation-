import React from 'react';
import { Button } from "../../components/ui/Button";
import { Monitor, Sun, Moon } from 'lucide-react';

export function AppearanceSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Appearance</h2>
        <p className="text-muted-foreground">Customize the UI theme and interface density.</p>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-4">Theme Preference</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border-2 border-primary rounded-xl p-4 cursor-pointer relative bg-card shadow-sm">
              <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-primary-foreground rounded-full"></div>
              </div>
              <Monitor className="w-8 h-8 mb-2 text-primary" />
              <h4 className="font-medium">System</h4>
              <p className="text-xs text-muted-foreground mt-1">Syncs with your OS</p>
            </div>
            <div className="border border-border rounded-xl p-4 cursor-pointer hover:border-primary/50 transition-colors bg-card shadow-sm">
              <Sun className="w-8 h-8 mb-2 text-muted-foreground" />
              <h4 className="font-medium">Light</h4>
              <p className="text-xs text-muted-foreground mt-1">Light UI components</p>
            </div>
            <div className="border border-border rounded-xl p-4 cursor-pointer hover:border-primary/50 transition-colors bg-card shadow-sm">
              <Moon className="w-8 h-8 mb-2 text-muted-foreground" />
              <h4 className="font-medium">Dark</h4>
              <p className="text-xs text-muted-foreground mt-1">Dark UI components</p>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-border">
          <h3 className="text-lg font-semibold mb-4">Interface Density</h3>
          <div className="grid gap-2 border-b border-border pb-6">
            <select className="flex h-10 w-full md:w-[400px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
              <option>Comfortable (Default)</option>
              <option>Compact</option>
              <option>Spacious</option>
            </select>
            <p className="text-xs text-muted-foreground mt-1">Adjusts the spacing and padding across tables and lists.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
