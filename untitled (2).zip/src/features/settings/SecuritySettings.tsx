import React from 'react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import { Shield, Key, Smartphone, Laptop, AlertCircle } from 'lucide-react';

export function SecuritySettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Security Center</h2>
        <p className="text-muted-foreground">Manage your account security and active sessions.</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><Shield className="w-5 h-5 text-emerald-500" /> Multi-Factor Authentication</h3>
        <p className="text-sm text-muted-foreground mb-4">Add an extra layer of security to your account.</p>
        <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-secondary/20">
          <div>
            <p className="font-medium">Authenticator App</p>
            <p className="text-sm text-muted-foreground">Use an app like Google Authenticator or Authy to generate verification codes.</p>
          </div>
          <Button variant="outline">Configure</Button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><Key className="w-5 h-5" /> Change Password</h3>
        <form className="space-y-4 max-w-md" onSubmit={(e) => e.preventDefault()}>
          <div className="grid gap-2">
            <label className="text-sm font-medium">Current Password</label>
            <Input type="password" />
          </div>
          <div className="grid gap-2">
            <label className="text-sm font-medium">New Password</label>
            <Input type="password" />
          </div>
          <div className="grid gap-2">
            <label className="text-sm font-medium">Confirm New Password</label>
            <Input type="password" />
          </div>
          <Button type="submit">Update Password</Button>
        </form>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Active Sessions</h3>
          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">Terminate All</Button>
        </div>
        <div className="space-y-4">
          <div className="flex items-start gap-4 p-4 border border-border rounded-lg">
            <Laptop className="w-6 h-6 mt-1" />
            <div className="flex-1">
              <p className="font-medium">Mac OS • Chrome <span className="text-xs text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full ml-2">Current</span></p>
              <p className="text-sm text-muted-foreground">San Francisco, US • 192.168.1.1</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 border border-border rounded-lg">
            <Smartphone className="w-6 h-6 mt-1" />
            <div className="flex-1">
              <p className="font-medium">iOS • Safari</p>
              <p className="text-sm text-muted-foreground">San Francisco, US • 10.0.0.14</p>
              <p className="text-xs text-muted-foreground mt-1">Last active: 2 hours ago</p>
            </div>
            <Button variant="ghost" size="sm">Revoke</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
