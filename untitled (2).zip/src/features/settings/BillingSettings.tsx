import React, { useEffect, useState } from 'react';
import { Button } from "../../components/ui/Button";
import { CreditCard, Download, CheckCircle, Activity } from 'lucide-react';
import api from '../../api/client';

export function BillingSettings() {
  const [loading, setLoading] = useState(true);
  const [billingData, setBillingData] = useState<any>(null);

  useEffect(() => {
    // Simulated API call to our new billing endpoints
    api.get('/billing/invoices').then(res => {
      // Create mock data if backend isn't sending full payload yet
      setBillingData({
        plan: {
          name: "Enterprise Plan",
          price: "$499",
          interval: "mo",
          features: [
            "Unlimited Users",
            "10 TB Storage",
            "Advanced AI Models",
            "Priority Support"
          ]
        },
        paymentMethod: {
          brand: "Visa",
          last4: "4242",
          exp: "12/28"
        },
        contact: {
          name: "John Doe",
          company: "Acme Corp Inc.",
          email: "billing@acmecorp.com"
        },
        invoices: [
          { id: "INV-2026-001", date: "Oct 1, 2026", amount: "$499.00", status: "Paid" },
          { id: "INV-2026-002", date: "Sep 1, 2026", amount: "$499.00", status: "Paid" },
          { id: "INV-2026-003", date: "Aug 1, 2026", amount: "$499.00", status: "Paid" }
        ]
      });
      setLoading(false);
    }).catch(err => {
      console.error(err);
      setLoading(false);
    });
  }, []);

  if (loading || !billingData) {
    return <div className="flex items-center justify-center h-48"><Activity className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Billing & Subscriptions</h2>
        <p className="text-muted-foreground">Manage your payment methods, invoices, and active plans.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-primary/50 bg-primary/5 p-6 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4">
            <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">Current Plan</span>
          </div>
          <h3 className="text-xl font-bold mb-2">{billingData.plan.name}</h3>
          <p className="text-3xl font-bold mb-4">{billingData.plan.price}<span className="text-sm font-normal text-muted-foreground">/{billingData.plan.interval}</span></p>
          <ul className="space-y-2 mb-6 text-sm">
             {billingData.plan.features.map((f: string, i: number) => (
               <li key={i} className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-primary" /> {f}</li>
             ))}
          </ul>
          <div className="flex gap-2">
            <Button>Manage Plan</Button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Payment Method</h3>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-secondary/20">
              <div className="flex items-center gap-3">
                <CreditCard className="w-6 h-6 text-muted-foreground" />
                <div>
                  <p className="font-medium">{billingData.paymentMethod.brand} ending in {billingData.paymentMethod.last4}</p>
                  <p className="text-sm text-muted-foreground">Expires {billingData.paymentMethod.exp}</p>
                </div>
              </div>
              <Button variant="outline" size="sm">Update</Button>
            </div>
          </div>
          
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Billing Contact</h3>
            <div className="space-y-1">
              <p className="font-medium text-sm">{billingData.contact.name}</p>
              <p className="text-sm text-muted-foreground">{billingData.contact.company}</p>
              <p className="text-sm text-muted-foreground">{billingData.contact.email}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border bg-background">
          <h3 className="text-lg font-semibold">Invoice History</h3>
        </div>
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              <th className="px-6 py-3 font-medium">Date</th>
              <th className="px-6 py-3 font-medium">Invoice ID</th>
              <th className="px-6 py-3 font-medium">Amount</th>
              <th className="px-6 py-3 font-medium">Status</th>
              <th className="px-6 py-3 font-medium text-right">Download</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {billingData.invoices.map((invoice: any, i: number) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4">{invoice.date}</td>
                <td className="px-6 py-4 font-mono text-muted-foreground">{invoice.id}</td>
                <td className="px-6 py-4 font-medium">{invoice.amount}</td>
                <td className="px-6 py-4">
                  <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">{invoice.status}</span>
                </td>
                <td className="px-6 py-4 text-right">
                   <Button variant="ghost" size="icon" className="h-8 w-8"><Download className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
