import React from 'react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";

export function GeneralSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">General Settings</h2>
        <p className="text-muted-foreground">Manage your account preferences and defaults.</p>
      </div>
      <div className="space-y-6">
        <div className="grid gap-2 border-b border-border pb-6">
          <label className="text-sm font-medium">Timezone</label>
          <select className="flex h-10 w-full md:w-[400px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
            <option>Pacific Time (PT)</option>
            <option>Eastern Time (ET)</option>
            <option>Coordinated Universal Time (UTC)</option>
          </select>
        </div>
        <div className="grid gap-2 border-b border-border pb-6">
          <label className="text-sm font-medium">Language</label>
          <select className="flex h-10 w-full md:w-[400px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
            <option>English (US)</option>
            <option>Spanish</option>
            <option>French</option>
          </select>
        </div>
        <div className="grid gap-2 pb-6">
          <label className="text-sm font-medium">Date Format</label>
          <select className="flex h-10 w-full md:w-[400px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
            <option>MM/DD/YYYY</option>
            <option>DD/MM/YYYY</option>
            <option>YYYY-MM-DD</option>
          </select>
        </div>
        <Button>Save Preferences</Button>
      </div>
    </div>
  );
}
