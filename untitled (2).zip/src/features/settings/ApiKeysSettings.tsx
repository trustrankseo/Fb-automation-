import React from 'react';
import { Button } from "../../components/ui/Button";
import { Plus, Key, Copy, MoreVertical, Trash } from 'lucide-react';

export function ApiKeysSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">API Keys</h2>
          <p className="text-muted-foreground">Manage API keys for external access to your workspace.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create API Key
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              <th className="px-6 py-3 font-medium">Name</th>
              <th className="px-6 py-3 font-medium">Key Prefix</th>
              <th className="px-6 py-3 font-medium">Created</th>
              <th className="px-6 py-3 font-medium">Last Used</th>
              <th className="px-6 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {[1, 2].map((i) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4 font-medium flex items-center gap-2">
                  <Key className="w-4 h-4 text-muted-foreground" /> {i === 1 ? 'Production Access' : 'Development Testing'}
                </td>
                <td className="px-6 py-4 font-mono text-muted-foreground">emc_{i === 1 ? 'prod' : 'dev'}_...</td>
                <td className="px-6 py-4 text-muted-foreground">Oct 24, 2026</td>
                <td className="px-6 py-4 text-muted-foreground">{i === 1 ? '2 hours ago' : 'Never'}</td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                   <Button variant="ghost" size="icon" className="h-8 w-8"><Copy className="w-4 h-4" /></Button>
                   <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"><Trash className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
