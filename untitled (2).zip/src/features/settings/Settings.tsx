import { Settings as SettingsIcon, Shield, Bell, Key, Database } from "lucide-react";

export function Settings() {
  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Platform Settings</h2>
        <p className="text-muted-foreground mt-1 text-sm">
          Manage your organization, security, and integration preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <div className="md:col-span-1 space-y-1">
          <button className="w-full flex items-center gap-2 px-3 py-2 bg-secondary text-secondary-foreground rounded-md text-sm font-medium">
            <SettingsIcon className="w-4 h-4" />
            General
          </button>
          <button className="w-full flex items-center gap-2 px-3 py-2 text-muted-foreground hover:bg-secondary/50 rounded-md text-sm font-medium transition-colors">
            <Shield className="w-4 h-4" />
            Security
          </button>
          <button className="w-full flex items-center gap-2 px-3 py-2 text-muted-foreground hover:bg-secondary/50 rounded-md text-sm font-medium transition-colors">
            <Bell className="w-4 h-4" />
            Notifications
          </button>
          <button className="w-full flex items-center gap-2 px-3 py-2 text-muted-foreground hover:bg-secondary/50 rounded-md text-sm font-medium transition-colors">
            <Key className="w-4 h-4" />
            API Keys
          </button>
          <button className="w-full flex items-center gap-2 px-3 py-2 text-muted-foreground hover:bg-secondary/50 rounded-md text-sm font-medium transition-colors">
            <Database className="w-4 h-4" />
            Data & Storage
          </button>
        </div>

        {/* Settings Content */}
        <div className="md:col-span-3 space-y-6">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-medium mb-4">Organization Profile</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Organization Name</label>
                <input 
                  type="text" 
                  placeholder="Enter organization name" 
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Contact Email</label>
                <input 
                  type="email" 
                  placeholder="admin@example.com" 
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:bg-primary/90 transition-colors">
                Save Changes
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-medium mb-1">Danger Zone</h3>
            <p className="text-sm text-muted-foreground mb-4">Irreversible and destructive actions.</p>
            <div className="border border-destructive/20 bg-destructive/5 rounded-md p-4 flex items-center justify-between">
              <div>
                <h4 className="font-medium text-sm text-destructive">Delete Organization</h4>
                <p className="text-xs text-muted-foreground mt-1">Permanently remove your organization and all associated data.</p>
              </div>
              <button className="bg-destructive text-destructive-foreground px-4 py-2 rounded-md font-medium text-sm hover:bg-destructive/90 transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
