import React from 'react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import { User } from 'lucide-react';

export function ProfileSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">User Profile</h2>
        <p className="text-muted-foreground">Manage your public and personal information.</p>
      </div>
      
      <div className="flex items-center gap-6 py-6 border-b border-border">
        <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center border border-border">
          <User className="w-8 h-8 text-muted-foreground" />
        </div>
        <div className="space-y-2">
          <div className="flex gap-2">
            <Button size="sm">Upload Avatar</Button>
            <Button size="sm" variant="outline">Remove</Button>
          </div>
          <p className="text-xs text-muted-foreground">JPG, GIF or PNG. Max size of 2MB.</p>
        </div>
      </div>

      <div className="space-y-6 pt-4">
        <div className="grid gap-2">
          <label className="text-sm font-medium">Display Name</label>
          <Input defaultValue="John Doe" className="md:w-[400px]" />
        </div>
        <div className="grid gap-2">
          <label className="text-sm font-medium">Username</label>
          <Input defaultValue="johndoe" className="md:w-[400px]" />
        </div>
        <div className="grid gap-2">
          <label className="text-sm font-medium">Email Address</label>
          <Input defaultValue="john@example.com" type="email" className="md:w-[400px]" />
        </div>
        <div className="grid gap-2">
          <label className="text-sm font-medium">Bio</label>
          <textarea className="flex min-h-[100px] w-full md:w-[600px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background" defaultValue="Senior Software Engineer at EMCAS." />
        </div>
        <Button>Save Profile</Button>
      </div>
    </div>
  );
}
