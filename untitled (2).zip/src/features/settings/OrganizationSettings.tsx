import React from 'react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import { Building, Globe, Mail } from 'lucide-react';

export function OrganizationSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Organization Settings</h2>
        <p className="text-muted-foreground">Manage your workspace identity and domains.</p>
      </div>

      <div className="flex items-center gap-6 py-6 border-b border-border">
        <div className="w-24 h-24 rounded-xl bg-secondary flex items-center justify-center border border-border">
          <span className="text-2xl font-bold text-muted-foreground font-mono">AC</span>
        </div>
        <div className="space-y-2">
          <div className="flex gap-2">
            <Button size="sm">Upload Logo</Button>
            <Button size="sm" variant="outline">Remove</Button>
          </div>
          <p className="text-xs text-muted-foreground">Preferred size: 256x256px.</p>
        </div>
      </div>

      <div className="space-y-6 pt-4">
        <div className="grid gap-2">
          <label className="text-sm font-medium">Organization Name</label>
          <Input defaultValue="Acme Corp" className="md:w-[400px]" />
        </div>
        <div className="grid gap-2">
          <label className="text-sm font-medium flex items-center gap-2"><Globe className="w-4 h-4" /> Workspace URL</label>
          <div className="flex items-center">
            <span className="bg-secondary px-3 py-2 border border-border border-r-0 rounded-l-md text-sm text-muted-foreground h-10">emcas.app/</span>
            <Input defaultValue="acmecorp" className="rounded-l-none md:w-[325px]" />
          </div>
        </div>
        <div className="grid gap-2">
          <label className="text-sm font-medium flex items-center gap-2"><Mail className="w-4 h-4" /> Allowed Email Domains</label>
          <Input defaultValue="@acmecorp.com" className="md:w-[400px]" placeholder="e.g. @company.com" />
          <p className="text-xs text-muted-foreground">Users with these domains can automatically join.</p>
        </div>
        
        <Button>Save Organization</Button>
      </div>
    </div>
  );
}
