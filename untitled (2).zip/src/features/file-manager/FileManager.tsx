import React, { useState } from 'react';
import { Folder, File as FileIcon, Image, FileText, Download, Trash, MoreVertical, UploadCloud, Search, Plus } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export function FileManager() {
  const [currentFolder, setCurrentFolder] = useState('Root');

  const files = [
    { id: 1, name: 'Marketing Assets', type: 'folder', items: 12, size: '--', updated: '2 days ago' },
    { id: 2, name: 'Q3 Financials', type: 'folder', items: 5, size: '--', updated: '1 week ago' },
    { id: 3, name: 'Project Alpha Requirements.pdf', type: 'pdf', size: '2.4 MB', updated: '3 hours ago' },
    { id: 4, name: 'Brand Guidelines.fig', type: 'design', size: '15 MB', updated: 'Yesterday' },
    { id: 5, name: 'Hero Banner.png', type: 'image', size: '4.1 MB', updated: '2 days ago' }
  ];

  const getIcon = (type: string) => {
    switch(type) {
      case 'folder': return <Folder className="w-5 h-5 text-blue-500 fill-blue-500/20" />;
      case 'pdf': return <FileText className="w-5 h-5 text-red-500" />;
      case 'image': return <Image className="w-5 h-5 text-emerald-500" />;
      default: return <FileIcon className="w-5 h-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 shrink-0">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">File Manager</h2>
          <div className="flex items-center text-sm text-muted-foreground mt-1 gap-2">
            <span className="hover:text-foreground cursor-pointer transition-colors">Workspace</span>
            <span>/</span>
            <span className="font-medium text-foreground">{currentFolder}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Search files..." 
              className="pl-9 pr-4 py-2 border border-input rounded-md text-sm bg-background focus:outline-none focus:ring-1 focus:ring-primary w-full sm:w-64"
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2"><Plus className="w-4 h-4"/> New Folder</Button>
          <Button className="flex items-center gap-2"><UploadCloud className="w-4 h-4"/> Upload</Button>
        </div>
      </div>

      <div className="flex-1 border border-border rounded-xl bg-card overflow-hidden flex flex-col shadow-sm">
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="text-xs text-muted-foreground bg-secondary/30 sticky top-0 z-10">
              <tr>
                <th className="px-6 py-3 font-medium">Name</th>
                <th className="px-6 py-3 font-medium">Size</th>
                <th className="px-6 py-3 font-medium">Last Modified</th>
                <th className="px-6 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {files.map(file => (
                <tr key={file.id} className="hover:bg-secondary/20 transition-colors group cursor-pointer">
                  <td className="px-6 py-4 flex items-center gap-3">
                    {getIcon(file.type)}
                    <span className="font-medium text-foreground">{file.name}</span>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">
                    {file.type === 'folder' ? `${file.items} items` : file.size}
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{file.updated}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {file.type !== 'folder' && (
                        <button className="p-1.5 hover:bg-secondary rounded-md text-muted-foreground transition-colors" title="Download">
                          <Download className="w-4 h-4" />
                        </button>
                      )}
                      <button className="p-1.5 hover:bg-destructive/10 hover:text-destructive rounded-md text-muted-foreground transition-colors" title="Delete">
                        <Trash className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-secondary rounded-md text-muted-foreground transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
