import React, { useEffect, useState } from 'react';
import { Layers, Activity, Users, Database, Zap, HardDrive, CheckCircle, Bell, ArrowRight } from 'lucide-react';
import api from '../../api/client';

const iconMap: Record<string, any> = {
  Layers,
  Activity,
  Users,
  Zap
};

export function Dashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const response = await api.get('/dashboards');
        setData(response.data.data);
      } catch (error) {
        console.error("Failed to fetch dashboard", error);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  if (loading || !data) {
    return <div className="flex items-center justify-center h-full">Loading dashboard...</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground mt-2">Welcome back. Here is what's happening across your organization today.</p>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {data.stats.map((stat: any, i: number) => {
          const Icon = iconMap[stat.icon] || Activity;
          return (
            <div key={i} className="rounded-xl border border-border bg-card p-6 shadow-sm flex items-center gap-4 hover:border-primary/50 transition-colors cursor-default">
              <div className="p-3 bg-secondary rounded-lg text-primary">
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Projects</h3>
            <button className="text-sm text-primary hover:underline flex items-center">View all <ArrowRight className="w-4 h-4 ml-1" /></button>
          </div>
          <div className="space-y-4">
            {data.recentProjects.map((project: any) => (
              <div key={project.id} className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-secondary/20 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-md bg-secondary flex items-center justify-center text-primary font-medium">
                    {project.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium">{project.name}</p>
                    <p className="text-xs text-muted-foreground">Updated {project.updated}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Users className="w-4 h-4" /> {project.members}</span>
                  <span className="flex items-center gap-1"><HardDrive className="w-4 h-4" /> {project.storage}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">System Health</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-2"><Database className="w-4 h-4" /> Database</span>
                <span className={`text-sm font-medium flex items-center gap-1 ${data.health.database === 'Operational' ? 'text-emerald-500' : 'text-amber-500'}`}>
                  <CheckCircle className="w-4 h-4" /> {data.health.database}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-2"><HardDrive className="w-4 h-4" /> Storage</span>
                <span className={`text-sm font-medium flex items-center gap-1 ${data.health.storage === 'Operational' ? 'text-emerald-500' : 'text-amber-500'}`}>
                  <CheckCircle className="w-4 h-4" /> {data.health.storage}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-2"><Activity className="w-4 h-4" /> Queue</span>
                <span className={`text-sm font-medium flex items-center gap-1 ${data.health.queue === 'Operational' ? 'text-emerald-500' : 'text-amber-500'}`}>
                  <CheckCircle className="w-4 h-4" /> {data.health.queue}
                </span>
              </div>
            </div>
          </div>
          
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {data.activities.map((activity: any) => (
                <div key={activity.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <Bell className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-foreground">{activity.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
