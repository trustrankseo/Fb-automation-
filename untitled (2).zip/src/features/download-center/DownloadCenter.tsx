import React from 'react';
import { Download, CheckCircle2, XCircle, Clock, PauseCircle } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function DownloadCenter() {
  const downloads = [
    { name: 'backup_2026_07.zip', size: '4.2 GB', status: 'downloading', progress: 45, speed: '12 MB/s' },
    { name: 'project_assets.tar.gz', size: '850 MB', status: 'completed', progress: 100, speed: '-' },
    { name: 'dataset_v2.csv', size: '12.4 GB', status: 'paused', progress: 12, speed: '-' },
    { name: 'corrupted_file.bin', size: '100 MB', status: 'failed', progress: 0, speed: '-' },
  ];

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'completed': return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      case 'failed': return <XCircle className="w-5 h-5 text-destructive" />;
      case 'paused': return <PauseCircle className="w-5 h-5 text-amber-500" />;
      case 'downloading': return <Download className="w-5 h-5 text-primary animate-bounce" />;
      default: return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Download Center</h2>
          <p className="text-muted-foreground mt-1">Manage active downloads and transfer history.</p>
        </div>
        <Button variant="outline">Clear Completed</Button>
      </div>

      <div className="space-y-4">
        {downloads.map((dl, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-4 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4 flex-1">
              {getStatusIcon(dl.status)}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-medium text-sm">{dl.name}</p>
                  <span className="text-xs text-muted-foreground">{dl.size}</span>
                </div>
                {dl.status === 'downloading' || dl.status === 'paused' ? (
                  <div className="w-full max-w-md h-1.5 bg-secondary rounded-full overflow-hidden flex items-center">
                     <div className="h-full bg-primary" style={{ width: `${dl.progress}%` }}></div>
                  </div>
                ) : null}
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs capitalize text-muted-foreground">{dl.status}</span>
                  {dl.status === 'downloading' && (
                    <span className="text-xs text-muted-foreground">• {dl.speed}</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 ml-4">
              {dl.status === 'downloading' && <Button variant="ghost" size="sm">Pause</Button>}
              {dl.status === 'paused' && <Button variant="ghost" size="sm">Resume</Button>}
              {dl.status === 'failed' && <Button variant="ghost" size="sm">Retry</Button>}
              {(dl.status === 'downloading' || dl.status === 'paused') && <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">Cancel</Button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
