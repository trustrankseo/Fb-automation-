import React from 'react';
import { Folder, Star, Clock, Activity, HardDrive, Download, Bell, Plus } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function WorkspaceHome() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Workspace Overview</h2>
          <p className="text-muted-foreground mt-1">Manage your projects, files, and recent activities.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Project
        </Button>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Recent Projects', icon: Clock, value: '5' },
          { label: 'Favorite Projects', icon: Star, value: '2' },
          { label: 'Storage Used', icon: HardDrive, value: '45%' },
          { label: 'Active Downloads', icon: Download, value: '1' },
        ].map((stat, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <stat.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{stat.label}</span>
            </div>
            <h3 className="text-2xl font-bold">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Recent Files</h3>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors">
                <div className="flex items-center gap-3">
                  <Folder className="w-5 h-5 text-primary" />
                  <div>
                    <p className="font-medium text-sm">Design_Assets_v{i}.zip</p>
                    <p className="text-xs text-muted-foreground">Modified 2 hours ago</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Open</Button>
              </div>
            ))}
          </div>
        </div>
        
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4" /> Recent Activity
          </h3>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex gap-3 items-start">
                <div className="w-2 h-2 rounded-full bg-primary mt-1.5" />
                <div>
                  <p className="text-sm">User uploaded a new file</p>
                  <p className="text-xs text-muted-foreground">10 minutes ago</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
