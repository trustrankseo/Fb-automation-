import React, { useState } from 'react';
import { GitMerge, Play, Save, Settings, PlusCircle, ArrowRight, Activity, Database, Check } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function WorkflowBuilder() {
  const [isSaving, setIsSaving] = useState(false);
  const [isDeployed, setIsDeployed] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
    }, 1000);
  };

  const handleDeploy = () => {
    setIsDeployed(true);
    setTimeout(() => {
      setIsDeployed(false);
    }, 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex items-center justify-between mb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Customer Onboarding Workflow</h2>
          <p className="text-sm text-muted-foreground mt-1">Automated sequence for new enterprise signups.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2"><Settings className="w-4 h-4" /> Configure</Button>
          <Button variant="outline" onClick={handleSave} className="flex items-center gap-2">
            {isSaving ? <span className="animate-spin text-lg leading-none">⟳</span> : <Save className="w-4 h-4" />} 
            {isSaving ? "Saving..." : "Save"}
          </Button>
          <Button onClick={handleDeploy} disabled={isDeployed} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
            {isDeployed ? <span className="animate-spin text-lg leading-none">⟳</span> : <Play className="w-4 h-4" />} 
            {isDeployed ? "Deploying..." : "Deploy"}
          </Button>
        </div>
      </div>
      
      <div className="flex-1 rounded-xl border border-border bg-secondary/5 relative overflow-hidden flex flex-col shadow-inner">
        {/* Pseudo Canvas Grid Background */}
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
        
        {/* Toolbar */}
        <div className="absolute top-4 left-4 bg-card border border-border p-2 rounded-lg shadow-sm z-20 flex flex-col gap-2">
          <button className="p-2 bg-secondary rounded-md text-foreground hover:bg-primary hover:text-primary-foreground transition-colors" title="Triggers">
            <Activity className="w-4 h-4" />
          </button>
          <button className="p-2 bg-secondary rounded-md text-foreground hover:bg-primary hover:text-primary-foreground transition-colors" title="AI Actions">
            <GitMerge className="w-4 h-4" />
          </button>
          <button className="p-2 bg-secondary rounded-md text-foreground hover:bg-primary hover:text-primary-foreground transition-colors" title="Databases">
            <Database className="w-4 h-4" />
          </button>
        </div>

        {/* Pseudo Nodes */}
        <div className="z-10 flex-1 flex items-center justify-center overflow-auto p-12">
          <div className="flex items-center gap-8 min-w-max">
             <div className="w-56 bg-card border-l-4 border-l-blue-500 border border-border rounded-xl p-4 shadow-lg relative cursor-pointer hover:border-primary transition-colors">
               <div className="flex justify-between items-start mb-2">
                 <div className="w-8 h-8 rounded-md bg-blue-500/10 flex items-center justify-center text-blue-500">
                   <Activity className="w-4 h-4" />
                 </div>
                 <span className="text-[10px] font-medium px-2 py-1 bg-secondary rounded text-muted-foreground">Trigger</span>
               </div>
               <h4 className="font-semibold text-sm">Stripe Webhook</h4>
               <p className="text-xs text-muted-foreground mt-1 line-clamp-2">Listens for customer.subscription.created</p>
               <div className="absolute -right-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
             </div>
             
             <ArrowRight className="w-5 h-5 text-muted-foreground" />
             
             <div className="w-56 bg-card border-l-4 border-l-amber-500 border border-border rounded-xl p-4 shadow-lg relative cursor-pointer hover:border-primary transition-colors">
               <div className="flex justify-between items-start mb-2">
                 <div className="w-8 h-8 rounded-md bg-amber-500/10 flex items-center justify-center text-amber-500">
                   <Settings className="w-4 h-4" />
                 </div>
                 <span className="text-[10px] font-medium px-2 py-1 bg-secondary rounded text-muted-foreground">Action</span>
               </div>
               <h4 className="font-semibold text-sm">AI Enrichment</h4>
               <p className="text-xs text-muted-foreground mt-1 line-clamp-2">Extract company details and industry from email domain</p>
               <div className="absolute -left-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
               <div className="absolute -right-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
             </div>

             <ArrowRight className="w-5 h-5 text-muted-foreground" />

             <div className="w-56 bg-card border-l-4 border-l-emerald-500 border border-border rounded-xl p-4 shadow-lg relative cursor-pointer hover:border-primary transition-colors">
               <div className="flex justify-between items-start mb-2">
                 <div className="w-8 h-8 rounded-md bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                   <Database className="w-4 h-4" />
                 </div>
                 <span className="text-[10px] font-medium px-2 py-1 bg-secondary rounded text-muted-foreground">Database</span>
               </div>
               <h4 className="font-semibold text-sm">Upsert CRM Record</h4>
               <p className="text-xs text-muted-foreground mt-1 line-clamp-2">Update Postgres tenant table with enriched data</p>
               <div className="absolute -left-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
               <div className="absolute -right-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
             </div>
             
             <ArrowRight className="w-5 h-5 text-muted-foreground" />
             
             <div className="w-48 bg-card border border-border rounded-xl p-4 shadow-sm text-center relative border-dashed cursor-pointer hover:border-primary hover:bg-secondary/20 transition-all">
               <PlusCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
               <h4 className="font-semibold text-sm text-muted-foreground">Add Action</h4>
               <div className="absolute -left-5 top-1/2 -translate-y-1/2 w-4 h-0.5 bg-border"></div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
