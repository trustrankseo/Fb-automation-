import React from 'react';
import { Users, Server, Shield, Activity, BarChart, Database, ArrowUpRight } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export function AdminDashboard() {
  const metrics = [
    { label: "Total Organizations", value: "45", trend: "+12%", icon: Users },
    { label: "Active Nodes", value: "128", trend: "Stable", icon: Server },
    { label: "Security Events", value: "3", trend: "-50%", icon: Shield, status: "good" },
    { label: "System Load", value: "42%", trend: "+5%", icon: Activity }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Admin Console</h2>
          <p className="text-muted-foreground mt-1">Platform-wide overview and administration.</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <BarChart className="w-4 h-4" /> View Full Report
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {metrics.map((metric, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 shadow-sm flex flex-col hover:border-primary/50 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-secondary rounded-lg text-primary">
                <metric.icon className="w-5 h-5" />
              </div>
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${metric.status === 'good' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-secondary text-muted-foreground'}`}>
                {metric.trend}
              </span>
            </div>
            <h3 className="text-2xl font-bold">{metric.value}</h3>
            <p className="text-sm font-medium text-muted-foreground mt-1">{metric.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 border-b border-border bg-secondary/30 flex justify-between items-center">
            <h3 className="text-lg font-semibold flex items-center gap-2"><Database className="w-4 h-4 text-primary" /> Recent Tenants</h3>
            <Button variant="ghost" size="sm" className="text-xs">View All <ArrowUpRight className="w-3 h-3 ml-1" /></Button>
          </div>
          <div className="p-0 overflow-y-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground bg-background">
                <tr>
                  <th className="px-4 py-3 font-medium">Tenant ID</th>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Plan</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {['Acme Corp', 'Globex', 'Soylent', 'Initech', 'Umbrella'].map((name, i) => (
                  <tr key={i} className="hover:bg-secondary/20 transition-colors">
                    <td className="px-4 py-3 font-mono text-muted-foreground">org_{Math.floor(Math.random() * 10000)}</td>
                    <td className="px-4 py-3 font-medium">{name}</td>
                    <td className="px-4 py-3">{i === 0 ? 'Enterprise' : 'Pro'}</td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">Active</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
          <div className="grid gap-3 grid-cols-2">
            <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center hover:border-primary">
              <Users className="w-5 h-5 text-primary" /> Manage Users
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center hover:border-primary">
              <Server className="w-5 h-5 text-primary" /> Provision Node
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center hover:border-primary">
              <Shield className="w-5 h-5 text-primary" /> Security Policies
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center hover:border-primary">
              <Activity className="w-5 h-5 text-primary" /> View Logs
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
