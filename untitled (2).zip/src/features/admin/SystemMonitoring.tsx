import React from 'react';
import { Activity, Server, Cpu, HardDrive, Network, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function SystemMonitoring() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">System Monitoring</h2>
          <p className="text-muted-foreground mt-1">Live metrics and health status of infrastructure.</p>
        </div>
        <Button className="flex items-center gap-2" variant="outline">
          <Activity className="w-4 h-4" /> Live View
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Cluster Status', value: 'Healthy', icon: Server, status: 'good' },
          { label: 'CPU Average', value: '42%', icon: Cpu, status: 'good' },
          { label: 'Memory Usage', value: '78%', icon: HardDrive, status: 'warning' },
          { label: 'Network I/O', value: '1.2 GB/s', icon: Network, status: 'good' },
        ].map((stat, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 shadow-sm flex items-center gap-4">
            <div className={`p-3 rounded-lg ${stat.status === 'warning' ? 'bg-amber-500/20 text-amber-500' : 'bg-emerald-500/20 text-emerald-500'}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
              <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
         <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
           <h3 className="text-lg font-semibold mb-4">Active Services</h3>
           <div className="space-y-4">
             {[
               { name: 'API Gateway', status: 'operational', uptime: '99.99%' },
               { name: 'Authentication Service', status: 'operational', uptime: '100%' },
               { name: 'Database Cluster', status: 'operational', uptime: '99.95%' },
               { name: 'Background Workers', status: 'degraded', uptime: '98.20%' },
               { name: 'AI Proxy', status: 'operational', uptime: '99.9%' },
             ].map((service, i) => (
               <div key={i} className="flex items-center justify-between">
                 <span className="text-sm font-medium">{service.name}</span>
                 <div className="flex items-center gap-4">
                   <span className="text-xs text-muted-foreground">Uptime: {service.uptime}</span>
                   {service.status === 'operational' ? (
                     <span className="text-xs font-medium text-emerald-500 flex items-center gap-1"><CheckCircle className="w-3 h-3"/> OK</span>
                   ) : (
                     <span className="text-xs font-medium text-amber-500 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> Degraded</span>
                   )}
                 </div>
               </div>
             ))}
           </div>
         </div>
         
         <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
           <h3 className="text-lg font-semibold mb-4">Recent Alerts</h3>
           <div className="space-y-4">
             {[1, 2, 3, 4].map((i) => (
               <div key={i} className="flex gap-3 items-start border-l-2 border-amber-500 pl-3">
                 <div>
                   <p className="text-sm font-medium">High memory utilization on Worker Node {i}</p>
                   <p className="text-xs text-muted-foreground mt-1">Memory exceeded 85% threshold. Auto-scaling initiated.</p>
                   <p className="text-[10px] text-muted-foreground mt-1">{i * 15} minutes ago</p>
                 </div>
               </div>
             ))}
           </div>
         </div>
      </div>
    </div>
  );
}
