import React from 'react';
import { Search, Filter, Download, ShieldAlert, History } from 'lucide-react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";

export function AuditLogViewer() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Audit Logs</h2>
          <p className="text-muted-foreground mt-1">Immutable record of all system events and user actions.</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="w-4 h-4" /> Export Logs
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border flex items-center justify-between bg-background">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9 w-[400px]" placeholder="Search by user, action, resource, or IP..." />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <Filter className="w-4 h-4" /> Filters
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <History className="w-4 h-4" /> Last 30 Days
            </Button>
          </div>
        </div>
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              <th className="px-6 py-3 font-medium">Timestamp</th>
              <th className="px-6 py-3 font-medium">Actor</th>
              <th className="px-6 py-3 font-medium">Action</th>
              <th className="px-6 py-3 font-medium">Resource</th>
              <th className="px-6 py-3 font-medium">IP Address</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {[1, 2, 3, 4, 5, 6, 7].map((i) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4 text-muted-foreground font-mono text-xs">2026-10-24 14:32:{i}0 UTC</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center text-xs font-medium border border-border">
                      {i % 2 === 0 ? 'S' : 'A'}
                    </div>
                    <span className="font-medium">{i % 2 === 0 ? 'System' : 'admin@emcas.local'}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-muted-foreground">
                  {i === 3 ? (
                    <span className="flex items-center gap-1 text-destructive"><ShieldAlert className="w-3 h-3"/> auth.failed</span>
                  ) : (
                    'resource.read'
                  )}
                </td>
                <td className="px-6 py-4 text-muted-foreground font-mono text-xs">proj_alpha_assets</td>
                <td className="px-6 py-4 text-muted-foreground font-mono text-xs">192.168.1.{i * 15}</td>
                <td className="px-6 py-4">
                  {i === 3 ? (
                    <span className="text-xs font-medium text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">Failed</span>
                  ) : (
                    <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">Success</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
