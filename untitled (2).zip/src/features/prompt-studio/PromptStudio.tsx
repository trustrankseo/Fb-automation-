
import React, { useState } from 'react';
import { Save, Play, Settings2, Sparkles, Layers } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export function PromptStudio() {
  const [systemPrompt, setSystemPrompt] = useState('You are an expert enterprise architect.');
  const [userPrompt, setUserPrompt] = useState('Design a scalable microservices architecture for an e-commerce platform.');
  const [result, setResult] = useState('');
  const [isRunning, setIsRunning] = useState(false);

  const handleRun = () => {
    setIsRunning(true);
    // Simulate API call to execute prompt
    setTimeout(() => {
      setResult('Here is the proposed microservices architecture:\n\n1. **API Gateway**: Kong or AWS API Gateway to route requests.\n2. **Auth Service**: Manages JWT, OAuth, and RBAC.\n3. **Product Catalog**: Read-heavy service, backed by Elasticsearch and Redis cache.\n4. **Order Management**: Handles transactions, backed by PostgreSQL.\n5. **Payment Service**: Integrates with Stripe/PayPal.\n6. **Event Bus**: Kafka or RabbitMQ for asynchronous communication.\n\nAll services containerized via Docker and orchestrated with Kubernetes.');
      setIsRunning(false);
    }, 1500);
  };

  return (
    <div className="space-y-6 h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Prompt Studio</h2>
          <p className="text-sm text-muted-foreground mt-1">Design, test, and optimize your LLM prompts</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2"><Save className="w-4 h-4"/> Save Template</Button>
          <Button onClick={handleRun} disabled={isRunning} className="flex items-center gap-2">
            {isRunning ? <span className="animate-spin text-lg leading-none">⟳</span> : <Play className="w-4 h-4"/>} 
            Run Prompt
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
        {/* Configuration Side */}
        <div className="space-y-4 flex flex-col min-h-0">
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold flex items-center gap-2"><Settings2 className="w-4 h-4" /> Model Configuration</label>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Model</label>
                <select className="w-full bg-background border border-input rounded-md text-sm p-2 focus:ring-1 focus:ring-primary outline-none">
                  <option>Gemini 1.5 Pro</option>
                  <option>Gemini 1.5 Flash</option>
                  <option>GPT-4o</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Temperature (0.7)</label>
                <input type="range" min="0" max="1" step="0.1" defaultValue="0.7" className="w-full mt-2" />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-4 shadow-sm flex-1 flex flex-col min-h-0">
            <label className="text-sm font-semibold flex items-center gap-2 mb-2"><Layers className="w-4 h-4" /> System Instructions</label>
            <textarea 
              value={systemPrompt}
              onChange={e => setSystemPrompt(e.target.value)}
              className="w-full flex-1 bg-background border border-input rounded-md p-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none font-mono"
              placeholder="Enter system instructions..."
            />
          </div>

          <div className="bg-card border border-border rounded-xl p-4 shadow-sm flex-1 flex flex-col min-h-0">
            <label className="text-sm font-semibold flex items-center gap-2 mb-2"><Sparkles className="w-4 h-4" /> User Prompt</label>
            <textarea 
              value={userPrompt}
              onChange={e => setUserPrompt(e.target.value)}
              className="w-full flex-1 bg-background border border-input rounded-md p-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none font-mono"
              placeholder="Enter your prompt here..."
            />
          </div>
        </div>

        {/* Results Side */}
        <div className="bg-card border border-border rounded-xl p-0 shadow-sm flex flex-col min-h-0 overflow-hidden">
          <div className="p-4 border-b border-border bg-secondary/50 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Output Preview</h3>
            {result && <span className="text-xs text-emerald-500 font-medium bg-emerald-500/10 px-2 py-1 rounded">Success</span>}
          </div>
          <div className="p-4 flex-1 overflow-y-auto bg-background">
            {isRunning ? (
              <div className="flex items-center justify-center h-full text-muted-foreground flex-col gap-3">
                <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-sm">Generating response...</p>
              </div>
            ) : result ? (
              <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                {result}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                Run the prompt to see results here.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
