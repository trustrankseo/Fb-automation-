import React from 'react';
import { Users, FileText, Settings, Activity, Clock } from 'lucide-react';
import { Button } from "../../components/ui/Button";

export function ProjectDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-border pb-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Project Alpha</h2>
          <p className="text-muted-foreground mt-1">Enterprise software redesign and modernization.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Settings</Button>
          <Button>Invite Members</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Users className="w-4 h-4" /> Team Members
          </h3>
          <p className="text-2xl font-bold mt-2">12 Active</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <FileText className="w-4 h-4" /> Total Files
          </h3>
          <p className="text-2xl font-bold mt-2">1,492</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Clock className="w-4 h-4" /> Time Tracked
          </h3>
          <p className="text-2xl font-bold mt-2">340 hrs</p>
        </div>
      </div>
    </div>
  );
}
