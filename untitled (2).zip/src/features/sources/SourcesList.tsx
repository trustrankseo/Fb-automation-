import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DownloadCloud, Plus, FileVideo, HardDrive, Search, PlaySquare, X } from "lucide-react";
import { useState } from "react";

export function SourcesList() {
  const queryClient = useQueryClient();
  // We'll use a hardcoded project ID for now or fetch all sources if the API supports it.
  const projectId = "proj_default_123";
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newType, setNewType] = useState("YOUTUBE");

  const { data, isLoading, error } = useQuery({
    queryKey: ["sources", projectId],
    queryFn: async () => {
      const response = await fetch(`/api/sources/project/${projectId}`);
      if (!response.ok) throw new Error("Failed to fetch sources");
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (newSource: { name: string; type: string; projectId: string; status: string }) => {
      const response = await fetch("/api/sources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSource),
      });
      if (!response.ok) throw new Error("Failed to connect source");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sources", projectId] });
      setIsCreating(false);
      setNewName("");
      setNewType("YOUTUBE");
    },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;
    createMutation.mutate({
      name: newName,
      type: newType,
      projectId: projectId,
      status: "ACTIVE",
    });
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "YOUTUBE": return <PlaySquare className="w-5 h-5 text-red-500" />;
      case "TWITCH": return <FileVideo className="w-5 h-5 text-purple-500" />;
      case "GOOGLE_DRIVE": return <HardDrive className="w-5 h-5 text-blue-500" />;
      default: return <DownloadCloud className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Media Sources</h2>
          <p className="text-muted-foreground mt-1 text-sm">
            Connect content streams to pull media into your pipeline.
          </p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="flex items-center justify-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Connect Source
        </button>
      </div>

      {isCreating && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-lg shadow-lg max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Connect New Source</h3>
              <button onClick={() => setIsCreating(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Source Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Main YouTube Channel"
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Source Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value)}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                >
                  <option value="YOUTUBE">YouTube Channel</option>
                  <option value="TWITCH">Twitch Stream</option>
                  <option value="GOOGLE_DRIVE">Google Drive Folder</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
                >
                  {createMutation.isPending ? "Connecting..." : "Connect Source"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex items-center gap-4 bg-card border border-border p-2 rounded-md">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input 
            type="text" 
            placeholder="Search connected sources..." 
            className="w-full bg-transparent border-none pl-9 pr-4 py-1.5 text-sm focus:outline-none focus:ring-0 text-foreground"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <div className="col-span-full py-12 flex justify-center">
            <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
          </div>
        ) : error ? (
          <div className="col-span-full p-6 border border-destructive/20 bg-destructive/5 rounded-lg text-destructive">
            Failed to load sources. Check API connection.
          </div>
        ) : data?.data?.length === 0 ? (
          <div className="col-span-full p-12 border border-dashed border-border rounded-lg text-center flex flex-col items-center justify-center">
            <DownloadCloud className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No sources connected</h3>
            <p className="text-muted-foreground text-sm mt-1 mb-6 max-w-sm">
              Connect a YouTube, Twitch, or Drive account to start importing media.
            </p>
          </div>
        ) : (
          data?.data?.map((source: any) => (
            <div key={source.id} className="bg-card border border-border rounded-lg p-6 flex flex-col hover:border-primary/50 transition-colors group cursor-pointer shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-md bg-secondary flex items-center justify-center text-foreground transition-colors border border-border">
                  {getSourceIcon(source.type)}
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                  source.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-destructive/10 text-destructive'
                }`}>
                  {source.status}
                </span>
              </div>
              <h3 className="font-semibold text-lg">{source.name}</h3>
              <p className="text-muted-foreground text-sm mt-1 mb-6">
                Type: <span className="font-mono text-xs ml-1 bg-secondary px-1.5 py-0.5 rounded">{source.type}</span>
              </p>
              <div className="mt-auto pt-4 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                <span>Added {new Date(source.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
