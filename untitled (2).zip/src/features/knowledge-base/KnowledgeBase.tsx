import React from 'react';
import { Book, Upload, Folder, Search, Database, RefreshCw, FileText } from 'lucide-react';
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";

export function KnowledgeBase() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Knowledge Base</h2>
          <p className="text-muted-foreground mt-1">Manage documents and data sources for AI grounding.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Upload className="w-4 h-4" /> Upload Documents
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm flex items-center justify-between">
           <div>
             <p className="text-sm font-medium text-muted-foreground">Total Documents</p>
             <h3 className="text-2xl font-bold mt-1">3,492</h3>
           </div>
           <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
             <FileText className="w-5 h-5" />
           </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm flex items-center justify-between">
           <div>
             <p className="text-sm font-medium text-muted-foreground">Embeddings Status</p>
             <h3 className="text-2xl font-bold mt-1 text-emerald-500">Up to date</h3>
           </div>
           <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500">
             <Database className="w-5 h-5" />
           </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm flex items-center justify-between">
           <div>
             <p className="text-sm font-medium text-muted-foreground">Sync Queue</p>
             <h3 className="text-2xl font-bold mt-1">0 pending</h3>
           </div>
           <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500">
             <RefreshCw className="w-5 h-5" />
           </div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border flex items-center justify-between bg-background">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9 w-[300px]" placeholder="Search knowledge base..." />
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Folder className="w-4 h-4" /> New Collection
          </Button>
        </div>
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              <th className="px-6 py-3 font-medium">Name</th>
              <th className="px-6 py-3 font-medium">Collection</th>
              <th className="px-6 py-3 font-medium">Status</th>
              <th className="px-6 py-3 font-medium">Last Synced</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {[1, 2, 3, 4, 5].map((i) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4 flex items-center gap-3">
                  <FileText className="w-4 h-4 text-primary" />
                  <span className="font-medium">employee_handbook_2026.pdf</span>
                </td>
                <td className="px-6 py-4 text-muted-foreground">HR Policies</td>
                <td className="px-6 py-4">
                  <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">Indexed</span>
                </td>
                <td className="px-6 py-4 text-muted-foreground">Oct 24, 2026</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
