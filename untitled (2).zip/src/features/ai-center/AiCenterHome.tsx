import React from 'react';
import { Link } from 'react-router-dom';
import { Bot, MessageSquare, PenTool, BookOpen, Workflow, Settings } from 'lucide-react';

export function AiCenterHome() {
  const tools = [
    {
      title: "AI Chat Assistant",
      description: "Chat with your enterprise-configured AI models. Context-aware and secure.",
      icon: MessageSquare,
      href: "/chat",
      color: "text-blue-500",
      bg: "bg-blue-500/10"
    },
    {
      title: "Prompt Studio",
      description: "Design, test, and version your LLM prompts with real-time previews.",
      icon: PenTool,
      href: "/prompts",
      color: "text-purple-500",
      bg: "bg-purple-500/10"
    },
    {
      title: "Knowledge Base (RAG)",
      description: "Manage documents and vector embeddings for grounded AI responses.",
      icon: BookOpen,
      href: "/knowledge",
      color: "text-emerald-500",
      bg: "bg-emerald-500/10"
    },
    {
      title: "AI Agents",
      description: "Build autonomous agents with custom tools and logic chains.",
      icon: Bot,
      href: "/agents",
      color: "text-amber-500",
      bg: "bg-amber-500/10"
    },
    {
      title: "Workflows",
      description: "Create visual AI workflows connecting multiple models and services.",
      icon: Workflow,
      href: "/workflows",
      color: "text-rose-500",
      bg: "bg-rose-500/10"
    },
    {
      title: "Model Settings",
      description: "Configure API keys, default models, and system-wide AI limits.",
      icon: Settings,
      href: "/settings/api-keys",
      color: "text-slate-500",
      bg: "bg-slate-500/10"
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">AI Center</h2>
        <p className="text-muted-foreground mt-2">Your central hub for Enterprise AI capabilities, models, and tools.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tools.map((tool, i) => (
          <Link key={i} to={tool.href} className="block group">
            <div className="rounded-xl border border-border bg-card p-6 shadow-sm h-full hover:border-primary/50 transition-colors">
              <div className={`w-12 h-12 rounded-lg ${tool.bg} ${tool.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <tool.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{tool.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{tool.description}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden shadow-sm mt-8">
        <div className="p-6 border-b border-border bg-secondary/30">
          <h3 className="text-lg font-semibold">Active Models & Integrations</h3>
        </div>
        <div className="p-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="flex items-center gap-3 p-4 rounded-lg border border-border">
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <div>
              <p className="font-medium text-sm">Gemini 1.5 Pro</p>
              <p className="text-xs text-muted-foreground">Google GenAI</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 rounded-lg border border-border">
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <div>
              <p className="font-medium text-sm">Gemini 1.5 Flash</p>
              <p className="text-xs text-muted-foreground">Google GenAI</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 rounded-lg border border-border">
            <div className="w-3 h-3 rounded-full bg-amber-500"></div>
            <div>
              <p className="font-medium text-sm">GPT-4o</p>
              <p className="text-xs text-muted-foreground">OpenAI (Standby)</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 rounded-lg border border-border">
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <div>
              <p className="font-medium text-sm">Vector Store</p>
              <p className="text-xs text-muted-foreground">Pinecone connected</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
