import { useQuery } from "@tanstack/react-query";
import { Activity, Clock, PlayCircle, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";

export function JobsList() {
  const projectId = "proj_default_123";

  const { data, isLoading, error } = useQuery({
    queryKey: ["jobs", projectId],
    queryFn: async () => {
      const response = await fetch(`/api/jobs/project/${projectId}`);
      if (!response.ok) throw new Error("Failed to fetch jobs");
      return response.json();
    },
    refetchInterval: 3000, // Refresh every 3 seconds to show progress
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "PENDING": return <Clock className="w-5 h-5 text-blue-500" />;
      case "PROCESSING": return <Loader2 className="w-5 h-5 text-purple-500 animate-spin" />;
      case "COMPLETED": return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      case "FAILED": return <AlertCircle className="w-5 h-5 text-destructive" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PENDING": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "PROCESSING": return "bg-purple-500/10 text-purple-500 border-purple-500/20";
      case "COMPLETED": return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      case "FAILED": return "bg-destructive/10 text-destructive border-destructive/20";
      default: return "bg-secondary text-secondary-foreground border-border";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Active Jobs</h2>
          <p className="text-muted-foreground mt-1 text-sm">
            Monitor background processing tasks, downloads, and AI clip generation.
          </p>
        </div>
        <button 
          onClick={async () => {
            try {
              await fetch('/api/jobs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  projectId: projectId,
                  type: 'GENERATE_CLIPS',
                  payload: { transcript: "Example transcript of a very engaging podcast about AI replacing coding tasks. We are moving into a world where agents orchestrate workflows. It is incredible." }
                })
              });
            } catch (err) {
              console.error(err);
            }
          }}
          className="flex items-center justify-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:bg-primary/90 transition-colors"
        >
          <PlayCircle className="w-4 h-4" />
          Trigger AI Clip Generation
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 font-medium">Job ID</th>
                <th className="px-6 py-4 font-medium">Type</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Progress</th>
                <th className="px-6 py-4 font-medium">Created</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <div className="flex justify-center">
                      <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
                    </div>
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-destructive">
                    Failed to load jobs. Check API connection.
                  </td>
                </tr>
              ) : data?.data?.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                    <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No jobs found for this project.</p>
                  </td>
                </tr>
              ) : (
                data?.data?.map((job: any) => (
                  <tr key={job.id} className="border-b border-border/50 hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-xs">
                      {job.id.split('_')[1] || job.id}
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-medium">{job.type.replace(/_/g, ' ')}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(job.status)}
                        <span className={`text-xs font-medium px-2.5 py-1 rounded-full border ${getStatusColor(job.status)}`}>
                          {job.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 w-64">
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              job.status === 'FAILED' ? 'bg-destructive' : 
                              job.status === 'COMPLETED' ? 'bg-emerald-500' : 'bg-primary'
                            }`}
                            style={{ width: `${job.progress || 0}%` }}
                          />
                        </div>
                        <span className="text-xs font-mono w-8">{job.progress || 0}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground text-xs whitespace-nowrap">
                      {new Date(job.createdAt).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
