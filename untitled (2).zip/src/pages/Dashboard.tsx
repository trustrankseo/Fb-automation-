import React from 'react';

export function Dashboard() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-6 shadow-sm">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Metric {i}</h3>
            <p className="text-2xl font-bold mt-2">1,234</p>
          </div>
        ))}
      </div>
    </div>
  );
}
