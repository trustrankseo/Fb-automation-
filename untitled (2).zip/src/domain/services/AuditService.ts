import { eventDispatcher } from '../events/EventDispatcher';

export class AuditService {
  static async record(
    actorId: string, 
    action: string, 
    resourceType: string, 
    resourceId: string, 
    previousValue?: any, 
    newValue?: any,
    correlationId?: string
  ) {
    await eventDispatcher.dispatch({
      id: crypto.randomUUID(),
      type: 'AUDIT_LOG_RECORDED',
      timestamp: new Date(),
      actorId,
      correlationId,
      payload: {
        action,
        resourceType,
        resourceId,
        previousValue,
        newValue
      }
    });
  }
}
