
export interface IntegrationEvent {
  id: string;
  topic: string;
  payload: any;
  timestamp: Date;
  correlationId?: string;
}

export class EventBus {
  private subscribers: Map<string, Array<(event: IntegrationEvent) => Promise<void>>> = new Map();

  subscribe(topic: string, handler: (event: IntegrationEvent) => Promise<void>) {
    const handlers = this.subscribers.get(topic) || [];
    handlers.push(handler);
    this.subscribers.set(topic, handlers);
  }

  async publish(topic: string, payload: any, correlationId?: string): Promise<void> {
    const event: IntegrationEvent = {
      id: crypto.randomUUID(),
      topic,
      payload,
      timestamp: new Date(),
      correlationId
    };

    const handlers = this.subscribers.get(topic) || [];
    
    // In a real system, this would push to Kafka/RabbitMQ
    Promise.allSettled(handlers.map(handler => handler(event))).catch(console.error);
    
    console.log(`[EventBus] Published ${topic}`);
  }
}

export const eventBus = new EventBus();
