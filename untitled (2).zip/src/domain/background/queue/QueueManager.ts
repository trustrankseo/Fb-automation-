
export interface Job {
  id: string;
  type: string;
  payload: any;
  priority: number;
  status: 'queued' | 'pending' | 'running' | 'paused' | 'retrying' | 'completed' | 'failed' | 'cancelled' | 'expired';
  attempts: number;
  maxAttempts: number;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  error?: string;
  correlationId?: string;
  tenantId?: string;
}

export class QueueManager {
  private queues: Map<string, Job[]> = new Map();

  async enqueue(type: string, payload: any, options: { priority?: number, maxAttempts?: number, delay?: number, correlationId?: string, tenantId?: string } = {}): Promise<Job> {
    const job: Job = {
      id: crypto.randomUUID(),
      type,
      payload,
      priority: options.priority || 0,
      status: 'queued',
      attempts: 0,
      maxAttempts: options.maxAttempts || 3,
      createdAt: new Date(),
      correlationId: options.correlationId,
      tenantId: options.tenantId
    };

    const queue = this.queues.get(type) || [];
    queue.push(job);
    queue.sort((a, b) => b.priority - a.priority); // Simple priority sorting
    this.queues.set(type, queue);
    
    console.log(`[QueueManager] Enqueued job ${job.id} of type ${job.type}`);
    return job;
  }

  async dequeue(type: string): Promise<Job | null> {
    const queue = this.queues.get(type) || [];
    const job = queue.find(j => j.status === 'queued' || j.status === 'retrying');
    if (job) {
      job.status = 'pending';
      return job;
    }
    return null;
  }
}

export const queueManager = new QueueManager();
