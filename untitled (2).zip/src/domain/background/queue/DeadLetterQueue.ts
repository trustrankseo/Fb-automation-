
import { Job } from './QueueManager';

export class DeadLetterQueue {
  private dlq: Job[] = [];

  async add(job: Job, reason: string): Promise<void> {
    console.error(`[DLQ] Job ${job.id} moved to DLQ. Reason: ${reason}`);
    this.dlq.push({ ...job, error: reason });
  }

  async list(): Promise<Job[]> {
    return this.dlq;
  }

  async retry(jobId: string): Promise<boolean> {
    // Logic to move back to main queue
    return true;
  }
}

export const deadLetterQueue = new DeadLetterQueue();
