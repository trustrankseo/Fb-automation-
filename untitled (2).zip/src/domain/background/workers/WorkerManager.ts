
import { queueManager, Job } from '../queue/QueueManager';
import { deadLetterQueue } from '../queue/DeadLetterQueue';

export type JobHandler = (job: Job) => Promise<void>;

export class WorkerManager {
  private handlers: Map<string, JobHandler> = new Map();
  private isRunning = false;

  registerWorker(type: string, handler: JobHandler) {
    this.handlers.set(type, handler);
  }

  start() {
    this.isRunning = true;
    this.poll();
  }

  stop() {
    this.isRunning = false;
  }

  private async poll() {
    if (!this.isRunning) return;

    for (const [type, handler] of this.handlers.entries()) {
      const job = await queueManager.dequeue(type);
      if (job) {
        this.processJob(job, handler);
      }
    }

    setTimeout(() => this.poll(), 1000); // Poll every second
  }

  private async processJob(job: Job, handler: JobHandler) {
    job.status = 'running';
    job.startedAt = new Date();
    job.attempts += 1;

    try {
      await handler(job);
      job.status = 'completed';
      job.completedAt = new Date();
      console.log(`[WorkerManager] Job ${job.id} completed successfully`);
    } catch (error: any) {
      if (job.attempts >= job.maxAttempts) {
        job.status = 'failed';
        job.error = error.message;
        await deadLetterQueue.add(job, error.message);
      } else {
        job.status = 'retrying';
        // Exponential backoff logic would go here
      }
    }
  }
}

export const workerManager = new WorkerManager();
