export interface DomainEvent {
  id: string;
  type: string;
  timestamp: Date;
  payload: any;
  correlationId?: string;
  actorId?: string;
}

export class EventDispatcher {
  private handlers: Map<string, Array<(event: DomainEvent) => Promise<void>>> = new Map();

  subscribe(eventType: string, handler: (event: DomainEvent) => Promise<void>) {
    const handlers = this.handlers.get(eventType) || [];
    handlers.push(handler);
    this.handlers.set(eventType, handlers);
  }

  async dispatch(event: DomainEvent): Promise<void> {
    const handlers = this.handlers.get(event.type) || [];
    
    // Execute asynchronously without blocking
    Promise.allSettled(handlers.map(handler => handler(event))).catch(console.error);
    
    // Log event for audit purposes (would typically route to an Audit log / messaging queue)
    console.log(`[EventDispatcher] Dispatched: ${event.type}`, event);
  }
}

export const eventDispatcher = new EventDispatcher();
