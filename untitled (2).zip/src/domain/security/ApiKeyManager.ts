import { randomBytes, createHash } from 'crypto';

export interface ApiKey {
  id: string;
  name: string;
  keyPrefix: string;
  keyHash: string;
  userId: string;
  organizationId?: string;
  scopes: string[];
  createdAt: Date;
  expiresAt?: Date;
  lastUsedAt?: Date;
  isActive: boolean;
}

export class ApiKeyManager {
  
  async generateKey(name: string, userId: string, scopes: string[], organizationId?: string, expiresAt?: Date): Promise<{ key: string, record: ApiKey }> {
    // Generate a secure random key
    const rawKey = randomBytes(32).toString('base64url');
    const keyPrefix = rawKey.substring(0, 8);
    
    // Hash the key for storage
    const keyHash = createHash('sha256').update(rawKey).digest('hex');
    
    const record: ApiKey = {
      id: randomBytes(16).toString('hex'),
      name,
      keyPrefix,
      keyHash,
      userId,
      organizationId,
      scopes,
      createdAt: new Date(),
      expiresAt,
      isActive: true
    };
    
    // In a real app, save 'record' to database here
    
    return {
      key: `emc_${rawKey}`,
      record
    };
  }

  async validateKey(key: string): Promise<ApiKey | null> {
    if (!key.startsWith('emc_')) return null;
    
    const rawKey = key.substring(4);
    const keyHash = createHash('sha256').update(rawKey).digest('hex');
    
    // In a real app, query database for keyHash
    // const record = await db.apiKeys.findOne({ keyHash, isActive: true });
    // if (!record) return null;
    
    // Check expiration
    // if (record.expiresAt && new Date() > record.expiresAt) return null;
    
    // Update last used
    // await db.apiKeys.updateOne({ id: record.id }, { lastUsedAt: new Date() });
    
    return null; // Return null since it's a mock
  }

  async revokeKey(id: string): Promise<void> {
    // In a real app, update database
    console.log(`Revoked API key ${id}`);
  }
}

export const apiKeyManager = new ApiKeyManager();
