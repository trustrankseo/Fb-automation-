export enum Role {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ORG_ADMIN = 'ORG_ADMIN',
  WORKSPACE_ADMIN = 'WORKSPACE_ADMIN',
  PROJECT_MANAGER = 'PROJECT_MANAGER',
  MEMBER = 'MEMBER',
  VIEWER = 'VIEWER',
  GUEST = 'GUEST'
}

export enum Permission {
  READ = 'READ',
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  EXECUTE = 'EXECUTE',
  APPROVE = 'APPROVE',
  SHARE = 'SHARE',
  EXPORT = 'EXPORT',
  IMPORT = 'IMPORT',
  MANAGE = 'MANAGE'
}

export class RBACEngine {
  private rolePermissions: Record<Role, Permission[]> = {
    [Role.SUPER_ADMIN]: Object.values(Permission),
    [Role.ORG_ADMIN]: [Permission.READ, Permission.CREATE, Permission.UPDATE, Permission.DELETE, Permission.MANAGE, Permission.SHARE, Permission.EXPORT, Permission.IMPORT],
    [Role.WORKSPACE_ADMIN]: [Permission.READ, Permission.CREATE, Permission.UPDATE, Permission.DELETE, Permission.MANAGE],
    [Role.PROJECT_MANAGER]: [Permission.READ, Permission.CREATE, Permission.UPDATE, Permission.APPROVE],
    [Role.MEMBER]: [Permission.READ, Permission.CREATE, Permission.UPDATE],
    [Role.VIEWER]: [Permission.READ],
    [Role.GUEST]: [Permission.READ] // highly restricted read
  };

  hasPermission(roles: string[], requiredPermission: Permission): boolean {
    for (const roleStr of roles) {
      const role = roleStr as Role;
      if (this.rolePermissions[role]?.includes(requiredPermission)) {
        return true;
      }
    }
    return false;
  }
  
  hasAnyPermission(roles: string[], requiredPermissions: Permission[]): boolean {
    return requiredPermissions.some(p => this.hasPermission(roles, p));
  }
  
  hasAllPermissions(roles: string[], requiredPermissions: Permission[]): boolean {
    return requiredPermissions.every(p => this.hasPermission(roles, p));
  }
}

export const rbacEngine = new RBACEngine();
