import { randomUUID } from 'crypto';
import { cacheService } from '../services/CacheService';

export interface Session {
  id: string;
  userId: string;
  deviceId: string;
  ipAddress: string;
  userAgent: string;
  createdAt: Date;
  lastActiveAt: Date;
  expiresAt: Date;
  isValid: boolean;
}

export class SessionManager {
  private readonly SESSION_TTL = 7 * 24 * 60 * 60; // 7 days

  async createSession(userId: string, deviceId: string, ipAddress: string, userAgent: string): Promise<Session> {
    const session: Session = {
      id: randomUUID(),
      userId,
      deviceId,
      ipAddress,
      userAgent,
      createdAt: new Date(),
      lastActiveAt: new Date(),
      expiresAt: new Date(Date.now() + this.SESSION_TTL * 1000),
      isValid: true
    };
    
    await cacheService.set(`session:${session.id}`, session, this.SESSION_TTL);
    
    // We would also save to database here for persistence across cache evictions
    
    return session;
  }

  async getSession(sessionId: string): Promise<Session | null> {
    const session = await cacheService.get<Session>(`session:${sessionId}`);
    if (!session || !session.isValid) return null;
    
    if (new Date() > session.expiresAt) {
      await this.revokeSession(sessionId);
      return null;
    }
    
    return session;
  }

  async heartbeat(sessionId: string): Promise<boolean> {
    const session = await this.getSession(sessionId);
    if (!session) return false;
    
    session.lastActiveAt = new Date();
    await cacheService.set(`session:${session.id}`, session, this.SESSION_TTL);
    
    return true;
  }

  async revokeSession(sessionId: string): Promise<void> {
    const session = await cacheService.get<Session>(`session:${sessionId}`);
    if (session) {
      session.isValid = false;
      await cacheService.set(`session:${session.id}`, session, this.SESSION_TTL);
    }
  }
  
  async revokeAllUserSessions(userId: string): Promise<void> {
    // In a real implementation, this would query the DB for all active sessions for the user
    // and mark them invalid, then remove from cache
    console.log(`Revoked all sessions for user ${userId}`);
  }
}

export const sessionManager = new SessionManager();
