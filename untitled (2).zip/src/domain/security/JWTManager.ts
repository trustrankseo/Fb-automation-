import * as crypto from 'crypto';

export interface TokenPayload {
  userId: string;
  roles: string[];
  organizationId?: string;
  sessionId?: string;
  [key: string]: any;
}

export class JWTManager {
  private readonly secret: string;
  private readonly issuer: string = 'emcas-enterprise';

  constructor(secret: string = process.env.JWT_SECRET || 'default-insecure-secret') {
    this.secret = secret;
  }

  // A basic mock implementation of JWT signing for the architecture
  async sign(payload: TokenPayload, expiresIn: string = '1h'): Promise<string> {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    
    // Calculate expiration
    const exp = Math.floor(Date.now() / 1000) + this.parseExpiration(expiresIn);
    
    const body = Buffer.from(JSON.stringify({ 
      ...payload, 
      iss: this.issuer,
      exp,
      iat: Math.floor(Date.now() / 1000)
    })).toString('base64url');
    
    const signature = crypto.createHmac('sha256', this.secret)
      .update(`${header}.${body}`)
      .digest('base64url');

    return `${header}.${body}.${signature}`;
  }

  async verify(token: string): Promise<TokenPayload> {
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid token format');
    }

    const [header, body, signature] = parts;
    const expectedSignature = crypto.createHmac('sha256', this.secret)
      .update(`${header}.${body}`)
      .digest('base64url');

    if (signature !== expectedSignature) {
      throw new Error('Invalid token signature');
    }

    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      throw new Error('Token expired');
    }

    return payload as TokenPayload;
  }
  
  private parseExpiration(expiresIn: string): number {
    if (expiresIn.endsWith('h')) return parseInt(expiresIn) * 3600;
    if (expiresIn.endsWith('d')) return parseInt(expiresIn) * 86400;
    if (expiresIn.endsWith('m')) return parseInt(expiresIn) * 60;
    return 3600; // default 1h
  }
}

export const jwtManager = new JWTManager();
