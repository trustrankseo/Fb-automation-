
export interface FileMetadata {
  id: string;
  filename: string;
  size: number;
  mimeType: string;
  path: string;
  version: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface StorageProvider {
  id: string;
  name: string;
  
  upload(file: Buffer | Blob, path: string, options?: any): Promise<FileMetadata>;
  uploadChunk?(chunk: Buffer | Blob, uploadId: string, partNumber: number): Promise<void>;
  completeMultipartUpload?(uploadId: string): Promise<FileMetadata>;
  
  download(path: string): Promise<Buffer | Blob>;
  getDownloadUrl(path: string, expiresIn?: number): Promise<string>;
  
  delete(path: string): Promise<void>;
  exists(path: string): Promise<boolean>;
  
  list(prefix: string): Promise<FileMetadata[]>;
}
