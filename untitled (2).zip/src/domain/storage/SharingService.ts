
export interface ShareLink {
  id: string;
  filePath: string;
  url: string;
  expiresAt?: Date;
  passwordProtected: boolean;
  downloadCount: number;
  maxDownloads?: number;
}

export class SharingService {
  async createPublicLink(filePath: string, expiresInDays?: number, password?: string): Promise<ShareLink> {
    return {
      id: crypto.randomUUID(),
      filePath,
      url: `https://share.emcas.app/${crypto.randomUUID()}`,
      expiresAt: expiresInDays ? new Date(Date.now() + expiresInDays * 86400000) : undefined,
      passwordProtected: !!password,
      downloadCount: 0
    };
  }
}
