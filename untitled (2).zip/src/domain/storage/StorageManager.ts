
import { StorageProvider, FileMetadata } from './providers/StorageProvider';

export class StorageManager {
  private providers: Map<string, StorageProvider> = new Map();
  private defaultProvider: string | null = null;

  registerProvider(provider: StorageProvider, isDefault: boolean = false) {
    this.providers.set(provider.id, provider);
    if (isDefault || !this.defaultProvider) {
      this.defaultProvider = provider.id;
    }
  }

  getProvider(providerId?: string): StorageProvider {
    const id = providerId || this.defaultProvider;
    if (!id) throw new Error('No storage provider registered');
    const provider = this.providers.get(id);
    if (!provider) throw new Error(`Provider ${id} not found`);
    return provider;
  }

  async uploadFile(file: Buffer | Blob, destinationPath: string, providerId?: string): Promise<FileMetadata> {
    const provider = this.getProvider(providerId);
    return await provider.upload(file, destinationPath);
  }

  async getFileUrl(path: string, expiresIn: number = 3600, providerId?: string): Promise<string> {
    const provider = this.getProvider(providerId);
    return await provider.getDownloadUrl(path, expiresIn);
  }

  async deleteFile(path: string, providerId?: string): Promise<void> {
    const provider = this.getProvider(providerId);
    await provider.delete(path);
  }
}

export const storageManager = new StorageManager();
