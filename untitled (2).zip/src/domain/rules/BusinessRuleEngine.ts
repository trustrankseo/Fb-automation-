import { BusinessException } from '../exceptions/BusinessException';

export interface BusinessRule<T> {
  name: string;
  evaluate: (context: T) => Promise<boolean> | boolean;
  errorMessage: string;
}

export class BusinessRuleEngine<T> {
  private rules: BusinessRule<T>[] = [];

  addRule(rule: BusinessRule<T>) {
    this.rules.push(rule);
    return this;
  }

  async evaluateAll(context: T): Promise<void> {
    for (const rule of this.rules) {
      const isValid = await rule.evaluate(context);
      if (!isValid) {
        throw new BusinessException(rule.errorMessage, 'BUSINESS_RULE_VIOLATION', 422);
      }
    }
  }
}
