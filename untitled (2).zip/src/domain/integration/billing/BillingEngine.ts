
export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'succeeded' | 'failed';
  customerId: string;
}

export interface Subscription {
  id: string;
  planId: string;
  customerId: string;
  status: 'active' | 'past_due' | 'canceled' | 'trialing';
  currentPeriodEnd: Date;
}

export interface BillingProvider {
  id: string;
  createPaymentIntent(amount: number, currency: string, customerId: string): Promise<PaymentIntent>;
  createSubscription(customerId: string, planId: string): Promise<Subscription>;
  cancelSubscription(subscriptionId: string): Promise<Subscription>;
}

export class BillingEngine {
  private provider: BillingProvider | null = null;

  setProvider(provider: BillingProvider) {
    this.provider = provider;
  }

  async charge(amount: number, currency: string, customerId: string): Promise<PaymentIntent> {
    if (!this.provider) throw new Error('No billing provider configured');
    console.log(`[BillingEngine] Charging ${amount} ${currency} to ${customerId}`);
    return await this.provider.createPaymentIntent(amount, currency, customerId);
  }
}

export const billingEngine = new BillingEngine();
