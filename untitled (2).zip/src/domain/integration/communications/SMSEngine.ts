
export interface SMSOptions {
  to: string;
  message: string;
  from?: string;
}

export interface SMSProvider {
  id: string;
  send(options: SMSOptions): Promise<boolean>;
}

export class SMSEngine {
  private provider: SMSProvider | null = null;

  setProvider(provider: SMSProvider) {
    this.provider = provider;
  }

  async send(options: SMSOptions): Promise<boolean> {
    if (!this.provider) throw new Error('No SMS provider configured');
    
    console.log(`[SMSEngine] Sending SMS to ${options.to}`);
    return await this.provider.send(options);
  }
}

export const smsEngine = new SMSEngine();
