
export interface EmailOptions {
  to: string | string[];
  from?: string;
  subject: string;
  text?: string;
  html?: string;
  templateId?: string;
  variables?: Record<string, any>;
  attachments?: any[];
}

export interface EmailProvider {
  id: string;
  send(options: EmailOptions): Promise<boolean>;
}

export class EmailEngine {
  private provider: EmailProvider | null = null;

  setProvider(provider: EmailProvider) {
    this.provider = provider;
  }

  async send(options: EmailOptions): Promise<boolean> {
    if (!this.provider) throw new Error('No email provider configured');
    
    console.log(`[EmailEngine] Sending email to ${options.to}`);
    return await this.provider.send(options);
  }
}

export const emailEngine = new EmailEngine();
