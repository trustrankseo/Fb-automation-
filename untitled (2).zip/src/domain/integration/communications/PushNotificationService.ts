
export interface PushOptions {
  token: string;
  title: string;
  body: string;
  data?: Record<string, any>;
}

export class PushNotificationService {
  async send(options: PushOptions): Promise<boolean> {
    console.log(`[PushService] Sending push to ${options.token}`);
    return true; // Mock success
  }
}

export const pushNotificationService = new PushNotificationService();
