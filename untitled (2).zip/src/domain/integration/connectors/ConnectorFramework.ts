
export interface ExternalConnector {
  id: string;
  name: string;
  authenticate(credentials: any): Promise<boolean>;
  executeAction(action: string, params: any): Promise<any>;
}

export class ConnectorFramework {
  private connectors: Map<string, ExternalConnector> = new Map();

  register(connector: ExternalConnector) {
    this.connectors.set(connector.id, connector);
  }

  async runAction(connectorId: string, action: string, params: any): Promise<any> {
    const connector = this.connectors.get(connectorId);
    if (!connector) throw new Error(`Connector ${connectorId} not found`);
    
    console.log(`[ConnectorFramework] Executing ${action} on ${connectorId}`);
    return await connector.executeAction(action, params);
  }
}

export const connectorFramework = new ConnectorFramework();
