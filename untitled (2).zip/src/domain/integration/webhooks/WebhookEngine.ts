
import * as crypto from 'crypto';

export interface WebhookEndpoint {
  id: string;
  url: string;
  secret: string;
  events: string[];
  isActive: boolean;
}

export class WebhookEngine {
  private endpoints: WebhookEndpoint[] = [];

  registerEndpoint(endpoint: WebhookEndpoint) {
    this.endpoints.push(endpoint);
  }

  generateSignature(payload: any, secret: string): string {
    const hmac = crypto.createHmac('sha256', secret);
    const data = JSON.stringify(payload);
    hmac.update(data);
    return hmac.digest('hex');
  }

  validateSignature(payload: any, signature: string, secret: string): boolean {
    const expected = this.generateSignature(payload, secret);
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  }

  async dispatch(event: string, payload: any): Promise<void> {
    const targets = this.endpoints.filter(e => e.isActive && (e.events.includes('*') || e.events.includes(event)));
    
    for (const target of targets) {
      // In a real app, enqueue this for background processing
      console.log(`[WebhookEngine] Dispatching ${event} to ${target.url}`);
    }
  }
}

export const webhookEngine = new WebhookEngine();
