
export interface IntegrationProvider {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'inactive' | 'error';
  healthCheck(): Promise<boolean>;
}

export class IntegrationManager {
  private providers: Map<string, IntegrationProvider> = new Map();

  registerProvider(provider: IntegrationProvider) {
    this.providers.set(provider.id, provider);
  }

  getProvider(id: string): IntegrationProvider | undefined {
    return this.providers.get(id);
  }

  async checkHealth(): Promise<Record<string, boolean>> {
    const health: Record<string, boolean> = {};
    for (const [id, provider] of this.providers.entries()) {
      try {
        health[id] = await provider.healthCheck();
      } catch (error) {
        health[id] = false;
      }
    }
    return health;
  }
}

export const integrationManager = new IntegrationManager();
