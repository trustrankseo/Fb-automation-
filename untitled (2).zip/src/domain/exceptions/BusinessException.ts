export class BusinessException extends Error {
  constructor(public message: string, public code: string, public statusCode: number = 400) {
    super(message);
    this.name = 'BusinessException';
  }
}

export class ValidationException extends BusinessException {
  constructor(public errors: Record<string, string[]>) {
    super('Validation failed', 'VALIDATION_ERROR', 400);
  }
}

export class PermissionException extends BusinessException {
  constructor(message: string = 'Permission denied') {
    super(message, 'FORBIDDEN', 403);
  }
}

export class ResourceNotFoundException extends BusinessException {
  constructor(resource: string) {
    super(`${resource} not found`, 'NOT_FOUND', 404);
  }
}

export class ConflictException extends BusinessException {
  constructor(message: string) {
    super(message, 'CONFLICT', 409);
  }
}
