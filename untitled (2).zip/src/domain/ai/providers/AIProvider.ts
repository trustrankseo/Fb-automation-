
export interface AIProviderOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  stopSequences?: string[];
  tools?: any[];
}

export interface AIProvider {
  id: string;
  name: string;
  generateText(prompt: string, options?: AIProviderOptions): Promise<string>;
  generateStream(prompt: string, options?: AIProviderOptions): AsyncGenerator<string, void, unknown>;
  generateStructured<T>(prompt: string, schema: any, options?: AIProviderOptions): Promise<T>;
}
