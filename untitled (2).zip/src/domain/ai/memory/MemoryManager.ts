
export interface MemoryMessage {
  id: string;
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  timestamp: Date;
}

export class MemoryManager {
  private sessions: Map<string, MemoryMessage[]> = new Map();

  async addMessage(sessionId: string, message: MemoryMessage): Promise<void> {
    const history = this.sessions.get(sessionId) || [];
    history.push(message);
    this.sessions.set(sessionId, history);
  }

  async getHistory(sessionId: string, limit: number = 50): Promise<MemoryMessage[]> {
    const history = this.sessions.get(sessionId) || [];
    return history.slice(-limit);
  }

  async summarize(sessionId: string): Promise<string> {
    // In a real app, this would use an LLM to compress older messages
    return "Summary of previous conversation...";
  }
}

export const memoryManager = new MemoryManager();
