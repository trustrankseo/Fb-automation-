
import { AIProviderOptions } from '../providers/AIProvider';
import { aiOrchestrator } from '../AIOrchestrator';

export interface AgentTask {
  id: string;
  goal: string;
  context?: string;
}

export class Agent {
  constructor(
    public id: string,
    public role: string,
    public systemPrompt: string,
    public tools: any[] = []
  ) {}

  async execute(task: AgentTask): Promise<string> {
    const prompt = `
      System: ${this.systemPrompt}
      Task: ${task.goal}
      Context: ${task.context || ''}
    `;
    
    return await aiOrchestrator.generateText(prompt, { tools: this.tools });
  }
}

export class MultiAgentOrchestrator {
  private agents: Map<string, Agent> = new Map();

  registerAgent(agent: Agent) {
    this.agents.set(agent.id, agent);
  }

  async delegate(taskId: string, goal: string, agentId: string): Promise<string> {
    const agent = this.agents.get(agentId);
    if (!agent) throw new Error(`Agent ${agentId} not found`);
    
    return await agent.execute({ id: taskId, goal });
  }
}

export const multiAgentOrchestrator = new MultiAgentOrchestrator();
