
import { AIProvider, AIProviderOptions } from './providers/AIProvider';
import { aiAnalytics } from './AIAnalytics';

export class AIOrchestrator {
  private providers: Map<string, AIProvider> = new Map();
  private defaultProvider: string | null = null;

  registerProvider(provider: AIProvider, isDefault: boolean = false) {
    this.providers.set(provider.id, provider);
    if (isDefault || !this.defaultProvider) {
      this.defaultProvider = provider.id;
    }
  }

  getProvider(providerId?: string): AIProvider {
    const id = providerId || this.defaultProvider;
    if (!id) throw new Error('No AI provider registered');
    const provider = this.providers.get(id);
    if (!provider) throw new Error(`Provider ${id} not found`);
    return provider;
  }

  async generateText(prompt: string, options?: AIProviderOptions & { providerId?: string }): Promise<string> {
    const startTime = Date.now();
    const provider = this.getProvider(options?.providerId);
    
    try {
      const response = await provider.generateText(prompt, options);
      
      aiAnalytics.recordExecution({
        provider: provider.id,
        durationMs: Date.now() - startTime,
        status: 'success'
      });
      
      return response;
    } catch (error: any) {
      aiAnalytics.recordExecution({
        provider: provider.id,
        durationMs: Date.now() - startTime,
        status: 'error',
        error: error.message
      });
      // Basic failover logic would go here
      throw error;
    }
  }

  async *generateStream(prompt: string, options?: AIProviderOptions & { providerId?: string }) {
    const provider = this.getProvider(options?.providerId);
    yield* provider.generateStream(prompt, options);
  }
}

export const aiOrchestrator = new AIOrchestrator();
