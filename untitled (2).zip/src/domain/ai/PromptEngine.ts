
export interface PromptTemplate {
  id: string;
  name: string;
  template: string;
  variables: string[];
  version: number;
}

export class PromptEngine {
  private templates: Map<string, PromptTemplate> = new Map();

  registerTemplate(template: PromptTemplate) {
    this.templates.set(template.id, template);
  }

  render(templateId: string, variables: Record<string, string>): string {
    const template = this.templates.get(templateId);
    if (!template) throw new Error(`Template ${templateId} not found`);

    let rendered = template.template;
    for (const [key, value] of Object.entries(variables)) {
      rendered = rendered.replace(new RegExp(`{{s*${key}s*}}`, 'g'), value);
    }
    
    return rendered;
  }
}

export const promptEngine = new PromptEngine();
