
export interface AIExecutionLog {
  provider: string;
  durationMs: number;
  status: 'success' | 'error';
  error?: string;
  tokensUsed?: number;
  estimatedCost?: number;
}

export class AIAnalytics {
  private logs: AIExecutionLog[] = [];

  recordExecution(log: AIExecutionLog) {
    this.logs.push(log);
    // In reality, push to time-series DB or log stream
    console.log('[AI Analytics] Execution recorded', log);
  }
  
  getMetrics() {
    return {
      totalExecutions: this.logs.length,
      successRate: this.logs.filter(l => l.status === 'success').length / (this.logs.length || 1),
      avgLatency: this.logs.reduce((acc, l) => acc + l.durationMs, 0) / (this.logs.length || 1)
    };
  }
}

export const aiAnalytics = new AIAnalytics();
