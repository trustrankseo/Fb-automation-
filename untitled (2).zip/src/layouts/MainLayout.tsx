import React from 'react';
import { Outlet } from 'react-router-dom';
import { cn } from '../utils/cn';

export function MainLayout({ className }: { className?: string }) {
  return (
    <div className={cn("min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-50 flex flex-col", className)}>
      <header className="h-16 border-b border-slate-200 dark:border-slate-800 flex items-center px-6">
        <h1 className="text-xl font-semibold">EMCAS Enterprise</h1>
      </header>
      <div className="flex flex-1 overflow-hidden">
        <aside className="w-64 border-r border-slate-200 dark:border-slate-800 p-4 hidden md:block">
          <nav className="space-y-2">
            <div className="px-3 py-2 text-sm font-medium rounded-md bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-white">Dashboard</div>
            <div className="px-3 py-2 text-sm font-medium rounded-md text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900">Workspaces</div>
            <div className="px-3 py-2 text-sm font-medium rounded-md text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900">Projects</div>
            <div className="px-3 py-2 text-sm font-medium rounded-md text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900">Settings</div>
          </nav>
        </aside>
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
