import { eq, and, isNull } from 'drizzle-orm';

// Repository Pattern Implementation
export class BaseRepository<T extends { id: any, deletedAt?: any }> {
  constructor(
    protected readonly db: any,
    protected readonly table: any
  ) {}

  async findById(id: string) {
    const result = await this.db
      .select()
      .from(this.table)
      .where(and(eq(this.table.id, id), isNull(this.table.deletedAt)))
      .limit(1);
    return result[0];
  }

  async softDelete(id: string, deletedBy: string) {
    return await this.db
      .update(this.table)
      .set({
        deletedAt: new Date(),
        deletedBy: deletedBy,
        updatedAt: new Date()
      })
      .where(eq(this.table.id, id))
      .returning();
  }

  async restore(id: string, updatedBy: string) {
    return await this.db
      .update(this.table)
      .set({
        deletedAt: null,
        deletedBy: null,
        updatedBy: updatedBy,
        updatedAt: new Date()
      })
      .where(eq(this.table.id, id))
      .returning();
  }
}
