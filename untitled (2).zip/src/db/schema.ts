import { pgTable, text, timestamp, integer, uuid, boolean, jsonb } from 'drizzle-orm/pg-core';

// Base Entity matching the requested specification
export const baseEntity = {
  id: uuid('id').primaryKey().defaultRandom(),
  version: integer('version').default(1).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  deletedAt: timestamp('deleted_at'),
  createdBy: uuid('created_by'),
  updatedBy: uuid('updated_by'),
  deletedBy: uuid('deleted_by'),
};

// Multi-Tenancy Columns
export const tenantColumns = {
  organizationId: uuid('organization_id'),
  workspaceId: uuid('workspace_id'),
  projectId: uuid('project_id'),
};

// Example Table using the Base Entity and Tenant specs
export const users = pgTable('users', {
  ...baseEntity,
  ...tenantColumns,
  email: text('email').notNull().unique(),
  name: text('name').notNull(),
  role: text('role').notNull().default('user'),
  isActive: boolean('is_active').default(true).notNull(),
});

// Audit Trail Table
export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  tableName: text('table_name').notNull(),
  recordId: uuid('record_id').notNull(),
  action: text('action').notNull(), // INSERT, UPDATE, DELETE, RESTORE
  changes: jsonb('changes'),
  performedBy: uuid('performed_by'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  ...tenantColumns,
});
