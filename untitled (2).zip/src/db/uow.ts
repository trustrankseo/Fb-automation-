// Unit of Work pattern implementation for Drizzle
export class UnitOfWork {
  constructor(private db: any) {}

  async transaction<T>(callback: (tx: any) => Promise<T>): Promise<T> {
    // Note: 'any' is used here to avoid complex generic Drizzle types in this template
    return await this.db.transaction(async (tx: any) => {
      try {
        const result = await callback(tx);
        return result;
      } catch (error) {
        console.error('Transaction rollback due to error:', error);
        throw error; // Transaction automatically rolls back on throw
      }
    });
  }
}
