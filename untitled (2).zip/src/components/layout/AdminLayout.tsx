import { Outlet, Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Users, Shield, Settings, Database, Server, Activity, ArrowLeft, History } from "lucide-react";

export function AdminLayout() {
  const location = useLocation();
  
  const navigation = [
    { name: "Overview", href: "/admin/dashboard", icon: LayoutDashboard },
    { name: "Organizations", href: "/admin/organizations", icon: Database },
    { name: "Users", href: "/admin/users", icon: Users },
    { name: "Roles & Perms", href: "/admin/roles", icon: Shield },
    { name: "System Settings", href: "/admin/settings", icon: Settings },
    { name: "Workers", href: "/admin/workers", icon: Server },
    { name: "Monitoring", href: "/admin/monitoring", icon: Activity },
    { name: "Audit Logs", href: "/admin/audit", icon: History },
  ];


  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <Link to="/dashboard" className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <span className="font-semibold tracking-tight text-foreground">Admin Console</span>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
                  isActive ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-background">
        <Outlet />
      </main>
    </div>
  );
}
