import { Outlet, Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Settings, Layers, DownloadCloud, UploadCloud, Users, Bell, Activity, Menu, X, Bot, MessageSquare, PenTool, BookOpen, GitMerge, Workflow, BarChart, PieChart, FileText, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { Search, Command } from "lucide-react";
import { useTheme } from "../../providers/ThemeProvider";
import { Sun, Moon, LogOut } from "lucide-react";
import { useAuthStore } from "../../store/authStore";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export function MainLayout() {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { user, isAuthenticated, logout, checkAuth } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth/login');
    }
  }, [isAuthenticated, navigate]);

  const handleLogout = () => {
    logout();
    navigate('/auth/login');
  };

  
  
  
  const navigation = [
    { name: "Overview", href: "/dashboard", icon: LayoutDashboard },
    { name: "Workspace", href: "/workspace", icon: Layers },
    { name: "File Manager", href: "/files", icon: DownloadCloud },
    { name: "Storage", href: "/storage", icon: UploadCloud },
    { name: "Downloads", href: "/downloads", icon: Activity },
    { name: "AI Center", href: "/ai-center", icon: Bot },
    { name: "AI Chat", href: "/chat", icon: MessageSquare },
    { name: "Prompt Studio", href: "/prompts", icon: PenTool },
    { name: "Knowledge Base", href: "/knowledge", icon: BookOpen },
    { name: "Workflows", href: "/workflows", icon: GitMerge },
    { name: "Automation", href: "/automation", icon: Workflow },
    { name: "Analytics", href: "/analytics", icon: PieChart },
    { name: "Reports", href: "/reports", icon: FileText },
    { name: "Admin Console", href: "/admin", icon: ShieldAlert },
    { name: "Settings", href: "/settings", icon: Settings },
  ];




  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 border-r border-border bg-card flex flex-col transition-transform duration-300 ease-in-out md:translate-x-0 md:static
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold font-mono text-sm">EM</span>
            </div>
            <span className="font-semibold tracking-tight text-foreground">EMCAS</span>
          </div>
          <button 
            className="md:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
                  isActive
                    ? "bg-secondary text-secondary-foreground"
                    : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center border border-border">
              <span className="text-xs font-medium text-muted-foreground">U</span>
            </div>
            <div className="flex flex-col truncate">
              <span className="text-sm font-medium truncate">{user?.name || 'User'}</span>
              <span className="text-xs text-muted-foreground truncate">{user?.email || 'admin@enterprise.com'}</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-border bg-card flex items-center justify-between px-4 sm:px-6 shrink-0">
          <div className="flex items-center gap-4">

            <div className="relative hidden md:flex items-center">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search..."
                className="flex h-9 w-[300px] rounded-md border border-input bg-background pl-9 pr-4 py-2 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
              <div className="absolute right-2 top-2 flex items-center gap-1 text-xs text-muted-foreground">
                <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
                  <span className="text-xs">⌘</span>K
                </kbd>
              </div>
            </div>

            <button 
              className="md:hidden p-2 -ml-2 rounded-md hover:bg-secondary text-muted-foreground"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-sm font-medium text-muted-foreground hidden sm:block">
              Organization: <span className="text-foreground font-semibold">None Selected</span>
            </h1>
            <h1 className="text-sm font-medium text-foreground sm:hidden font-semibold">
              Select Org
            </h1>
          </div>
          <div className="flex items-center gap-4">
            
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="p-2 rounded-full hover:bg-secondary text-muted-foreground transition-colors relative"
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button className="p-2 rounded-full hover:bg-secondary text-muted-foreground transition-colors relative">

              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-destructive border border-card"></span>
            </button>
            <button onClick={handleLogout} className="p-2 rounded-full hover:bg-secondary text-muted-foreground transition-colors relative" title="Logout">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-background">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
