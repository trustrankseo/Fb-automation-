import React from 'react';
import { Outlet, Link, useLocation } from "react-router-dom";
import { User, Shield, Key, CreditCard, Bell, ArrowLeft, Building, Palette, Settings } from "lucide-react";

export function SettingsLayout() {
  const location = useLocation();
  const navigation = [
    { name: "General", href: "/settings/general", icon: Settings },
    { name: "Profile", href: "/settings/profile", icon: User },
    { name: "Security", href: "/settings/security", icon: Shield },
    { name: "API Keys", href: "/settings/api-keys", icon: Key },
    { name: "Organization", href: "/settings/organization", icon: Building },
    { name: "Billing", href: "/settings/billing", icon: CreditCard },
    { name: "Appearance", href: "/settings/appearance", icon: Palette },
    { name: "Notifications", href: "/settings/notifications", icon: Bell },
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] bg-background overflow-hidden">
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          <div className="text-xs font-medium text-muted-foreground px-3 py-2 uppercase tracking-wider">Personal</div>
          {navigation.slice(0, 4).map((item) => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
                  isActive ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
          
          <div className="text-xs font-medium text-muted-foreground px-3 py-2 uppercase tracking-wider mt-4">Workspace</div>
          {navigation.slice(4).map((item) => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
                  isActive ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-background">
        <div className="max-w-4xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
