import React from 'react';

interface CodeEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  readOnly?: boolean;
}

export function CodeEditor({ value, onChange, language = 'javascript', readOnly = false }: CodeEditorProps) {
  return (
    <div className="relative rounded-md overflow-hidden border border-border bg-[#1e1e1e] font-mono text-sm text-[#d4d4d4]">
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-white/5">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">{language}</span>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        readOnly={readOnly}
        className="w-full min-h-[300px] bg-transparent p-4 outline-none resize-y"
        spellCheck={false}
      />
    </div>
  );
}
