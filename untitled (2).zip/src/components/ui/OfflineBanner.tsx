import React from 'react';
import { WifiOff } from 'lucide-react';
import { useNetworkStatus } from '../../hooks/useNetworkStatus';

export function OfflineBanner() {
  const isOnline = useNetworkStatus();

  if (isOnline) return null;

  return (
    <div className="bg-amber-500 text-white p-2 text-sm flex items-center justify-center gap-2 z-50 relative">
      <WifiOff className="w-4 h-4" />
      <span className="font-medium">You are currently offline. Changes will be synced when your connection is restored.</span>
    </div>
  );
}
