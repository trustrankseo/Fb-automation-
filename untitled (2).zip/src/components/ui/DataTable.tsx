import React from 'react';
import { Search, ChevronLeft, ChevronRight, ChevronDown } from 'lucide-react';
import { Input } from './Input';
import { Button } from './Button';

interface Column<T> {
  key: keyof T | string;
  header: string;
  render?: (item: T) => React.ReactNode;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  searchable?: boolean;
  searchPlaceholder?: string;
}

export function DataTable<T>({ data, columns, searchable = true, searchPlaceholder = "Search..." }: DataTableProps<T>) {
  return (
    <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden flex flex-col">
      {searchable && (
        <div className="p-4 border-b border-border bg-background flex items-center justify-between">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9 w-[300px]" placeholder={searchPlaceholder} />
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            Filter <ChevronDown className="w-4 h-4" />
          </Button>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase">
            <tr>
              {columns.map((col, i) => (
                <th key={String(col.key)} className="px-6 py-3 font-medium">
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {data.map((row, i) => (
              <tr key={i} className="hover:bg-secondary/20 transition-colors">
                {columns.map((col, j) => (
                  <td key={String(col.key)} className="px-6 py-4">
                    {col.render ? col.render(row) : String((row as any)[col.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="p-4 border-t border-border flex items-center justify-between bg-background">
        <span className="text-sm text-muted-foreground">Showing 1 to {data.length} of {data.length} entries</span>
        <div className="flex gap-1">
          <Button variant="outline" size="icon" className="h-8 w-8"><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="outline" size="icon" className="h-8 w-8"><ChevronRight className="w-4 h-4" /></Button>
        </div>
      </div>
    </div>
  );
}
