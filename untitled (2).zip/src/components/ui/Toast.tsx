import React from 'react';
import { X, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { Button } from './Button';

interface ToastProps {
  title: string;
  description?: string;
  variant?: 'default' | 'success' | 'destructive';
  onClose: () => void;
}

export function Toast({ title, description, variant = 'default', onClose }: ToastProps) {
  const variants = {
    default: { bg: 'bg-card', border: 'border-border', icon: Info, iconColor: 'text-primary' },
    success: { bg: 'bg-card', border: 'border-emerald-500/50', icon: CheckCircle, iconColor: 'text-emerald-500' },
    destructive: { bg: 'bg-destructive/10', border: 'border-destructive/50', icon: AlertCircle, iconColor: 'text-destructive' }
  };

  const currentVariant = variants[variant];
  const Icon = currentVariant.icon;

  return (
    <div className={`pointer-events-auto w-full max-w-sm overflow-hidden rounded-lg border ${currentVariant.border} ${currentVariant.bg} shadow-lg ring-1 ring-black ring-opacity-5`}>
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <Icon className={`h-5 w-5 ${currentVariant.iconColor}`} aria-hidden="true" />
          </div>
          <div className="ml-3 w-0 flex-1 pt-0.5">
            <p className="text-sm font-medium">{title}</p>
            {description && (
              <p className="mt-1 text-sm text-muted-foreground">{description}</p>
            )}
          </div>
          <div className="ml-4 flex flex-shrink-0">
            <Button variant="ghost" size="icon" onClick={onClose} className="h-6 w-6">
              <span className="sr-only">Close</span>
              <X className="h-4 w-4" aria-hidden="true" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
