
export const analytics = {
  trackPage: (path: string) => {
    console.log(`[Analytics] Page View: ${path}`);
  },
  trackEvent: (category: string, action: string, label?: string, value?: number) => {
    console.log(`[Analytics] Event: ${category} - ${action}`, { label, value });
  }
};
