
type Locale = 'en' | 'es' | 'fr';

let currentLocale: Locale = 'en';

const translations: Record<Locale, Record<string, string>> = {
  en: {
    welcome: 'Welcome',
    settings: 'Settings'
  },
  es: {
    welcome: 'Bienvenido',
    settings: 'Configuraciones'
  },
  fr: {
    welcome: 'Bienvenue',
    settings: 'Paramètres'
  }
};

export const i18n = {
  setLocale: (locale: Locale) => {
    currentLocale = locale;
  },
  getLocale: () => currentLocale,
  t: (key: string): string => {
    return translations[currentLocale]?.[key] || key;
  }
};
