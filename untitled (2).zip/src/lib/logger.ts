
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

class Logger {
  private level: LogLevel = 'info';

  setLevel(level: LogLevel) {
    this.level = level;
  }

  private shouldLog(level: LogLevel) {
    const levels: LogLevel[] = ['debug', 'info', 'warn', 'error'];
    return levels.indexOf(level) >= levels.indexOf(this.level);
  }

  debug(message: string, meta?: any) {
    if (this.shouldLog('debug')) console.debug(`[DEBUG] ${message}`, meta || '');
  }

  info(message: string, meta?: any) {
    if (this.shouldLog('info')) console.info(`[INFO] ${message}`, meta || '');
  }

  warn(message: string, meta?: any) {
    if (this.shouldLog('warn')) console.warn(`[WARN] ${message}`, meta || '');
  }

  error(message: string, error?: any) {
    if (this.shouldLog('error')) console.error(`[ERROR] ${message}`, error || '');
  }
}

export const logger = new Logger();
