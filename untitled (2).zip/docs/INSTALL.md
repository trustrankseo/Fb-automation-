# Production Installation Guide

## Prerequisites
- Docker & Docker Compose
- Node.js 20+
- PostgreSQL 15+
- Redis 7+

## Environment Setup
1. Copy \`.env.example\` to \`.env\`
2. Configure all database passwords and API keys.

## Build and Start
\`\`\`bash
npm run build
npm start
\`\`\`
