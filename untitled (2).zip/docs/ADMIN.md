# Administrator Guide

## Managing Users
Use the Admin Dashboard \`/admin\` to view and manage tenants, user roles, and subscription limits.

## Security
- Rate limiting is enabled globally
- Helmet is used for HTTP headers
- Ensure \`TRUST_PROXY\` is configured correctly for your load balancer/Ingress.
