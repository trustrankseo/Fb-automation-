# API Documentation

## OpenAPI/Swagger
Access the Swagger documentation at \`/api/docs\` when running locally.

### Endpoints
- \`POST /api/v1/auth/login\`: Authenticate user
- \`POST /api/v1/auth/register\`: Register new user
- \`GET /api/v1/users/me\`: Get current user profile
- \`GET /api/v1/health\`: System health check
