# Deployment Guide

This application is ready for Blue-Green and Canary deployments.

## CI/CD Pipeline
- GitHub Actions pipeline is configured in \`.github/workflows/ci-cd.yml\`
- Automatically runs tests and builds Docker images on push to main/staging.

## Kubernetes Strategy
We use rolling updates for our Deployment (\`emcas-web\`) which ensures zero downtime during deployment.
