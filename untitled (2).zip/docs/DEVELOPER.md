# Developer Guide

## Architecture
- \`src/\`: React frontend
- \`server/\`: Express backend
- \`server/presentation\`: API Controllers and Routes
- \`server/application\`: DTOs and Validation
- \`server/infrastructure\`: Services and DB config

## Adding New Features
1. Create Database Schema in \`drizzle\`
2. Generate DTOs in \`server/application/dtos\`
3. Create Controller in \`server/presentation/controllers\`
4. Mount Routes in \`server/presentation/routes\`
5. Build React Components in \`src/features\`
