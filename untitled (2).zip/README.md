# Enterprise SaaS Platform (EMCAS)

A full-stack, production-ready enterprise application with integrated AI capabilities.

## Features

- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Backend**: Express, TypeScript, Zod Validation, Rate Limiting
- **Database**: PostgreSQL (via Drizzle ORM) + Redis for caching/queue
- **AI Integrations**: Gemini API Integration
- **Infrastructure**: Docker, Kubernetes, NGINX, GitHub Actions CI/CD

## Testing

The application includes a comprehensive testing suite using Vitest, React Testing Library, and Supertest.

Run tests:
\`\`\`bash
npm run test           # Run all tests
npm run test:watch     # Run in watch mode
npm run test:coverage  # Generate coverage reports
\`\`\`

## Production Deployment

### Docker

To run the application using Docker Compose:
\`\`\`bash
docker-compose -f docker-compose.prod.yml up --build -d
\`\`\`

### Kubernetes

Deploy to Kubernetes using Kustomize:
\`\`\`bash
kubectl apply -k k8s/base
\`\`\`

## Guides

- [Production Installation Guide](docs/INSTALL.md)
- [Deployment Guide](docs/DEPLOY.md)
- [Administrator Guide](docs/ADMIN.md)
- [Developer Guide](docs/DEVELOPER.md)
- [API Documentation](docs/API.md)

