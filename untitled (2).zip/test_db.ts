import * as schema from './server/infrastructure/database/schema.js';
console.log('Schema imported successfully', Object.keys(schema).length, 'tables/exports found.');
