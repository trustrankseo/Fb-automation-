import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import helmet from "helmet";
import "dotenv/config";
import rateLimit from "express-rate-limit";
import { requestLogger } from "./server/presentation/middlewares/requestLogger.js";
import { errorHandler, notFoundHandler } from "./server/presentation/middlewares/errorHandler.js";
import { sendSuccess } from "./server/presentation/utils/apiResponse.js";
import aiRoutes from "./server/presentation/routes/ai.routes.js";
import organizationRoutes from "./server/presentation/routes/organization.routes.js";
import projectRoutes from "./server/presentation/routes/project.routes.js";
import sourceRoutes from "./server/presentation/routes/source.routes.js";
import publishingRoutes from "./server/presentation/routes/publishing.routes.js";
import userRoutes from "./server/presentation/routes/user.routes.js";
import jobRoutes from "./server/presentation/routes/job.routes.js";
import authRoutes from "./server/presentation/routes/auth.routes.js";
import roleRoutes from "./server/presentation/routes/role.routes.js";
import permissionRoutes from "./server/presentation/routes/permission.routes.js";
import sessionRoutes from "./server/presentation/routes/session.routes.js";
import apiKeyRoutes from "./server/presentation/routes/apiKey.routes.js";
import workspaceRoutes from "./server/presentation/routes/workspace.routes.js";
import folderRoutes from "./server/presentation/routes/folder.routes.js";
import fileRoutes from "./server/presentation/routes/file.routes.js";
import attachmentRoutes from "./server/presentation/routes/attachment.routes.js";
import storageRoutes from "./server/presentation/routes/storage.routes.js";
import searchRoutes from "./server/presentation/routes/search.routes.js";
import notificationRoutes from "./server/presentation/routes/notification.routes.js";
import analyticsRoutes from "./server/presentation/routes/analytics.routes.js";
import reportRoutes from "./server/presentation/routes/report.routes.js";
import dashboardRoutes from "./server/presentation/routes/dashboard.routes.js";
import webhookRoutes from "./server/presentation/routes/webhook.routes.js";
import pluginRoutes from "./server/presentation/routes/plugin.routes.js";
import systemRoutes from "./server/presentation/routes/system.routes.js";
import observabilityRoutes from "./server/presentation/routes/observability.routes.js";
import subscriptionRoutes from "./server/presentation/routes/subscription.routes.js";
import planRoutes from "./server/presentation/routes/plan.routes.js";
import invoiceRoutes from "./server/presentation/routes/invoice.routes.js";
import paymentRoutes from "./server/presentation/routes/payment.routes.js";
import licenseRoutes from "./server/presentation/routes/license.routes.js";
import featureFlagRoutes from "./server/presentation/routes/featureFlag.routes.js";
import usageRoutes from "./server/presentation/routes/usage.routes.js";
import billingRoutes from "./server/presentation/routes/billing.routes.js";
import securityPolicyRoutes from "./server/presentation/routes/securityPolicy.routes.js";
import complianceRoutes from "./server/presentation/routes/compliance.routes.js";
import auditRoutes from "./server/presentation/routes/audit.routes.js";
import backupRoutes from "./server/presentation/routes/backup.routes.js";
import disasterRecoveryRoutes from "./server/presentation/routes/disasterRecovery.routes.js";
import encryptionKeyRoutes from "./server/presentation/routes/encryptionKey.routes.js";
import healthRoutes from "./server/presentation/routes/health.routes.js";
import environmentRoutes from "./server/presentation/routes/environment.routes.js";
import deploymentRoutes from "./server/presentation/routes/deployment.routes.js";
import buildRoutes from "./server/presentation/routes/build.routes.js";
import pipelineRoutes from "./server/presentation/routes/pipeline.routes.js";
import releaseRoutes from "./server/presentation/routes/release.routes.js";
import infrastructureRoutes from "./server/presentation/routes/infrastructure.routes.js";
import containerRoutes from "./server/presentation/routes/container.routes.js";
import secretRoutes from "./server/presentation/routes/secret.routes.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Trust reverse proxy for rate limiting to work correctly in Cloud Run
  app.set("trust proxy", 1);

  // Basic middleware
  app.use(cors());
  app.use(helmet({ contentSecurityPolicy: false })); // Disabled CSP for dev preview iframe compatibility
  app.use(express.json());

  // Observability & Request Tracking
  app.use(requestLogger);

  // Rate Limiting
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, trustProxy: false },
    message: {
      success: false,
      error: {
        code: "RATE_LIMIT_EXCEEDED",
        message: "Too many requests from this IP, please try again after 15 minutes."
      }
    }
  });

  // Apply rate limiter to API routes
  app.use("/api/v1/", apiLimiter);

  // API Routes - EMCAS Architecture
  app.use("/api/v1/health", healthRoutes);

  app.use("/api/v1/ai", aiRoutes);
  app.use("/api/v1/organizations", organizationRoutes);
  app.use("/api/v1/projects", projectRoutes);
  app.use("/api/v1/sources", sourceRoutes);
  app.use("/api/v1/publishing", publishingRoutes);
  app.use("/api/v1/users", userRoutes);
  app.use("/api/v1/jobs", jobRoutes);
  app.use("/api/v1/auth", authRoutes);
  app.use("/api/v1/roles", roleRoutes);
  app.use("/api/v1/permissions", permissionRoutes);
  app.use("/api/v1/sessions", sessionRoutes);
  app.use("/api/v1/api-keys", apiKeyRoutes);
  app.use("/api/v1/workspaces", workspaceRoutes);
  app.use("/api/v1/folders", folderRoutes);
  app.use("/api/v1/files", fileRoutes);
  app.use("/api/v1/attachments", attachmentRoutes);
  app.use("/api/v1/storage", storageRoutes);
  app.use("/api/v1/search", searchRoutes);
  app.use("/api/v1/notifications", notificationRoutes);
  app.use("/api/v1/analytics", analyticsRoutes);
  app.use("/api/v1/reports", reportRoutes);
  app.use("/api/v1/dashboards", dashboardRoutes);
  app.use("/api/v1/webhooks", webhookRoutes);
  app.use("/api/v1/plugins", pluginRoutes);
  app.use("/api/v1/system", systemRoutes);
  app.use("/api/v1/observability", observabilityRoutes);
  app.use("/api/v1/subscriptions", subscriptionRoutes);
  app.use("/api/v1/plans", planRoutes);
  app.use("/api/v1/invoices", invoiceRoutes);
  app.use("/api/v1/payments", paymentRoutes);
  app.use("/api/v1/licenses", licenseRoutes);
  app.use("/api/v1/feature-flags", featureFlagRoutes);
  app.use("/api/v1/usage", usageRoutes);
  app.use("/api/v1/billing", billingRoutes);
  app.use("/api/v1/security/policies", securityPolicyRoutes);
  app.use("/api/v1/compliance", complianceRoutes);
  app.use("/api/v1/audit", auditRoutes);
  app.use("/api/v1/backups", backupRoutes);
  app.use("/api/v1/disaster-recovery", disasterRecoveryRoutes);
  app.use("/api/v1/security/keys", encryptionKeyRoutes);
  app.use("/api/v1/environments", environmentRoutes);
  app.use("/api/v1/deployments", deploymentRoutes);
  app.use("/api/v1/builds", buildRoutes);
  app.use("/api/v1/pipelines", pipelineRoutes);
  app.use("/api/v1/releases", releaseRoutes);
  app.use("/api/v1/infrastructure", infrastructureRoutes);
  app.use("/api/v1/containers", containerRoutes);
  app.use("/api/v1/secrets", secretRoutes);

  // Handle API 404
  app.use("/api/v1/*", notFoundHandler);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Global Error Handler
  app.use(errorHandler);

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EMCAS Server running on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start EMCAS server:", err);
  process.exit(1);
});
