const fs = require('fs');

const files = [
  'server/infrastructure/database/OrganizationRepository.ts',
  'server/infrastructure/database/ProjectRepository.ts',
  'server/infrastructure/database/PublishingDestinationRepository.ts',
  'server/infrastructure/database/SourceRepository.ts',
  'server/infrastructure/database/UserRepository.ts',
  'server/infrastructure/database/JobRepository.ts'
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  // Match constructor() { ... } down to the closing brace before the first async method.
  content = content.replace(/constructor\(\) \{[\s\S]*?\}\n\n  async/, 'constructor() {\n    // Empty seed\n  }\n\n  async');
  fs.writeFileSync(file, content);
}
console.log('Done');
