const fs = require('fs');

const schemaAdditions = `

export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'restrict' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull(),
  description: text("description"),
  icon: text("icon"),
  color: varchar("color", { length: 20 }),
  visibility: varchar("visibility", { length: 50 }),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  defaultLanguage: varchar("default_language", { length: 30 }),
  defaultTimezone: varchar("default_timezone", { length: 100 }),
  settings: jsonb("settings").default({}),
  ...commonColumns
}, (t) => [
  index('workspace_org_idx').on(t.organizationId),
  index('workspace_owner_idx').on(t.ownerId),
  index('workspace_slug_idx').on(t.slug),
  index('workspace_status_idx').on(t.status),
  unique('workspace_org_slug_unq').on(t.organizationId, t.slug)
]);

export const workspaceMembers = pgTable("workspace_members", {
  workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'set null' }),
  joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow(),
  invitedBy: uuid("invited_by"),
  isOwner: boolean("is_owner").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
}, (t) => [
  index('wm_workspace_idx').on(t.workspaceId),
  index('wm_user_idx').on(t.userId),
  index('wm_role_idx').on(t.roleId),
  unique('wm_workspace_user_unq').on(t.workspaceId, t.userId)
]);

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'restrict' }).notNull(),
  workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: 'restrict' }).notNull(),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  thumbnail: text("thumbnail"),
  visibility: varchar("visibility", { length: 50 }),
  projectType: varchar("project_type", { length: 100 }),
  priority: integer("priority").default(0),
  progress: integer("progress").default(0),
  healthScore: integer("health_score").default(100),
  currentVersion: integer("current_version").default(1),
  defaultLanguage: varchar("default_language", { length: 30 }),
  storageUsed: bigint("storage_used", { mode: 'number' }).default(BigInt(0)),
  storageLimit: bigint("storage_limit", { mode: 'number' }),
  aiEnabled: boolean("ai_enabled").default(false),
  settings: jsonb("settings").default({}),
  ...commonColumns
}, (t) => [
  index('proj_org_idx').on(t.organizationId),
  index('proj_workspace_idx').on(t.workspaceId),
  index('proj_owner_idx').on(t.ownerId),
  index('proj_status_idx').on(t.status),
  index('proj_priority_idx').on(t.priority),
  index('proj_created_idx').on(t.createdAt),
  unique('proj_workspace_slug_unq').on(t.workspaceId, t.slug)
]);

export const projectMembers = pgTable("project_members", {
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'set null' }),
  permissions: jsonb("permissions").default([]),
  joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow(),
  invitedBy: uuid("invited_by"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
}, (t) => [
  index('pm_project_idx').on(t.projectId),
  index('pm_user_idx').on(t.userId),
  index('pm_role_idx').on(t.roleId),
  unique('pm_project_user_unq').on(t.projectId, t.userId)
]);

export const projectTags = pgTable("project_tags", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  color: varchar("color", { length: 20 }),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ptag_project_idx').on(t.projectId),
  index('ptag_name_idx').on(t.name)
]);

export const projectVersions = pgTable("project_versions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  versionNumber: integer("version_number").notNull(),
  changeSummary: text("change_summary"),
  createdBy: uuid("created_by"),
  commitHash: varchar("commit_hash", { length: 100 }),
  snapshot: jsonb("snapshot").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('pver_project_idx').on(t.projectId),
  index('pver_version_idx').on(t.versionNumber)
]);

export const projectSettings = pgTable("project_settings", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull().unique(),
  downloadSettings: jsonb("download_settings").default({}),
  publishSettings: jsonb("publish_settings").default({}),
  storageSettings: jsonb("storage_settings").default({}),
  notificationSettings: jsonb("notification_settings").default({}),
  automationSettings: jsonb("automation_settings").default({}),
  aiSettings: jsonb("ai_settings").default({}),
  securitySettings: jsonb("security_settings").default({}),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const folders = pgTable("folders", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  parentFolderId: uuid("parent_folder_id"),
  name: varchar("name", { length: 255 }).notNull(),
  path: text("path"),
  depth: integer("depth").default(0),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('folder_project_idx').on(t.projectId),
  index('folder_parent_idx').on(t.parentFolderId),
  index('folder_path_idx').on(t.path)
]);

export const files = pgTable("files", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  folderId: uuid("folder_id").references(() => folders.id, { onDelete: 'set null' }),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  filename: varchar("filename", { length: 255 }).notNull(),
  originalFilename: varchar("original_filename", { length: 255 }),
  extension: varchar("extension", { length: 20 }),
  mimeType: varchar("mime_type", { length: 100 }),
  sizeBytes: bigint("size_bytes", { mode: 'number' }),
  checksum: varchar("checksum", { length: 255 }),
  storageProvider: varchar("storage_provider", { length: 50 }),
  storageKey: text("storage_key"),
  publicUrl: text("public_url"),
  thumbnailUrl: text("thumbnail_url"),
  width: integer("width"),
  height: integer("height"),
  duration: integer("duration"),
  isProcessed: boolean("is_processed").default(false),
  processingStatus: varchar("processing_status", { length: 50 }),
  virusScanStatus: varchar("virus_scan_status", { length: 50 }),
  ...commonColumns
}, (t) => [
  index('file_org_idx').on(t.organizationId),
  index('file_project_idx').on(t.projectId),
  index('file_folder_idx').on(t.folderId),
  index('file_checksum_idx').on(t.checksum),
  index('file_mimetype_idx').on(t.mimeType),
  index('file_procstatus_idx').on(t.processingStatus)
]);

export const attachments = pgTable("attachments", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  entityType: varchar("entity_type", { length: 100 }).notNull(),
  entityId: uuid("entity_id").notNull(),
  attachedBy: uuid("attached_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('att_entity_type_idx').on(t.entityType),
  index('att_entity_id_idx').on(t.entityId),
  index('att_file_idx').on(t.fileId)
]);

`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

// Also fix tsconfig.json to add skipLibCheck
let tsconfig = JSON.parse(fs.readFileSync('tsconfig.json', 'utf8'));
tsconfig.compilerOptions.skipLibCheck = true;
fs.writeFileSync('tsconfig.json', JSON.stringify(tsconfig, null, 2));

console.log('Schema appended and tsconfig fixed.');
