const fs = require('fs');

const schemaAdditions = `

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  notificationType: varchar("notification_type", { length: 100 }),
  title: text("title"),
  message: text("message"),
  priority: varchar("priority", { length: 50 }),
  channel: varchar("channel", { length: 50 }),
  icon: text("icon"),
  actionUrl: text("action_url"),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('notif_org_idx').on(t.organizationId),
  index('notif_user_idx').on(t.userId),
  index('notif_proj_idx').on(t.projectId),
  index('notif_priority_idx').on(t.priority),
  index('notif_isread_idx').on(t.isRead),
  index('notif_created_idx').on(t.createdAt)
]);

export const notificationTemplates = pgTable("notification_templates", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  templateName: varchar("template_name", { length: 255 }).notNull(),
  channel: varchar("channel", { length: 50 }),
  subject: text("subject"),
  body: text("body"),
  variables: jsonb("variables").default({}),
  language: varchar("language", { length: 30 }),
  active: boolean("active").default(true),
  ...commonColumns
}, (t) => [
  index('ntmpl_org_idx').on(t.organizationId),
  index('ntmpl_name_idx').on(t.templateName)
]);

export const notificationDeliveries = pgTable("notification_deliveries", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  notificationId: uuid("notification_id").references(() => notifications.id, { onDelete: 'cascade' }).notNull(),
  provider: varchar("provider", { length: 100 }),
  destination: text("destination"),
  deliveryStatus: varchar("delivery_status", { length: 50 }),
  attemptCount: integer("attempt_count").default(0),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  failedAt: timestamp("failed_at", { withTimezone: true }),
  failureReason: text("failure_reason"),
  providerResponse: jsonb("provider_response").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ndel_notif_idx').on(t.notificationId),
  index('ndel_prov_idx').on(t.provider),
  index('ndel_status_idx').on(t.deliveryStatus)
]);

export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  activityType: varchar("activity_type", { length: 100 }),
  resourceType: varchar("resource_type", { length: 100 }),
  resourceId: uuid("resource_id"),
  description: text("description"),
  ipAddress: varchar("ip_address", { length: 45 }),
  device: varchar("device", { length: 255 }),
  browser: varchar("browser", { length: 255 }),
  country: varchar("country", { length: 255 }),
  city: varchar("city", { length: 255 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('actlog_org_idx').on(t.organizationId),
  index('actlog_user_idx').on(t.userId),
  index('actlog_proj_idx').on(t.projectId),
  index('actlog_type_idx').on(t.activityType),
  index('actlog_created_idx').on(t.createdAt)
]);

export const systemLogs = pgTable("system_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  serviceName: varchar("service_name", { length: 255 }),
  module: varchar("module", { length: 255 }),
  logLevel: varchar("log_level", { length: 50 }),
  requestId: varchar("request_id", { length: 255 }),
  correlationId: varchar("correlation_id", { length: 255 }),
  traceId: varchar("trace_id", { length: 255 }),
  message: text("message"),
  exception: text("exception"),
  stackTrace: text("stack_trace"),
  durationMs: integer("duration_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('syslog_level_idx').on(t.logLevel),
  index('syslog_svc_idx').on(t.serviceName),
  index('syslog_req_idx').on(t.requestId),
  index('syslog_created_idx').on(t.createdAt)
]);

export const metrics = pgTable("metrics", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  metricName: varchar("metric_name", { length: 255 }).notNull(),
  metricType: varchar("metric_type", { length: 100 }),
  metricValue: bigint("metric_value", { mode: 'number' }),
  unit: varchar("unit", { length: 50 }),
  source: varchar("source", { length: 255 }),
  tags: jsonb("tags").default({}),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('metric_org_idx').on(t.organizationId),
  index('metric_name_idx').on(t.metricName),
  index('metric_recorded_idx').on(t.recordedAt)
]);

export const dashboards = pgTable("dashboards", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  name: varchar("name", { length: 255 }).notNull(),
  layout: jsonb("layout").default({}),
  widgets: jsonb("widgets").default({}),
  visibility: varchar("visibility", { length: 50 }),
  defaultDashboard: boolean("default_dashboard").default(false),
  ...commonColumns
}, (t) => [
  index('dash_org_idx').on(t.organizationId),
  index('dash_owner_idx').on(t.ownerId)
]);

export const reports = pgTable("reports", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  generatedBy: uuid("generated_by").references(() => users.id, { onDelete: 'set null' }),
  reportType: varchar("report_type", { length: 100 }),
  reportFormat: varchar("report_format", { length: 50 }),
  storageFileId: uuid("storage_file_id").references(() => files.id, { onDelete: 'set null' }),
  generatedAt: timestamp("generated_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
}, (t) => [
  index('rep_org_idx').on(t.organizationId),
  index('rep_proj_idx').on(t.projectId),
  index('rep_type_idx').on(t.reportType)
]);

export const reportSchedules = pgTable("report_schedules", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  reportId: uuid("report_id").references(() => reports.id, { onDelete: 'cascade' }),
  cronExpression: varchar("cron_expression", { length: 100 }),
  timezone: varchar("timezone", { length: 100 }),
  lastRun: timestamp("last_run", { withTimezone: true }),
  nextRun: timestamp("next_run", { withTimezone: true }),
  enabled: boolean("enabled").default(true),
  deliveryChannels: jsonb("delivery_channels").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('rsched_org_idx').on(t.organizationId),
  index('rsched_next_idx').on(t.nextRun),
  index('rsched_enabled_idx').on(t.enabled)
]);

export const auditEvents = pgTable("audit_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  resourceType: varchar("resource_type", { length: 100 }),
  resourceId: uuid("resource_id"),
  eventName: varchar("event_name", { length: 255 }),
  severity: varchar("severity", { length: 50 }),
  beforeState: jsonb("before_state").default({}),
  afterState: jsonb("after_state").default({}),
  requestId: varchar("request_id", { length: 255 }),
  correlationId: varchar("correlation_id", { length: 255 }),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aevt_org_idx').on(t.organizationId),
  index('aevt_name_idx').on(t.eventName),
  index('aevt_severity_idx').on(t.severity),
  index('aevt_created_idx').on(t.createdAt)
]);
`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 6 appended.');
