const fs = require('fs');

const schemaAdditions = `

export const aiProviders = pgTable("ai_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  providerVersion: varchar("provider_version", { length: 50 }),
  apiEndpoint: text("api_endpoint"),
  authenticationType: varchar("authentication_type", { length: 50 }),
  defaultModel: varchar("default_model", { length: 255 }),
  supportsStreaming: boolean("supports_streaming").default(false),
  supportsFunctionCalling: boolean("supports_function_calling").default(false),
  supportsImages: boolean("supports_images").default(false),
  supportsVideo: boolean("supports_video").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsEmbeddings: boolean("supports_embeddings").default(false),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('aiprov_name_idx').on(t.providerName),
  index('aiprov_enabled_idx').on(t.enabled),
  index('aiprov_priority_idx').on(t.priority)
]);

export const aiModels = pgTable("ai_models", {
  id: uuid("id").primaryKey(),
  providerId: uuid("provider_id").references(() => aiProviders.id, { onDelete: 'cascade' }).notNull(),
  modelName: varchar("model_name", { length: 255 }).notNull(),
  modelVersion: varchar("model_version", { length: 100 }),
  contextWindow: integer("context_window"),
  maxOutputTokens: integer("max_output_tokens"),
  supportsReasoning: boolean("supports_reasoning").default(false),
  supportsTools: boolean("supports_tools").default(false),
  supportsImages: boolean("supports_images").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsVideo: boolean("supports_video").default(false),
  costInput: bigint("cost_input", { mode: 'number' }),
  costOutput: bigint("cost_output", { mode: 'number' }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aimod_provider_idx').on(t.providerId),
  index('aimod_name_idx').on(t.modelName)
]);

export const aiAgents = pgTable("ai_agents", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  agentType: varchar("agent_type", { length: 100 }),
  description: text("description"),
  defaultProviderId: uuid("default_provider_id").references(() => aiProviders.id, { onDelete: 'set null' }),
  defaultModelId: uuid("default_model_id").references(() => aiModels.id, { onDelete: 'set null' }),
  systemPrompt: text("system_prompt"),
  temperature: integer("temperature"),
  maxTokens: integer("max_tokens"),
  toolAccess: jsonb("tool_access").default({}),
  permissionProfile: varchar("permission_profile", { length: 100 }),
  approvalRequired: boolean("approval_required").default(false),
  memoryEnabled: boolean("memory_enabled").default(false),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('aiagent_org_idx').on(t.organizationId),
  index('aiagent_type_idx').on(t.agentType),
  index('aiagent_enabled_idx').on(t.enabled)
]);

export const aiConversations = pgTable("ai_conversations", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'set null' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  title: text("title"),
  summary: text("summary"),
  lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
  messageCount: integer("message_count").default(0),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aiconv_org_idx').on(t.organizationId),
  index('aiconv_user_idx').on(t.userId)
]);

export const aiRequests = pgTable("ai_requests", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'set null' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  agentId: uuid("agent_id").references(() => aiAgents.id, { onDelete: 'set null' }),
  providerId: uuid("provider_id").references(() => aiProviders.id, { onDelete: 'set null' }),
  modelId: uuid("model_id").references(() => aiModels.id, { onDelete: 'set null' }),
  conversationId: uuid("conversation_id").references(() => aiConversations.id, { onDelete: 'set null' }),
  promptVersion: integer("prompt_version"),
  inputTokens: integer("input_tokens"),
  outputTokens: integer("output_tokens"),
  executionTimeMs: integer("execution_time_ms"),
  cost: bigint("cost", { mode: 'number' }),
  requestPayload: jsonb("request_payload").default({}),
  responsePayload: jsonb("response_payload").default({}),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aireq_org_idx').on(t.organizationId),
  index('aireq_proj_idx').on(t.projectId),
  index('aireq_agent_idx').on(t.agentId),
  index('aireq_user_idx').on(t.userId),
  index('aireq_created_idx').on(t.createdAt)
]);

export const aiMemory = pgTable("ai_memory", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  conversationId: uuid("conversation_id").references(() => aiConversations.id, { onDelete: 'cascade' }).notNull(),
  memoryType: varchar("memory_type", { length: 50 }),
  importanceScore: integer("importance_score"),
  memoryContent: text("memory_content"),
  embeddingId: varchar("embedding_id", { length: 255 }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aimem_conv_idx').on(t.conversationId),
  index('aimem_type_idx').on(t.memoryType)
]);

export const promptTemplates = pgTable("prompt_templates", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  versionNumber: integer("version_number").notNull(),
  systemPrompt: text("system_prompt"),
  userPrompt: text("user_prompt"),
  variables: jsonb("variables").default({}),
  approvalRequired: boolean("approval_required").default(false),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('promptt_org_idx').on(t.organizationId),
  index('promptt_cat_idx').on(t.category),
  index('promptt_active_idx').on(t.active)
]);

export const knowledgeBase = pgTable("knowledge_base", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  contentType: varchar("content_type", { length: 100 }),
  source: varchar("source", { length: 255 }),
  storageFileId: uuid("storage_file_id").references(() => files.id, { onDelete: 'set null' }),
  embeddingStatus: varchar("embedding_status", { length: 50 }),
  vectorId: varchar("vector_id", { length: 255 }),
  language: varchar("language", { length: 30 }),
  checksum: varchar("checksum", { length: 255 }),
  ...commonColumns
}, (t) => [
  index('kb_org_idx').on(t.organizationId),
  index('kb_proj_idx').on(t.projectId),
  index('kb_ctype_idx').on(t.contentType)
]);

export const aiToolCalls = pgTable("ai_tool_calls", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  requestId: uuid("request_id").references(() => aiRequests.id, { onDelete: 'cascade' }).notNull(),
  toolName: varchar("tool_name", { length: 255 }).notNull(),
  toolVersion: varchar("tool_version", { length: 50 }),
  parameters: jsonb("parameters").default({}),
  executionResult: jsonb("execution_result").default({}),
  executionTimeMs: integer("execution_time_ms"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aitool_req_idx').on(t.requestId),
  index('aitool_name_idx').on(t.toolName)
]);

export const aiFeedback = pgTable("ai_feedback", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  requestId: uuid("request_id").references(() => aiRequests.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  rating: integer("rating"),
  feedbackText: text("feedback_text"),
  accepted: boolean("accepted").default(false),
  reviewed: boolean("reviewed").default(false),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aifb_req_idx').on(t.requestId),
  index('aifb_rating_idx').on(t.rating)
]);
`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 5 appended.');
