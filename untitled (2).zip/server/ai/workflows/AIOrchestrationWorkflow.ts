import { contentAnalysisAgent } from "../agents/ContentAnalysisAgent";
import { jobRepository } from "../../infrastructure/database/JobRepository";
import { JobStatus, JobType } from "../../domain/entities/Job";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class AIOrchestrationWorkflow {
  
  async runClipGenerationWorkflow(jobId: string, transcript: string): Promise<void> {
    try {
      logger.info(`Starting AI Workflow for Job: ${jobId}`);
      
      await jobRepository.update(jobId, { status: JobStatus.PROCESSING, progress: 25 });
      
      // Step 1: Analyze Content
      const analysisResult = await contentAnalysisAgent.analyzeTranscript(transcript);
      
      await jobRepository.update(jobId, { progress: 75 });
      
      // Try parsing JSON if possible
      let parsedClips;
      try {
        const cleanJson = analysisResult.replace(/\`\`\`json/g, "").replace(/\`\`\`/g, "").trim();
        parsedClips = JSON.parse(cleanJson);
      } catch (e) {
        parsedClips = { raw: analysisResult };
      }

      // Step 2: Finalize
      const job = await jobRepository.update(jobId, { 
        status: JobStatus.COMPLETED, 
        progress: 100,
        result: { clips: parsedClips }
      });

      if (job) {
         await eventBus.publish({
            eventType: "AIWorkflowCompleted",
            eventVersion: "1.0",
            sourceModule: "AIOrchestration",
            projectId: job.projectId,
            payload: { jobId, clips: parsedClips },
         });
      }

      logger.info(`AI Workflow Completed for Job: ${jobId}`);
    } catch (error: any) {
      logger.error(`AI Workflow Failed for Job: ${jobId}`, { error });
      await jobRepository.update(jobId, { 
        status: JobStatus.FAILED, 
        error: error.message 
      });
    }
  }
}

export const aiOrchestrationWorkflow = new AIOrchestrationWorkflow();
