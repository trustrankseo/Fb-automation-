import { geminiService } from "../GeminiService";
import { logger } from "../../config/logger";

export class ContentAnalysisAgent {
  async analyzeTranscript(transcript: string): Promise<string> {
    logger.info("ContentAnalysisAgent: Analyzing transcript...");

    const systemInstruction = `
You are an expert Content Analysis Agent.
Your job is to analyze video transcripts and extract the most engaging, viral moments that can be repurposed into short-form content (TikToks, Shorts, Reels).
For each moment, provide:
1. A catchy title.
2. The start and end timestamp (if available, otherwise approximate).
3. A brief explanation of why this moment is engaging.
Format your response as a structured JSON array.
`;

    const response = await geminiService.generateContent({
      systemInstruction,
      contents: [
        {
          role: "user",
          parts: [{ text: `Analyze the following transcript:\n\n${transcript}` }],
        },
      ],
      model: "gemini-2.5-pro",
      temperature: 0.2,
    });

    return response.text;
  }
}

export const contentAnalysisAgent = new ContentAnalysisAgent();
