export interface GenerateContentRequest {
  systemInstruction?: string;
  contents: { role: "user" | "model"; parts: { text: string }[] }[];
  model?: string;
  temperature?: number;
}

export interface GenerateContentResponse {
  text: string;
}

export class GeminiService {
  async generateContent(request: GenerateContentRequest): Promise<GenerateContentResponse> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing");
    }

    const modelName = request.model || "gemini-2.5-flash";

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        systemInstruction: request.systemInstruction ? {
          parts: [{ text: request.systemInstruction }]
        } : undefined,
        contents: request.contents,
        generationConfig: {
          temperature: request.temperature ?? 0.7,
        }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";

    return { text };
  }
}

export const geminiService = new GeminiService();
