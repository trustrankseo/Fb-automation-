import Redis from "ioredis";
import { logger } from "../../config/logger";

class CacheService {
  private redis: Redis | null = null;
  private isConnected: boolean = false;

  constructor() {
    const redisUrl = process.env.REDIS_URL;
    if (redisUrl) {
      this.redis = new Redis(redisUrl, {
        maxRetriesPerRequest: 3,
        showFriendlyErrorStack: true,
      });

      this.redis.on("connect", () => {
        this.isConnected = true;
        logger.info("Connected to Redis cache");
      });

      this.redis.on("error", (err) => {
        this.isConnected = false;
        logger.error("Redis connection error", err);
      });
    } else {
      logger.warn("REDIS_URL not set. Running without Redis cache. Falling back to in-memory mode if necessary.");
    }
  }

  async get<T>(key: string): Promise<T | null> {
    if (!this.isConnected || !this.redis) return null;
    try {
      const data = await this.redis.get(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      logger.error(`Cache get error for key ${key}`, error);
      return null;
    }
  }

  async set(key: string, value: any, ttlSeconds: number = 3600): Promise<void> {
    if (!this.isConnected || !this.redis) return;
    try {
      await this.redis.set(key, JSON.stringify(value), "EX", ttlSeconds);
    } catch (error) {
      logger.error(`Cache set error for key ${key}`, error);
    }
  }

  async invalidate(key: string): Promise<void> {
    if (!this.isConnected || !this.redis) return;
    try {
      await this.redis.del(key);
    } catch (error) {
      logger.error(`Cache invalidate error for key ${key}`, error);
    }
  }

  async acquireLock(key: string, ttlSeconds: number = 10): Promise<boolean> {
    if (!this.isConnected || !this.redis) return true; // Fail open if no redis
    try {
      const result = await this.redis.set(key, "LOCKED", "EX", ttlSeconds, "NX");
      return result === "OK";
    } catch (error) {
      logger.error(`Failed to acquire lock for ${key}`, error);
      return false;
    }
  }

  async releaseLock(key: string): Promise<void> {
    if (!this.isConnected || !this.redis) return;
    try {
      await this.redis.del(key);
    } catch (error) {
      logger.error(`Failed to release lock for ${key}`, error);
    }
  }
}

export const cacheService = new CacheService();
