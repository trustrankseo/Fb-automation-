import { v4 as uuidv4 } from "uuid";
import { logger } from "../../config/logger";

export interface SystemEvent<T = any> {
  eventId: string;
  eventType: string;
  eventVersion: string;
  sourceModule: string;
  timestamp: string;
  organizationId?: string;
  projectId?: string;
  userId?: string;
  correlationId?: string;
  payload: T;
  metadata?: Record<string, any>;
}

type EventCallback = (event: SystemEvent) => Promise<void> | void;

export interface IEventBus {
  publish(event: Omit<SystemEvent, "eventId" | "timestamp">): Promise<void>;
  subscribe(eventType: string, callback: EventCallback): void;
}

// In-Memory Event Bus Fallback (Production would use Redis Pub/Sub or Kafka)
export class InMemoryEventBus implements IEventBus {
  private subscribers: Map<string, EventCallback[]> = new Map();

  async publish(eventData: Omit<SystemEvent, "eventId" | "timestamp">): Promise<void> {
    const event: SystemEvent = {
      ...eventData,
      eventId: uuidv4(),
      timestamp: new Date().toISOString(),
    };

    logger.debug(`[EventBus] Publishing event: ${event.eventType}`, { eventId: event.eventId });

    const handlers = this.subscribers.get(event.eventType) || [];
    
    // Asynchronously process all subscribers to prevent blocking the publisher
    Promise.allSettled(
      handlers.map(async (handler) => {
        try {
          await handler(event);
        } catch (error) {
          logger.error(`[EventBus] Subscriber failed for event ${event.eventType}:`, error);
          // Dead Letter Queue handling would go here
        }
      })
    );
  }

  subscribe(eventType: string, callback: EventCallback): void {
    if (!this.subscribers.has(eventType)) {
      this.subscribers.set(eventType, []);
    }
    this.subscribers.get(eventType)!.push(callback);
    logger.info(`[EventBus] Registered subscriber for: ${eventType}`);
  }
}

export const eventBus = new InMemoryEventBus();
