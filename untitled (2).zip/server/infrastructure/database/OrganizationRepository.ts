import { IOrganizationRepository } from "../../domain/repositories/IOrganizationRepository";
import { Organization } from "../../domain/entities/Organization";
import { v4 as uuidv4 } from "uuid";

// This is an in-memory implementation for immediate development.
// A Postgres implementation would sit right next to this file.
export class InMemoryOrganizationRepository implements IOrganizationRepository {
  private organizations: Map<string, Organization> = new Map();

  constructor() {
    // Empty seed
  }

  async findAll(): Promise<Organization[]> {
    return Array.from(this.organizations.values());
  }

  async findById(id: string): Promise<Organization | null> {
    return this.organizations.get(id) || null;
  }

  async findBySlug(slug: string): Promise<Organization | null> {
    for (const org of this.organizations.values()) {
      if (org.slug === slug) return org;
    }
    return null;
  }

  async create(data: Omit<Organization, "id" | "createdAt" | "updatedAt">): Promise<Organization> {
    const id = `org_${uuidv4()}`;
    const now = new Date();
    const newOrg: Organization = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.organizations.set(id, newOrg);
    return newOrg;
  }

  async update(id: string, updates: Partial<Organization>): Promise<Organization | null> {
    const org = await this.findById(id);
    if (!org) return null;

    const updated = { ...org, ...updates, updatedAt: new Date() };
    this.organizations.set(id, updated);
    return updated;
  }

  async delete(id: string): Promise<boolean> {
    return this.organizations.delete(id);
  }
}

export const organizationRepository = new InMemoryOrganizationRepository();
