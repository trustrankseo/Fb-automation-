import { IProjectRepository } from "../../domain/repositories/IProjectRepository";
import { Project, ProjectStatus } from "../../domain/entities/Project";
import { v4 as uuidv4 } from "uuid";

export class InMemoryProjectRepository implements IProjectRepository {
  private projects: Map<string, Project> = new Map();

  constructor() {
    // Empty seed
  }

  async findById(id: string): Promise<Project | null> {
    return this.projects.get(id) || null;
  }

  async findByOrganizationId(organizationId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(p => p.organizationId === organizationId);
  }

  async create(data: Omit<Project, "id" | "createdAt" | "updatedAt">): Promise<Project> {
    const id = `proj_${uuidv4()}`;
    const now = new Date();
    const newProject: Project = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async update(id: string, updates: Partial<Project>): Promise<Project | null> {
    const proj = await this.findById(id);
    if (!proj) return null;
    const updated = { ...proj, ...updates, updatedAt: new Date() };
    this.projects.set(id, updated);
    return updated;
  }

  async delete(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }
}

export const projectRepository = new InMemoryProjectRepository();
