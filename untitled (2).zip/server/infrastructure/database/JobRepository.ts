import { IJobRepository } from "../../domain/repositories/IJobRepository";
import { Job, JobStatus, JobType } from "../../domain/entities/Job";
import { v4 as uuidv4 } from "uuid";

export class InMemoryJobRepository implements IJobRepository {
  private jobs: Map<string, Job> = new Map();

  constructor() {
    // Empty seed
  }

  async findById(id: string): Promise<Job | null> {
    return this.jobs.get(id) || null;
  }

  async findByProjectId(projectId: string): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter((j) => j.projectId === projectId);
  }

  async findPendingJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter((j) => j.status === JobStatus.PENDING);
  }

  async create(data: Omit<Job, "id" | "createdAt" | "updatedAt">): Promise<Job> {
    const id = `job_${uuidv4()}`;
    const now = new Date();
    const newJob: Job = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.jobs.set(id, newJob);
    return newJob;
  }

  async update(id: string, updates: Partial<Job>): Promise<Job | null> {
    const job = await this.findById(id);
    if (!job) return null;
    const updated = { ...job, ...updates, updatedAt: new Date() };
    this.jobs.set(id, updated);
    return updated;
  }
}

export const jobRepository = new InMemoryJobRepository();
