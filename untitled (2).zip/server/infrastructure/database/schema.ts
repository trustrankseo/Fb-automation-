import { 
  pgTable, 
  uuid, 
  varchar, 
  text, 
  boolean, 
  integer, 
  timestamp, 
  jsonb, 
  unique,
  bigint,
  char,
  primaryKey,
  index
} from "drizzle-orm/pg-core";

const commonColumns = {
  version: integer("version").default(1),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
  createdBy: uuid("created_by"),
  updatedBy: uuid("updated_by"),
};

export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  legalName: varchar("legal_name", { length: 255 }),
  email: varchar("email", { length: 255 }).unique(),
  phone: varchar("phone", { length: 40 }),
  website: varchar("website", { length: 255 }),
  countryCode: char("country_code", { length: 2 }),
  timezone: varchar("timezone", { length: 100 }),
  language: varchar("language", { length: 30 }),
  currency: varchar("currency", { length: 10 }),
  logoUrl: text("logo_url"),
  primaryColor: varchar("primary_color", { length: 20 }),
  subscriptionId: uuid("subscription_id"),
  licenseId: uuid("license_id"),
  storageLimit: bigint("storage_limit", { mode: 'number' }),
  storageUsed: bigint("storage_used", { mode: 'number' }),
  userLimit: integer("user_limit"),
  projectLimit: integer("project_limit"),
  aiEnabled: boolean("ai_enabled").default(false),
  branding: jsonb("branding").default({}),
  settings: jsonb("settings").default({}),
  ...commonColumns
}, (t) => [
  index('org_status_idx').on(t.status),
  index('org_country_idx').on(t.countryCode),
  index('org_created_idx').on(t.createdAt),
]);

export const users = pgTable("users", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'restrict' }),
  firstName: varchar("first_name", { length: 255 }),
  lastName: varchar("last_name", { length: 255 }),
  displayName: varchar("display_name", { length: 255 }),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 40 }),
  avatar: text("avatar"),
  passwordHash: text("password_hash"),
  passwordAlgorithm: varchar("password_algorithm", { length: 50 }),
  emailVerified: boolean("email_verified").default(false),
  phoneVerified: boolean("phone_verified").default(false),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  twoFactorSecret: text("two_factor_secret"),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  lastLoginIp: varchar("last_login_ip", { length: 45 }),
  failedLoginCount: integer("failed_login_count").default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  locale: varchar("locale", { length: 30 }),
  timezone: varchar("timezone", { length: 100 }),
  ...commonColumns
}, (t) => [
  index('user_org_idx').on(t.organizationId),
  index('user_status_idx').on(t.status),
  index('user_lastlogin_idx').on(t.lastLoginAt),
]);

export const roles = pgTable("roles", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull(),
  description: text("description"),
  isSystem: boolean("is_system").default(false),
  priority: integer("priority").default(0),
  ...commonColumns
}, (t) => [
  index('roles_org_idx').on(t.organizationId),
  index('roles_slug_idx').on(t.slug),
  unique('roles_org_slug_unq').on(t.organizationId, t.slug)
]);

export const permissions = pgTable("permissions", {
  id: uuid("id").primaryKey(),
  resource: varchar("resource", { length: 255 }).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  permissionKey: varchar("permission_key", { length: 255 }).notNull().unique(),
  description: text("description"),
  category: varchar("category", { length: 255 }),
  riskLevel: varchar("risk_level", { length: 50 }),
  isSystem: boolean("is_system").default(false),
  ...commonColumns
}, (t) => [
  index('perm_category_idx').on(t.category)
]);

export const rolePermissions = pgTable("role_permissions", {
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'cascade' }).notNull(),
  permissionId: uuid("permission_id").references(() => permissions.id, { onDelete: 'cascade' }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  primaryKey({ columns: [t.roleId, t.permissionId] })
]);

export const userRoles = pgTable("user_roles", {
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'cascade' }).notNull(),
  assignedBy: uuid("assigned_by"),
  assignedAt: timestamp("assigned_at", { withTimezone: true }).defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
}, (t) => [
  primaryKey({ columns: [t.userId, t.roleId] })
]);

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  refreshTokenHash: text("refresh_token_hash"),
  deviceName: varchar("device_name", { length: 255 }),
  browser: varchar("browser", { length: 255 }),
  operatingSystem: varchar("operating_system", { length: 255 }),
  ipAddress: varchar("ip_address", { length: 45 }),
  country: varchar("country", { length: 255 }),
  city: varchar("city", { length: 255 }),
  lastActivityAt: timestamp("last_activity_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  revoked: boolean("revoked").default(false),
  ...commonColumns
}, (t) => [
  index('sessions_user_idx').on(t.userId),
  index('sessions_org_idx').on(t.organizationId),
  index('sessions_expires_idx').on(t.expiresAt)
]);

export const apiKeys = pgTable("api_keys", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }),
  name: varchar("name", { length: 255 }),
  apiKeyHash: text("api_key_hash"),
  prefix: varchar("prefix", { length: 50 }).unique(),
  permissions: jsonb("permissions").default([]),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('apikeys_org_idx').on(t.organizationId),
  index('apikeys_user_idx').on(t.userId)
]);

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  requestId: uuid("request_id"),
  correlationId: uuid("correlation_id"),
  resource: varchar("resource", { length: 255 }),
  resourceId: uuid("resource_id"),
  action: varchar("action", { length: 255 }),
  before: jsonb("before"),
  after: jsonb("after"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  severity: varchar("severity", { length: 50 }),
  ...commonColumns
}, (t) => [
  index('audit_org_idx').on(t.organizationId),
  index('audit_resource_idx').on(t.resource),
  index('audit_action_idx').on(t.action),
  index('audit_created_idx').on(t.createdAt)
]);


export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'restrict' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull(),
  description: text("description"),
  icon: text("icon"),
  color: varchar("color", { length: 20 }),
  visibility: varchar("visibility", { length: 50 }),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  defaultLanguage: varchar("default_language", { length: 30 }),
  defaultTimezone: varchar("default_timezone", { length: 100 }),
  settings: jsonb("settings").default({}),
  ...commonColumns
}, (t) => [
  index('workspace_org_idx').on(t.organizationId),
  index('workspace_owner_idx').on(t.ownerId),
  index('workspace_slug_idx').on(t.slug),
  index('workspace_status_idx').on(t.status),
  unique('workspace_org_slug_unq').on(t.organizationId, t.slug)
]);

export const workspaceMembers = pgTable("workspace_members", {
  workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'set null' }),
  joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow(),
  invitedBy: uuid("invited_by"),
  isOwner: boolean("is_owner").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
}, (t) => [
  index('wm_workspace_idx').on(t.workspaceId),
  index('wm_user_idx').on(t.userId),
  index('wm_role_idx').on(t.roleId),
  unique('wm_workspace_user_unq').on(t.workspaceId, t.userId)
]);

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'restrict' }).notNull(),
  workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: 'restrict' }).notNull(),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  thumbnail: text("thumbnail"),
  visibility: varchar("visibility", { length: 50 }),
  projectType: varchar("project_type", { length: 100 }),
  priority: integer("priority").default(0),
  progress: integer("progress").default(0),
  healthScore: integer("health_score").default(100),
  currentVersion: integer("current_version").default(1),
  defaultLanguage: varchar("default_language", { length: 30 }),
  storageUsed: bigint("storage_used", { mode: 'number' }).default(0),
  storageLimit: bigint("storage_limit", { mode: 'number' }),
  aiEnabled: boolean("ai_enabled").default(false),
  settings: jsonb("settings").default({}),
  ...commonColumns
}, (t) => [
  index('proj_org_idx').on(t.organizationId),
  index('proj_workspace_idx').on(t.workspaceId),
  index('proj_owner_idx').on(t.ownerId),
  index('proj_status_idx').on(t.status),
  index('proj_priority_idx').on(t.priority),
  index('proj_created_idx').on(t.createdAt),
  unique('proj_workspace_slug_unq').on(t.workspaceId, t.slug)
]);

export const projectMembers = pgTable("project_members", {
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roleId: uuid("role_id").references(() => roles.id, { onDelete: 'set null' }),
  permissions: jsonb("permissions").default([]),
  joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow(),
  invitedBy: uuid("invited_by"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
}, (t) => [
  index('pm_project_idx').on(t.projectId),
  index('pm_user_idx').on(t.userId),
  index('pm_role_idx').on(t.roleId),
  unique('pm_project_user_unq').on(t.projectId, t.userId)
]);

export const projectTags = pgTable("project_tags", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  color: varchar("color", { length: 20 }),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ptag_project_idx').on(t.projectId),
  index('ptag_name_idx').on(t.name)
]);

export const projectVersions = pgTable("project_versions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  versionNumber: integer("version_number").notNull(),
  changeSummary: text("change_summary"),
  createdBy: uuid("created_by"),
  commitHash: varchar("commit_hash", { length: 100 }),
  snapshot: jsonb("snapshot").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('pver_project_idx').on(t.projectId),
  index('pver_version_idx').on(t.versionNumber)
]);

export const projectSettings = pgTable("project_settings", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull().unique(),
  downloadSettings: jsonb("download_settings").default({}),
  publishSettings: jsonb("publish_settings").default({}),
  storageSettings: jsonb("storage_settings").default({}),
  notificationSettings: jsonb("notification_settings").default({}),
  automationSettings: jsonb("automation_settings").default({}),
  aiSettings: jsonb("ai_settings").default({}),
  securitySettings: jsonb("security_settings").default({}),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const folders = pgTable("folders", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  parentFolderId: uuid("parent_folder_id"),
  name: varchar("name", { length: 255 }).notNull(),
  path: text("path"),
  depth: integer("depth").default(0),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('folder_project_idx').on(t.projectId),
  index('folder_parent_idx').on(t.parentFolderId),
  index('folder_path_idx').on(t.path)
]);

export const files = pgTable("files", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  folderId: uuid("folder_id").references(() => folders.id, { onDelete: 'set null' }),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  filename: varchar("filename", { length: 255 }).notNull(),
  originalFilename: varchar("original_filename", { length: 255 }),
  extension: varchar("extension", { length: 20 }),
  mimeType: varchar("mime_type", { length: 100 }),
  sizeBytes: bigint("size_bytes", { mode: 'number' }),
  checksum: varchar("checksum", { length: 255 }),
  storageProvider: varchar("storage_provider", { length: 50 }),
  storageKey: text("storage_key"),
  publicUrl: text("public_url"),
  thumbnailUrl: text("thumbnail_url"),
  width: integer("width"),
  height: integer("height"),
  duration: integer("duration"),
  isProcessed: boolean("is_processed").default(false),
  processingStatus: varchar("processing_status", { length: 50 }),
  virusScanStatus: varchar("virus_scan_status", { length: 50 }),
  ...commonColumns
}, (t) => [
  index('file_org_idx').on(t.organizationId),
  index('file_project_idx').on(t.projectId),
  index('file_folder_idx').on(t.folderId),
  index('file_checksum_idx').on(t.checksum),
  index('file_mimetype_idx').on(t.mimeType),
  index('file_procstatus_idx').on(t.processingStatus)
]);

export const attachments = pgTable("attachments", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  entityType: varchar("entity_type", { length: 100 }).notNull(),
  entityId: uuid("entity_id").notNull(),
  attachedBy: uuid("attached_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('att_entity_type_idx').on(t.entityType),
  index('att_entity_id_idx').on(t.entityId),
  index('att_file_idx').on(t.fileId)
]);



export const downloadSources = pgTable("download_sources", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  baseUrl: text("base_url"),
  authenticationType: varchar("authentication_type", { length: 50 }),
  rateLimit: integer("rate_limit"),
  supportsVideo: boolean("supports_video").default(false),
  supportsImage: boolean("supports_image").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsMetadata: boolean("supports_metadata").default(false),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('dsource_org_idx').on(t.organizationId),
  index('dsource_ptype_idx').on(t.providerType),
  index('dsource_status_idx').on(t.status)
]);

export const downloadJobs = pgTable("download_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  requestedBy: uuid("requested_by").references(() => users.id, { onDelete: 'set null' }),
  sourceId: uuid("source_id").references(() => downloadSources.id, { onDelete: 'set null' }),
  queueId: varchar("queue_id", { length: 255 }),
  workerId: varchar("worker_id", { length: 255 }),
  downloadUrl: text("download_url").notNull(),
  mediaType: varchar("media_type", { length: 50 }),
  quality: varchar("quality", { length: 50 }),
  priority: integer("priority").default(0),
  retryCount: integer("retry_count").default(0),
  maxRetries: integer("max_retries").default(3),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  failedAt: timestamp("failed_at", { withTimezone: true }),
  processingTimeMs: integer("processing_time_ms"),
  failureReason: text("failure_reason"),
  ...commonColumns
}, (t) => [
  index('djob_org_idx').on(t.organizationId),
  index('djob_project_idx').on(t.projectId),
  index('djob_worker_idx').on(t.workerId),
  index('djob_status_idx').on(t.status),
  index('djob_priority_idx').on(t.priority),
  index('djob_created_idx').on(t.createdAt)
]);

export const downloadedAssets = pgTable("downloaded_assets", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  downloadJobId: uuid("download_job_id").references(() => downloadJobs.id, { onDelete: 'set null' }),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'set null' }),
  providerAssetId: varchar("provider_asset_id", { length: 255 }),
  title: text("title"),
  description: text("description"),
  author: varchar("author", { length: 255 }),
  license: varchar("license", { length: 255 }),
  sourceUrl: text("source_url"),
  thumbnailUrl: text("thumbnail_url"),
  previewUrl: text("preview_url"),
  duration: integer("duration"),
  width: integer("width"),
  height: integer("height"),
  fps: integer("fps"),
  codec: varchar("codec", { length: 50 }),
  bitrate: integer("bitrate"),
  language: varchar("language", { length: 50 }),
  checksum: varchar("checksum", { length: 255 }),
  ...commonColumns
}, (t) => [
  index('dasset_org_idx').on(t.organizationId),
  index('dasset_project_idx').on(t.projectId),
  index('dasset_job_idx').on(t.downloadJobId),
  index('dasset_checksum_idx').on(t.checksum)
]);

export const mediaProcessingJobs = pgTable("media_processing_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  workerId: varchar("worker_id", { length: 255 }),
  operation: varchar("operation", { length: 100 }),
  inputFormat: varchar("input_format", { length: 50 }),
  outputFormat: varchar("output_format", { length: 50 }),
  resolution: varchar("resolution", { length: 50 }),
  processingEngine: varchar("processing_engine", { length: 100 }),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  durationMs: integer("duration_ms"),
  errorMessage: text("error_message"),
  ...commonColumns
}, (t) => [
  index('mpjob_org_idx').on(t.organizationId),
  index('mpjob_project_idx').on(t.projectId),
  index('mpjob_worker_idx').on(t.workerId),
  index('mpjob_operation_idx').on(t.operation),
  index('mpjob_status_idx').on(t.status)
]);

export const storageObjects = pgTable("storage_objects", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'set null' }),
  provider: varchar("provider", { length: 100 }),
  bucket: varchar("bucket", { length: 255 }),
  region: varchar("region", { length: 100 }),
  storageKey: text("storage_key").notNull(),
  objectUrl: text("object_url"),
  publicUrl: text("public_url"),
  encrypted: boolean("encrypted").default(false),
  compressed: boolean("compressed").default(false),
  replicationStatus: varchar("replication_status", { length: 50 }),
  checksum: varchar("checksum", { length: 255 }),
  storageClass: varchar("storage_class", { length: 100 }),
  sizeBytes: bigint("size_bytes", { mode: 'number' }),
  ...commonColumns
}, (t) => [
  index('sobj_provider_idx').on(t.provider),
  index('sobj_bucket_idx').on(t.bucket),
  unique('sobj_storage_key_unq').on(t.storageKey)
]);

export const thumbnails = pgTable("thumbnails", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  width: integer("width"),
  height: integer("height"),
  format: varchar("format", { length: 50 }),
  storageObjectId: uuid("storage_object_id").references(() => storageObjects.id, { onDelete: 'set null' }),
  generatedBy: varchar("generated_by", { length: 100 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('thumb_file_idx').on(t.fileId)
]);

export const mediaVersions = pgTable("media_versions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  versionNumber: integer("version_number").notNull(),
  parentVersion: integer("parent_version"),
  editor: varchar("editor", { length: 255 }),
  changeSummary: text("change_summary"),
  storageObjectId: uuid("storage_object_id").references(() => storageObjects.id, { onDelete: 'set null' }),
  checksum: varchar("checksum", { length: 255 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('mver_file_idx').on(t.fileId),
  index('mver_version_idx').on(t.versionNumber)
]);

export const storageProviders = pgTable("storage_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  endpoint: text("endpoint"),
  region: varchar("region", { length: 100 }),
  defaultBucket: varchar("default_bucket", { length: 255 }),
  encryptionEnabled: boolean("encryption_enabled").default(false),
  compressionEnabled: boolean("compression_enabled").default(false),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('sprov_name_idx').on(t.providerName),
  index('sprov_org_idx').on(t.organizationId)
]);



export const aiProviders = pgTable("ai_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  providerVersion: varchar("provider_version", { length: 50 }),
  apiEndpoint: text("api_endpoint"),
  authenticationType: varchar("authentication_type", { length: 50 }),
  defaultModel: varchar("default_model", { length: 255 }),
  supportsStreaming: boolean("supports_streaming").default(false),
  supportsFunctionCalling: boolean("supports_function_calling").default(false),
  supportsImages: boolean("supports_images").default(false),
  supportsVideo: boolean("supports_video").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsEmbeddings: boolean("supports_embeddings").default(false),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('aiprov_name_idx').on(t.providerName),
  index('aiprov_enabled_idx').on(t.enabled),
  index('aiprov_priority_idx').on(t.priority)
]);

export const aiModels = pgTable("ai_models", {
  id: uuid("id").primaryKey(),
  providerId: uuid("provider_id").references(() => aiProviders.id, { onDelete: 'cascade' }).notNull(),
  modelName: varchar("model_name", { length: 255 }).notNull(),
  modelVersion: varchar("model_version", { length: 100 }),
  contextWindow: integer("context_window"),
  maxOutputTokens: integer("max_output_tokens"),
  supportsReasoning: boolean("supports_reasoning").default(false),
  supportsTools: boolean("supports_tools").default(false),
  supportsImages: boolean("supports_images").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsVideo: boolean("supports_video").default(false),
  costInput: bigint("cost_input", { mode: 'number' }),
  costOutput: bigint("cost_output", { mode: 'number' }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aimod_provider_idx').on(t.providerId),
  index('aimod_name_idx').on(t.modelName)
]);

export const aiAgents = pgTable("ai_agents", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  agentType: varchar("agent_type", { length: 100 }),
  description: text("description"),
  defaultProviderId: uuid("default_provider_id").references(() => aiProviders.id, { onDelete: 'set null' }),
  defaultModelId: uuid("default_model_id").references(() => aiModels.id, { onDelete: 'set null' }),
  systemPrompt: text("system_prompt"),
  temperature: integer("temperature"),
  maxTokens: integer("max_tokens"),
  toolAccess: jsonb("tool_access").default({}),
  permissionProfile: varchar("permission_profile", { length: 100 }),
  approvalRequired: boolean("approval_required").default(false),
  memoryEnabled: boolean("memory_enabled").default(false),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('aiagent_org_idx').on(t.organizationId),
  index('aiagent_type_idx').on(t.agentType),
  index('aiagent_enabled_idx').on(t.enabled)
]);

export const aiConversations = pgTable("ai_conversations", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'set null' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  title: text("title"),
  summary: text("summary"),
  lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
  messageCount: integer("message_count").default(0),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aiconv_org_idx').on(t.organizationId),
  index('aiconv_user_idx').on(t.userId)
]);

export const aiRequests = pgTable("ai_requests", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'set null' }),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  agentId: uuid("agent_id").references(() => aiAgents.id, { onDelete: 'set null' }),
  providerId: uuid("provider_id").references(() => aiProviders.id, { onDelete: 'set null' }),
  modelId: uuid("model_id").references(() => aiModels.id, { onDelete: 'set null' }),
  conversationId: uuid("conversation_id").references(() => aiConversations.id, { onDelete: 'set null' }),
  promptVersion: integer("prompt_version"),
  inputTokens: integer("input_tokens"),
  outputTokens: integer("output_tokens"),
  executionTimeMs: integer("execution_time_ms"),
  cost: bigint("cost", { mode: 'number' }),
  requestPayload: jsonb("request_payload").default({}),
  responsePayload: jsonb("response_payload").default({}),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aireq_org_idx').on(t.organizationId),
  index('aireq_proj_idx').on(t.projectId),
  index('aireq_agent_idx').on(t.agentId),
  index('aireq_user_idx').on(t.userId),
  index('aireq_created_idx').on(t.createdAt)
]);

export const aiMemory = pgTable("ai_memory", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  conversationId: uuid("conversation_id").references(() => aiConversations.id, { onDelete: 'cascade' }).notNull(),
  memoryType: varchar("memory_type", { length: 50 }),
  importanceScore: integer("importance_score"),
  memoryContent: text("memory_content"),
  embeddingId: varchar("embedding_id", { length: 255 }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aimem_conv_idx').on(t.conversationId),
  index('aimem_type_idx').on(t.memoryType)
]);

export const promptTemplates = pgTable("prompt_templates", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  versionNumber: integer("version_number").notNull(),
  systemPrompt: text("system_prompt"),
  userPrompt: text("user_prompt"),
  variables: jsonb("variables").default({}),
  approvalRequired: boolean("approval_required").default(false),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('promptt_org_idx').on(t.organizationId),
  index('promptt_cat_idx').on(t.category),
  index('promptt_active_idx').on(t.active)
]);

export const knowledgeBase = pgTable("knowledge_base", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  contentType: varchar("content_type", { length: 100 }),
  source: varchar("source", { length: 255 }),
  storageFileId: uuid("storage_file_id").references(() => files.id, { onDelete: 'set null' }),
  embeddingStatus: varchar("embedding_status", { length: 50 }),
  vectorId: varchar("vector_id", { length: 255 }),
  language: varchar("language", { length: 30 }),
  checksum: varchar("checksum", { length: 255 }),
  ...commonColumns
}, (t) => [
  index('kb_org_idx').on(t.organizationId),
  index('kb_proj_idx').on(t.projectId),
  index('kb_ctype_idx').on(t.contentType)
]);

export const aiToolCalls = pgTable("ai_tool_calls", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  requestId: uuid("request_id").references(() => aiRequests.id, { onDelete: 'cascade' }).notNull(),
  toolName: varchar("tool_name", { length: 255 }).notNull(),
  toolVersion: varchar("tool_version", { length: 50 }),
  parameters: jsonb("parameters").default({}),
  executionResult: jsonb("execution_result").default({}),
  executionTimeMs: integer("execution_time_ms"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aitool_req_idx').on(t.requestId),
  index('aitool_name_idx').on(t.toolName)
]);

export const aiFeedback = pgTable("ai_feedback", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  requestId: uuid("request_id").references(() => aiRequests.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  rating: integer("rating"),
  feedbackText: text("feedback_text"),
  accepted: boolean("accepted").default(false),
  reviewed: boolean("reviewed").default(false),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aifb_req_idx').on(t.requestId),
  index('aifb_rating_idx').on(t.rating)
]);


export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  notificationType: varchar("notification_type", { length: 100 }),
  title: text("title"),
  message: text("message"),
  priority: varchar("priority", { length: 50 }),
  channel: varchar("channel", { length: 50 }),
  icon: text("icon"),
  actionUrl: text("action_url"),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('notif_org_idx').on(t.organizationId),
  index('notif_user_idx').on(t.userId),
  index('notif_proj_idx').on(t.projectId),
  index('notif_priority_idx').on(t.priority),
  index('notif_isread_idx').on(t.isRead),
  index('notif_created_idx').on(t.createdAt)
]);

export const notificationTemplates = pgTable("notification_templates", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  templateName: varchar("template_name", { length: 255 }).notNull(),
  channel: varchar("channel", { length: 50 }),
  subject: text("subject"),
  body: text("body"),
  variables: jsonb("variables").default({}),
  language: varchar("language", { length: 30 }),
  active: boolean("active").default(true),
  ...commonColumns
}, (t) => [
  index('ntmpl_org_idx').on(t.organizationId),
  index('ntmpl_name_idx').on(t.templateName)
]);

export const notificationDeliveries = pgTable("notification_deliveries", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  notificationId: uuid("notification_id").references(() => notifications.id, { onDelete: 'cascade' }).notNull(),
  provider: varchar("provider", { length: 100 }),
  destination: text("destination"),
  deliveryStatus: varchar("delivery_status", { length: 50 }),
  attemptCount: integer("attempt_count").default(0),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  failedAt: timestamp("failed_at", { withTimezone: true }),
  failureReason: text("failure_reason"),
  providerResponse: jsonb("provider_response").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ndel_notif_idx').on(t.notificationId),
  index('ndel_prov_idx').on(t.provider),
  index('ndel_status_idx').on(t.deliveryStatus)
]);

export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  activityType: varchar("activity_type", { length: 100 }),
  resourceType: varchar("resource_type", { length: 100 }),
  resourceId: uuid("resource_id"),
  description: text("description"),
  ipAddress: varchar("ip_address", { length: 45 }),
  device: varchar("device", { length: 255 }),
  browser: varchar("browser", { length: 255 }),
  country: varchar("country", { length: 255 }),
  city: varchar("city", { length: 255 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('actlog_org_idx').on(t.organizationId),
  index('actlog_user_idx').on(t.userId),
  index('actlog_proj_idx').on(t.projectId),
  index('actlog_type_idx').on(t.activityType),
  index('actlog_created_idx').on(t.createdAt)
]);

export const systemLogs = pgTable("system_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  serviceName: varchar("service_name", { length: 255 }),
  module: varchar("module", { length: 255 }),
  logLevel: varchar("log_level", { length: 50 }),
  requestId: varchar("request_id", { length: 255 }),
  correlationId: varchar("correlation_id", { length: 255 }),
  traceId: varchar("trace_id", { length: 255 }),
  message: text("message"),
  exception: text("exception"),
  stackTrace: text("stack_trace"),
  durationMs: integer("duration_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('syslog_level_idx').on(t.logLevel),
  index('syslog_svc_idx').on(t.serviceName),
  index('syslog_req_idx').on(t.requestId),
  index('syslog_created_idx').on(t.createdAt)
]);

export const metrics = pgTable("metrics", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }),
  metricName: varchar("metric_name", { length: 255 }).notNull(),
  metricType: varchar("metric_type", { length: 100 }),
  metricValue: bigint("metric_value", { mode: 'number' }),
  unit: varchar("unit", { length: 50 }),
  source: varchar("source", { length: 255 }),
  tags: jsonb("tags").default({}),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('metric_org_idx').on(t.organizationId),
  index('metric_name_idx').on(t.metricName),
  index('metric_recorded_idx').on(t.recordedAt)
]);

export const dashboards = pgTable("dashboards", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: 'set null' }),
  name: varchar("name", { length: 255 }).notNull(),
  layout: jsonb("layout").default({}),
  widgets: jsonb("widgets").default({}),
  visibility: varchar("visibility", { length: 50 }),
  defaultDashboard: boolean("default_dashboard").default(false),
  ...commonColumns
}, (t) => [
  index('dash_org_idx').on(t.organizationId),
  index('dash_owner_idx').on(t.ownerId)
]);

export const reports = pgTable("reports", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }),
  generatedBy: uuid("generated_by").references(() => users.id, { onDelete: 'set null' }),
  reportType: varchar("report_type", { length: 100 }),
  reportFormat: varchar("report_format", { length: 50 }),
  storageFileId: uuid("storage_file_id").references(() => files.id, { onDelete: 'set null' }),
  generatedAt: timestamp("generated_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  metadata: jsonb("metadata").default({}),
}, (t) => [
  index('rep_org_idx').on(t.organizationId),
  index('rep_proj_idx').on(t.projectId),
  index('rep_type_idx').on(t.reportType)
]);

export const reportSchedules = pgTable("report_schedules", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  reportId: uuid("report_id").references(() => reports.id, { onDelete: 'cascade' }),
  cronExpression: varchar("cron_expression", { length: 100 }),
  timezone: varchar("timezone", { length: 100 }),
  lastRun: timestamp("last_run", { withTimezone: true }),
  nextRun: timestamp("next_run", { withTimezone: true }),
  enabled: boolean("enabled").default(true),
  deliveryChannels: jsonb("delivery_channels").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('rsched_org_idx').on(t.organizationId),
  index('rsched_next_idx').on(t.nextRun),
  index('rsched_enabled_idx').on(t.enabled)
]);

export const auditEvents = pgTable("audit_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'set null' }),
  resourceType: varchar("resource_type", { length: 100 }),
  resourceId: uuid("resource_id"),
  eventName: varchar("event_name", { length: 255 }),
  severity: varchar("severity", { length: 50 }),
  beforeState: jsonb("before_state").default({}),
  afterState: jsonb("after_state").default({}),
  requestId: varchar("request_id", { length: 255 }),
  correlationId: varchar("correlation_id", { length: 255 }),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('aevt_org_idx').on(t.organizationId),
  index('aevt_name_idx').on(t.eventName),
  index('aevt_severity_idx').on(t.severity),
  index('aevt_created_idx').on(t.createdAt)
]);


export const subscriptionPlans = pgTable("subscription_plans", {
  id: uuid("id").primaryKey(),
  planName: varchar("plan_name", { length: 255 }).notNull(),
  planCode: varchar("plan_code", { length: 100 }).notNull().unique(),
  description: text("description"),
  billingCycle: varchar("billing_cycle", { length: 50 }),
  price: bigint("price", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  trialDays: integer("trial_days"),
  storageLimit: bigint("storage_limit", { mode: 'number' }),
  projectLimit: integer("project_limit"),
  userLimit: integer("user_limit"),
  apiLimit: bigint("api_limit", { mode: 'number' }),
  aiTokenLimit: bigint("ai_token_limit", { mode: 'number' }),
  workerLimit: integer("worker_limit"),
  supportLevel: varchar("support_level", { length: 100 }),
  isPublic: boolean("is_public").default(false),
  features: jsonb("features").default({}),
  ...commonColumns
}, (t) => [
  index('subplan_code_idx').on(t.planCode),
  index('subplan_status_idx').on(t.status)
]);

export const subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull().unique(),
  planId: uuid("plan_id").references(() => subscriptionPlans.id, { onDelete: 'restrict' }),
  subscriptionNumber: varchar("subscription_number", { length: 255 }),
  billingProvider: varchar("billing_provider", { length: 100 }),
  providerSubscriptionId: varchar("provider_subscription_id", { length: 255 }),
  startDate: timestamp("start_date", { withTimezone: true }),
  renewalDate: timestamp("renewal_date", { withTimezone: true }),
  expirationDate: timestamp("expiration_date", { withTimezone: true }),
  trialEnd: timestamp("trial_end", { withTimezone: true }),
  cancelAt: timestamp("cancel_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  autoRenew: boolean("auto_renew").default(true),
  currentPeriodStart: timestamp("current_period_start", { withTimezone: true }),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('sub_org_idx').on(t.organizationId),
  index('sub_plan_idx').on(t.planId),
  index('sub_status_idx').on(t.status)
]);

export const invoices = pgTable("invoices", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  subscriptionId: uuid("subscription_id").references(() => subscriptions.id, { onDelete: 'cascade' }),
  invoiceNumber: varchar("invoice_number", { length: 255 }).notNull().unique(),
  billingPeriodStart: timestamp("billing_period_start", { withTimezone: true }),
  billingPeriodEnd: timestamp("billing_period_end", { withTimezone: true }),
  subtotal: bigint("subtotal", { mode: 'number' }),
  tax: bigint("tax", { mode: 'number' }),
  discount: bigint("discount", { mode: 'number' }),
  grandTotal: bigint("grand_total", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  paymentStatus: varchar("payment_status", { length: 50 }),
  dueDate: timestamp("due_date", { withTimezone: true }),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  pdfFileId: uuid("pdf_file_id").references(() => files.id, { onDelete: 'set null' }),
  ...commonColumns
}, (t) => [
  index('inv_org_idx').on(t.organizationId),
  index('inv_num_idx').on(t.invoiceNumber),
  index('inv_status_idx').on(t.paymentStatus)
]);

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  invoiceId: uuid("invoice_id").references(() => invoices.id, { onDelete: 'set null' }),
  provider: varchar("provider", { length: 100 }),
  providerTransactionId: varchar("provider_transaction_id", { length: 255 }).unique(),
  paymentMethod: varchar("payment_method", { length: 100 }),
  amount: bigint("amount", { mode: 'number' }),
  currency: varchar("currency", { length: 10 }),
  paymentStatus: varchar("payment_status", { length: 50 }),
  failureReason: text("failure_reason"),
  processedAt: timestamp("processed_at", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('pay_inv_idx').on(t.invoiceId),
  index('pay_tx_idx').on(t.providerTransactionId)
]);

export const licenses = pgTable("licenses", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  licenseKey: varchar("license_key", { length: 255 }).notNull().unique(),
  licenseType: varchar("license_type", { length: 100 }),
  issuedAt: timestamp("issued_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  activatedAt: timestamp("activated_at", { withTimezone: true }),
  deviceLimit: integer("device_limit"),
  seatLimit: integer("seat_limit"),
  licenseStatus: varchar("license_status", { length: 50 }),
  ...commonColumns
}, (t) => [
  index('lic_org_idx').on(t.organizationId),
  index('lic_key_idx').on(t.licenseKey)
]);

export const featureFlags = pgTable("feature_flags", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  featureKey: varchar("feature_key", { length: 100 }).notNull(),
  featureName: varchar("feature_name", { length: 255 }),
  enabled: boolean("enabled").default(false),
  rolloutPercentage: integer("rollout_percentage"),
  minimumPlan: varchar("minimum_plan", { length: 100 }),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('ff_org_idx').on(t.organizationId),
  unique('ff_org_key_unq').on(t.organizationId, t.featureKey)
]);

export const usageTracking = pgTable("usage_tracking", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  metricName: varchar("metric_name", { length: 100 }).notNull(),
  currentUsage: bigint("current_usage", { mode: 'number' }).default(0),
  maximumAllowed: bigint("maximum_allowed", { mode: 'number' }),
  warningThreshold: bigint("warning_threshold", { mode: 'number' }),
  resetPeriod: varchar("reset_period", { length: 50 }),
  lastReset: timestamp("last_reset", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('ut_org_idx').on(t.organizationId),
  index('ut_metric_idx').on(t.metricName)
]);

export const quotaEvents = pgTable("quota_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  usageTrackingId: uuid("usage_tracking_id").references(() => usageTracking.id, { onDelete: 'cascade' }).notNull(),
  eventType: varchar("event_type", { length: 100 }),
  oldValue: bigint("old_value", { mode: 'number' }),
  newValue: bigint("new_value", { mode: 'number' }),
  triggeredBy: varchar("triggered_by", { length: 255 }),
  notes: text("notes"),
  ...commonColumns
}, (t) => [
  index('qe_usage_idx').on(t.usageTrackingId),
  index('qe_created_idx').on(t.createdAt)
]);

export const billingEvents = pgTable("billing_events", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  subscriptionId: uuid("subscription_id").references(() => subscriptions.id, { onDelete: 'cascade' }),
  eventName: varchar("event_name", { length: 255 }),
  provider: varchar("provider", { length: 100 }),
  providerReference: varchar("provider_reference", { length: 255 }),
  payload: jsonb("payload").default({}),
  ...commonColumns
}, (t) => [
  index('bev_org_idx').on(t.organizationId),
  index('bev_sub_idx').on(t.subscriptionId),
  index('bev_event_idx').on(t.eventName)
]);


export const plugins = pgTable("plugins", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  pluginName: varchar("plugin_name", { length: 255 }).notNull(),
  pluginSlug: varchar("plugin_slug", { length: 255 }).notNull().unique(),
  pluginVersion: varchar("plugin_version", { length: 50 }),
  pluginAuthor: varchar("plugin_author", { length: 255 }),
  pluginType: varchar("plugin_type", { length: 100 }),
  pluginCategory: varchar("plugin_category", { length: 100 }),
  minimumPlatformVersion: varchar("minimum_platform_version", { length: 50 }),
  maximumPlatformVersion: varchar("maximum_platform_version", { length: 50 }),
  installationPath: text("installation_path"),
  configuration: jsonb("configuration").default({}),
  permissions: jsonb("permissions").default({}),
  enabled: boolean("enabled").default(false),
  verified: boolean("verified").default(false),
  ...commonColumns
}, (t) => [
  index('plug_org_idx').on(t.organizationId),
  index('plug_slug_idx').on(t.pluginSlug),
  index('plug_status_idx').on(t.status)
]);

export const pluginVersions = pgTable("plugin_versions", {
  id: uuid("id").primaryKey(),
  pluginId: uuid("plugin_id").references(() => plugins.id, { onDelete: 'cascade' }).notNull(),
  version: varchar("version", { length: 50 }),
  releaseNotes: text("release_notes"),
  checksum: varchar("checksum", { length: 255 }),
  downloadUrl: text("download_url"),
  installedAt: timestamp("installed_at", { withTimezone: true }),
  installedBy: uuid("installed_by").references(() => users.id, { onDelete: 'set null' }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('pver_plug_idx').on(t.pluginId),
  index('plugver_version_idx').on(t.version)
]);

export const pluginHooks = pgTable("plugin_hooks", {
  id: uuid("id").primaryKey(),
  pluginId: uuid("plugin_id").references(() => plugins.id, { onDelete: 'cascade' }).notNull(),
  hookName: varchar("hook_name", { length: 255 }),
  eventName: varchar("event_name", { length: 255 }),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('phook_plug_idx').on(t.pluginId),
  index('phook_name_idx').on(t.hookName)
]);

export const webhooks = pgTable("webhooks", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  targetUrl: text("target_url"),
  httpMethod: varchar("http_method", { length: 20 }),
  secret: varchar("secret", { length: 255 }),
  enabled: boolean("enabled").default(true),
  retryPolicy: varchar("retry_policy", { length: 100 }),
  timeoutSeconds: integer("timeout_seconds"),
  headers: jsonb("headers").default({}),
  events: jsonb("events").default({}),
  lastDelivery: timestamp("last_delivery", { withTimezone: true }),
  ...commonColumns
}, (t) => [
  index('wh_org_idx').on(t.organizationId),
  index('wh_enabled_idx').on(t.enabled)
]);

export const webhookDeliveries = pgTable("webhook_deliveries", {
  id: uuid("id").primaryKey(),
  webhookId: uuid("webhook_id").references(() => webhooks.id, { onDelete: 'cascade' }).notNull(),
  eventName: varchar("event_name", { length: 255 }),
  requestBody: jsonb("request_body").default({}),
  responseCode: integer("response_code"),
  responseBody: text("response_body"),
  attemptCount: integer("attempt_count").default(0),
  deliveryTimeMs: integer("delivery_time_ms"),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('whd_wh_idx').on(t.webhookId),
  index('whd_event_idx').on(t.eventName),
  index('whd_status_idx').on(t.status)
]);

export const apiClients = pgTable("api_clients", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  clientId: varchar("client_id", { length: 255 }).notNull().unique(),
  clientSecretHash: text("client_secret_hash"),
  redirectUri: text("redirect_uri"),
  allowedScopes: jsonb("allowed_scopes").default({}),
  allowedOrigins: jsonb("allowed_origins").default({}),
  rateLimit: integer("rate_limit"),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('apic_id_idx').on(t.clientId),
  index('apic_org_idx').on(t.organizationId)
]);

export const apiTokens = pgTable("api_tokens", {
  id: uuid("id").primaryKey(),
  clientId: varchar("client_id", { length: 255 }).notNull(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text("token_hash"),
  refreshTokenHash: text("refresh_token_hash"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  revoked: boolean("revoked").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('apit_client_idx').on(t.clientId),
  index('apit_user_idx').on(t.userId),
  index('apit_expires_idx').on(t.expiresAt)
]);

export const integrationProviders = pgTable("integration_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  authenticationMethod: varchar("authentication_method", { length: 50 }),
  baseUrl: text("base_url"),
  apiVersion: varchar("api_version", { length: 50 }),
  enabled: boolean("enabled").default(true),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('iprov_name_idx').on(t.providerName),
  index('iprov_org_idx').on(t.organizationId)
]);

export const integrationConnections = pgTable("integration_connections", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerId: uuid("provider_id").references(() => integrationProviders.id, { onDelete: 'cascade' }).notNull(),
  connectionName: varchar("connection_name", { length: 255 }),
  externalAccountId: varchar("external_account_id", { length: 255 }),
  encryptedCredentials: text("encrypted_credentials"),
  lastSync: timestamp("last_sync", { withTimezone: true }),
  syncStatus: varchar("sync_status", { length: 50 }),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('iconn_org_idx').on(t.organizationId),
  index('iconn_prov_idx').on(t.providerId)
]);

export const integrationLogs = pgTable("integration_logs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerId: uuid("provider_id").references(() => integrationProviders.id, { onDelete: 'cascade' }),
  connectionId: uuid("connection_id").references(() => integrationConnections.id, { onDelete: 'cascade' }),
  operation: varchar("operation", { length: 255 }),
  requestId: varchar("request_id", { length: 255 }),
  responseStatus: varchar("response_status", { length: 50 }),
  executionTimeMs: integer("execution_time_ms"),
  errorMessage: text("error_message"),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => [
  index('ilog_prov_idx').on(t.providerId),
  index('ilog_conn_idx').on(t.connectionId),
  index('ilog_op_idx').on(t.operation),
  index('ilog_created_idx').on(t.createdAt)
]);


export const securityPolicies = pgTable("security_policies", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  policyName: varchar("policy_name", { length: 255 }).notNull(),
  policyCode: varchar("policy_code", { length: 100 }).notNull().unique(),
  policyCategory: varchar("policy_category", { length: 100 }),
  description: text("description"),
  policyDefinition: jsonb("policy_definition").default({}),
  enforcementMode: varchar("enforcement_mode", { length: 50 }),
  priority: integer("priority").default(0),
  enabled: boolean("enabled").default(true),
  ...commonColumns
}, (t) => [
  index('spol_org_idx').on(t.organizationId),
  index('spol_code_idx').on(t.policyCode)
]);

export const complianceFrameworks = pgTable("compliance_frameworks", {
  id: uuid("id").primaryKey(),
  frameworkName: varchar("framework_name", { length: 255 }).notNull(),
  frameworkCode: varchar("framework_code", { length: 100 }).notNull().unique(),
  frameworkVersion: varchar("framework_version", { length: 50 }),
  description: text("description"),
  requirements: jsonb("requirements").default({}),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('cfwk_code_idx').on(t.frameworkCode)
]);

export const organizationCompliance = pgTable("organization_compliance", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  frameworkId: uuid("framework_id").references(() => complianceFrameworks.id, { onDelete: 'cascade' }).notNull(),
  complianceStatus: varchar("compliance_status", { length: 50 }),
  lastAudit: timestamp("last_audit", { withTimezone: true }),
  nextAudit: timestamp("next_audit", { withTimezone: true }),
  score: integer("score"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ocomp_org_idx').on(t.organizationId),
  index('ocomp_fwk_idx').on(t.frameworkId)
]);

export const encryptionKeys = pgTable("encryption_keys", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  keyName: varchar("key_name", { length: 255 }).notNull(),
  keyType: varchar("key_type", { length: 100 }),
  keyProvider: varchar("key_provider", { length: 100 }),
  keyVersion: varchar("key_version", { length: 50 }),
  rotationIntervalDays: integer("rotation_interval_days"),
  lastRotatedAt: timestamp("last_rotated_at", { withTimezone: true }),
  nextRotationAt: timestamp("next_rotation_at", { withTimezone: true }),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ekey_org_idx').on(t.organizationId),
  index('ekey_name_idx').on(t.keyName)
]);

export const backupJobs = pgTable("backup_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupType: varchar("backup_type", { length: 50 }),
  storageProvider: varchar("storage_provider", { length: 100 }),
  backupLocation: text("backup_location"),
  backupSize: integer("backup_size"),
  compressionEnabled: boolean("compression_enabled").default(false),
  encryptionEnabled: boolean("encryption_enabled").default(false),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  verificationStatus: varchar("verification_status", { length: 50 }),
  status: varchar("status", { length: 30 }).default('PENDING'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('bjob_org_idx').on(t.organizationId),
  index('bjob_type_idx').on(t.backupType),
  index('bjob_status_idx').on(t.status)
]);

export const backupArchives = pgTable("backup_archives", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupJobId: uuid("backup_job_id").references(() => backupJobs.id, { onDelete: 'cascade' }).notNull(),
  archiveName: varchar("archive_name", { length: 255 }).notNull(),
  archiveChecksum: varchar("archive_checksum", { length: 255 }),
  storageObjectId: varchar("storage_object_id", { length: 255 }),
  retentionUntil: timestamp("retention_until", { withTimezone: true }),
  verified: boolean("verified").default(false),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('barch_org_idx').on(t.organizationId),
  index('barch_job_idx').on(t.backupJobId)
]);

export const restoreJobs = pgTable("restore_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  backupArchiveId: uuid("backup_archive_id").references(() => backupArchives.id, { onDelete: 'cascade' }).notNull(),
  restoreType: varchar("restore_type", { length: 50 }),
  requestedBy: uuid("requested_by").references(() => users.id, { onDelete: 'set null' }),
  approvedBy: uuid("approved_by").references(() => users.id, { onDelete: 'set null' }),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  restoreStatus: varchar("restore_status", { length: 50 }),
  validationReport: jsonb("validation_report").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('rjob_org_idx').on(t.organizationId),
  index('rjob_status_idx').on(t.restoreStatus)
]);

export const ipAllowlists = pgTable("ip_allowlists", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  cidrBlock: varchar("cidr_block", { length: 50 }).notNull(),
  description: text("description"),
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('ipa_org_idx').on(t.organizationId),
  index('ipa_cidr_idx').on(t.cidrBlock)
]);

export const securityIncidents = pgTable("security_incidents", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  incidentType: varchar("incident_type", { length: 100 }),
  severity: varchar("severity", { length: 50 }),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  detectedAt: timestamp("detected_at", { withTimezone: true }),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  assignedTo: uuid("assigned_to").references(() => users.id, { onDelete: 'set null' }),
  resolutionNotes: text("resolution_notes"),
  status: varchar("status", { length: 30 }).default('OPEN'),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('sinc_org_idx').on(t.organizationId),
  index('sinc_sev_idx').on(t.severity),
  index('sinc_status_idx').on(t.status)
]);

export const dataRetentionPolicies = pgTable("data_retention_policies", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  resourceType: varchar("resource_type", { length: 100 }),
  retentionDays: integer("retention_days"),
  archiveAfterDays: integer("archive_after_days"),
  deleteAfterDays: integer("delete_after_days"),
  legalHold: boolean("legal_hold").default(false),
  status: varchar("status", { length: 30 }).default('ACTIVE'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('drp_org_idx').on(t.organizationId),
  index('drp_res_idx').on(t.resourceType)
]);
