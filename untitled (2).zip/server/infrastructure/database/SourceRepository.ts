import { ISourceRepository } from "../../domain/repositories/ISourceRepository";
import { Source, SourceType, SourceStatus } from "../../domain/entities/Source";
import { v4 as uuidv4 } from "uuid";

export class InMemorySourceRepository implements ISourceRepository {
  private sources: Map<string, Source> = new Map();

  constructor() {
    // Empty seed
  }

  async findById(id: string): Promise<Source | null> {
    return this.sources.get(id) || null;
  }

  async findByProjectId(projectId: string): Promise<Source[]> {
    return Array.from(this.sources.values()).filter(s => s.projectId === projectId);
  }

  async create(data: Omit<Source, "id" | "createdAt" | "updatedAt">): Promise<Source> {
    const id = `src_${uuidv4()}`;
    const now = new Date();
    const newSource: Source = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.sources.set(id, newSource);
    return newSource;
  }

  async update(id: string, updates: Partial<Source>): Promise<Source | null> {
    const src = await this.findById(id);
    if (!src) return null;
    const updated = { ...src, ...updates, updatedAt: new Date() };
    this.sources.set(id, updated);
    return updated;
  }

  async delete(id: string): Promise<boolean> {
    return this.sources.delete(id);
  }
}

export const sourceRepository = new InMemorySourceRepository();
