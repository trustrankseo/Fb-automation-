import { Pool } from "pg";
import { logger } from "../../config/logger";
import { InfrastructureException } from "../../types/errors";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgres://postgres:postgres@localhost:5432/emcas",
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on("error", (err) => {
  logger.error("Unexpected error on idle PostgreSQL client", err);
});

export const db = {
  query: async (text: string, params?: any[]) => {
    const start = Date.now();
    try {
      const res = await pool.query(text, params);
      const duration = Date.now() - start;
      logger.debug("Executed query", { text, duration, rows: res.rowCount });
      return res;
    } catch (error: any) {
      logger.error("Database query failed", { text, error: error.message });
      throw new InfrastructureException("Database operation failed", [error.message]);
    }
  },
  getClient: async () => {
    const client = await pool.connect();
    const query = client.query;
    const release = client.release;
    
    // Monkey patch the query method to log execution
    client.query = (...args: any[]) => {
      logger.debug("Executed transaction query", { args });
      return query.apply(client, args as any);
    };

    client.release = () => {
      client.query = query;
      client.release = release;
      return release.apply(client);
    };

    return client;
  }
};
