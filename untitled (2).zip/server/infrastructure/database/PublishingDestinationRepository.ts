import { IPublishingDestinationRepository } from "../../domain/repositories/IPublishingDestinationRepository";
import { PublishingDestination, DestinationType, DestinationStatus } from "../../domain/entities/PublishingDestination";
import { v4 as uuidv4 } from "uuid";

export class InMemoryPublishingRepository implements IPublishingDestinationRepository {
  private destinations: Map<string, PublishingDestination> = new Map();

  constructor() {
    // Empty seed
  }

  async findById(id: string): Promise<PublishingDestination | null> {
    return this.destinations.get(id) || null;
  }

  async findByProjectId(projectId: string): Promise<PublishingDestination[]> {
    return Array.from(this.destinations.values()).filter(d => d.projectId === projectId);
  }

  async create(data: Omit<PublishingDestination, "id" | "createdAt" | "updatedAt">): Promise<PublishingDestination> {
    const id = `dest_${uuidv4()}`;
    const now = new Date();
    const newDest: PublishingDestination = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.destinations.set(id, newDest);
    return newDest;
  }

  async update(id: string, updates: Partial<PublishingDestination>): Promise<PublishingDestination | null> {
    const dest = await this.findById(id);
    if (!dest) return null;
    const updated = { ...dest, ...updates, updatedAt: new Date() };
    this.destinations.set(id, updated);
    return updated;
  }

  async delete(id: string): Promise<boolean> {
    return this.destinations.delete(id);
  }
}

export const publishingRepository = new InMemoryPublishingRepository();
