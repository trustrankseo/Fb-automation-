export interface AIProviderResponse {
  status: "success" | "error";
  provider: string;
  latencyMs: number;
  requestId: string;
  data: any;
  metadata?: any;
  error?: any;
}

export interface IAIProvider {
  name: string;
  generateText(prompt: string, context?: any): Promise<AIProviderResponse>;
  generateJSON(prompt: string, schema?: any): Promise<AIProviderResponse>;
}
