import { GoogleGenAI } from "@google/genai";
import { IAIProvider, AIProviderResponse } from "./IAIProvider";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../../../config/logger";
import { InfrastructureException } from "../../../types/errors";

export class GeminiProvider implements IAIProvider {
  public readonly name = "GoogleGemini";
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      logger.warn("GEMINI_API_KEY is missing. GeminiProvider will fail if invoked.");
    }
    this.ai = new GoogleGenAI({ apiKey: apiKey || "MISSING_KEY" });
  }

  async generateText(prompt: string, context?: any): Promise<AIProviderResponse> {
    const requestId = uuidv4();
    const start = Date.now();
    
    try {
      // System instructions could be passed if supported
      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const latencyMs = Date.now() - start;
      logger.info(`[${this.name}] Text generation successful`, { requestId, latencyMs });

      return {
        status: "success",
        provider: this.name,
        latencyMs,
        requestId,
        data: response.text,
      };
    } catch (error: any) {
      const latencyMs = Date.now() - start;
      logger.error(`[${this.name}] Text generation failed: ${error.message}`, { requestId, latencyMs });
      
      throw new InfrastructureException(`AI Provider Failure: ${error.message}`, [error]);
    }
  }

  async generateJSON(prompt: string, schema?: any): Promise<AIProviderResponse> {
     const requestId = uuidv4();
     const start = Date.now();
     
     try {
       const response = await this.ai.models.generateContent({
         model: "gemini-2.5-flash",
         contents: prompt,
         config: {
           responseMimeType: "application/json",
         }
       });
 
       const latencyMs = Date.now() - start;
       return {
         status: "success",
         provider: this.name,
         latencyMs,
         requestId,
         data: JSON.parse(response.text || "{}"),
       };
     } catch (error: any) {
       const latencyMs = Date.now() - start;
       logger.error(`[${this.name}] JSON generation failed: ${error.message}`, { requestId, latencyMs });
       throw new InfrastructureException(`AI Provider Failure: ${error.message}`, [error]);
     }
  }
}
