import { Organization } from "../entities/Organization";

export interface IOrganizationRepository {
  findAll(): Promise<Organization[]>;
  findById(id: string): Promise<Organization | null>;
  findBySlug(slug: string): Promise<Organization | null>;
  create(organization: Omit<Organization, "id" | "createdAt" | "updatedAt">): Promise<Organization>;
  update(id: string, updates: Partial<Organization>): Promise<Organization | null>;
  delete(id: string): Promise<boolean>;
}
