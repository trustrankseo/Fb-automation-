import { Project } from "../entities/Project";

export interface IProjectRepository {
  findById(id: string): Promise<Project | null>;
  findByOrganizationId(organizationId: string): Promise<Project[]>;
  create(project: Omit<Project, "id" | "createdAt" | "updatedAt">): Promise<Project>;
  update(id: string, updates: Partial<Project>): Promise<Project | null>;
  delete(id: string): Promise<boolean>;
}
