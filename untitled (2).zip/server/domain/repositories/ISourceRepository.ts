import { Source } from "../entities/Source";

export interface ISourceRepository {
  findById(id: string): Promise<Source | null>;
  findByProjectId(projectId: string): Promise<Source[]>;
  create(source: Omit<Source, "id" | "createdAt" | "updatedAt">): Promise<Source>;
  update(id: string, updates: Partial<Source>): Promise<Source | null>;
  delete(id: string): Promise<boolean>;
}
