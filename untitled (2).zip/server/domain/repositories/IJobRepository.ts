import { Job } from "../entities/Job";

export interface IJobRepository {
  findById(id: string): Promise<Job | null>;
  findByProjectId(projectId: string): Promise<Job[]>;
  findPendingJobs(): Promise<Job[]>;
  create(job: Omit<Job, "id" | "createdAt" | "updatedAt">): Promise<Job>;
  update(id: string, updates: Partial<Job>): Promise<Job | null>;
}
