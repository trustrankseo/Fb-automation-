import { PublishingDestination } from "../entities/PublishingDestination";

export interface IPublishingDestinationRepository {
  findById(id: string): Promise<PublishingDestination | null>;
  findByProjectId(projectId: string): Promise<PublishingDestination[]>;
  create(dest: Omit<PublishingDestination, "id" | "createdAt" | "updatedAt">): Promise<PublishingDestination>;
  update(id: string, updates: Partial<PublishingDestination>): Promise<PublishingDestination | null>;
  delete(id: string): Promise<boolean>;
}
