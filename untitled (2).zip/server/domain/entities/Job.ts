export enum JobStatus {
  PENDING = "PENDING",
  PROCESSING = "PROCESSING",
  COMPLETED = "COMPLETED",
  FAILED = "FAILED",
}

export enum JobType {
  DOWNLOAD_MEDIA = "DOWNLOAD_MEDIA",
  PROCESS_AUDIO = "PROCESS_AUDIO",
  GENERATE_CLIPS = "GENERATE_CLIPS",
  PUBLISH_CONTENT = "PUBLISH_CONTENT",
}

export interface Job {
  id: string;
  projectId: string;
  type: JobType;
  status: JobStatus;
  payload: Record<string, any>;
  result?: Record<string, any>;
  error?: string;
  progress: number;
  createdAt: Date;
  updatedAt: Date;
}
