export enum DestinationType {
  YOUTUBE = "YOUTUBE",
  TIKTOK = "TIKTOK",
  INSTAGRAM = "INSTAGRAM",
  S3_BUCKET = "S3_BUCKET",
}

export enum DestinationStatus {
  ACTIVE = "ACTIVE",
  DISCONNECTED = "DISCONNECTED",
  ERROR = "ERROR",
}

export interface PublishingDestination {
  id: string;
  projectId: string;
  name: string;
  type: DestinationType;
  status: DestinationStatus;
  credentialsId?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}
