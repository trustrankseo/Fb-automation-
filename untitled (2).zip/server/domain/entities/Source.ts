export enum SourceType {
  YOUTUBE = "YOUTUBE",
  TWITCH = "TWITCH",
  TIKTOK = "TIKTOK",
  LOCAL_UPLOAD = "LOCAL_UPLOAD",
  GOOGLE_DRIVE = "GOOGLE_DRIVE",
}

export enum SourceStatus {
  ACTIVE = "ACTIVE",
  DISCONNECTED = "DISCONNECTED",
  ERROR = "ERROR",
}

export interface Source {
  id: string;
  projectId: string;
  name: string;
  type: SourceType;
  status: SourceStatus;
  credentialsId?: string; // Reference to secure credential store
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}
