import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class BillingController {
  static async getEvents(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getEvents successful");
    } catch (error) {
      next(error);
    }
  }

  static async getHistory(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getHistory successful");
    } catch (error) {
      next(error);
    }
  }

  static async getProviders(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getProviders successful");
    } catch (error) {
      next(error);
    }
  }

  static async testProvider(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "testProvider successful");
    } catch (error) {
      next(error);
    }
  }

}
