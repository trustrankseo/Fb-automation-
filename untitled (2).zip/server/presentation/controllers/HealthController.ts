import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class HealthController {
  static async getHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getHealth successful");
    } catch (error) {
      next(error);
    }
  }

  static async getDatabaseHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getDatabaseHealth successful");
    } catch (error) {
      next(error);
    }
  }

  static async getStorageHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStorageHealth successful");
    } catch (error) {
      next(error);
    }
  }

  static async getQueueHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getQueueHealth successful");
    } catch (error) {
      next(error);
    }
  }

  static async getWorkersHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getWorkersHealth successful");
    } catch (error) {
      next(error);
    }
  }

  static async getIntegrationsHealth(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getIntegrationsHealth successful");
    } catch (error) {
      next(error);
    }
  }

}
