import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class StorageController {
  static async getProviders(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getProviders successful");
    } catch (error) {
      next(error);
    }
  }

  static async createProvider(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "createProvider successful");
    } catch (error) {
      next(error);
    }
  }

  static async updateProvider(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "updateProvider successful");
    } catch (error) {
      next(error);
    }
  }

  static async deleteProvider(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "deleteProvider successful");
    } catch (error) {
      next(error);
    }
  }

  static async getStatistics(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStatistics successful");
    } catch (error) {
      next(error);
    }
  }

  static async getUsage(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getUsage successful");
    } catch (error) {
      next(error);
    }
  }

}
