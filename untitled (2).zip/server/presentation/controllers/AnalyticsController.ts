import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class AnalyticsController {
  static async getOverview(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getOverview successful");
    } catch (error) {
      next(error);
    }
  }

  static async getProjects(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getProjects successful");
    } catch (error) {
      next(error);
    }
  }

  static async getStorage(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStorage successful");
    } catch (error) {
      next(error);
    }
  }

  static async getDownloads(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getDownloads successful");
    } catch (error) {
      next(error);
    }
  }

  static async getUsers(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getUsers successful");
    } catch (error) {
      next(error);
    }
  }

  static async getAi(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAi successful");
    } catch (error) {
      next(error);
    }
  }

  static async getWorkers(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getWorkers successful");
    } catch (error) {
      next(error);
    }
  }

  static async getQueues(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getQueues successful");
    } catch (error) {
      next(error);
    }
  }

}
