import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class ContainerController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getById successful");
    } catch (error) {
      next(error);
    }
  }

  static async restart(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "restart successful");
    } catch (error) {
      next(error);
    }
  }

  static async scale(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "scale successful");
    } catch (error) {
      next(error);
    }
  }

}
