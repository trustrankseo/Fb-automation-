import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class DisasterRecoveryController {
  static async getStatus(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStatus successful");
    } catch (error) {
      next(error);
    }
  }

  static async test(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "test successful");
    } catch (error) {
      next(error);
    }
  }

  static async failover(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "failover successful");
    } catch (error) {
      next(error);
    }
  }

  static async failback(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "failback successful");
    } catch (error) {
      next(error);
    }
  }

}
