import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class InfrastructureController {
  static async getInfrastructure(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getInfrastructure successful");
    } catch (error) {
      next(error);
    }
  }

  static async getServices(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getServices successful");
    } catch (error) {
      next(error);
    }
  }

  static async getNodes(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getNodes successful");
    } catch (error) {
      next(error);
    }
  }

  static async getStorage(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStorage successful");
    } catch (error) {
      next(error);
    }
  }

  static async getNetwork(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getNetwork successful");
    } catch (error) {
      next(error);
    }
  }

  static async refresh(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "refresh successful");
    } catch (error) {
      next(error);
    }
  }

}
