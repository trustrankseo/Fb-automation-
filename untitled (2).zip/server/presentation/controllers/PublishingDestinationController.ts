import { Request, Response, NextFunction } from "express";
import { PublishingDestinationService } from "../../application/services/PublishingDestinationService";
import { publishingRepository } from "../../infrastructure/database/PublishingDestinationRepository";
import { sendSuccess } from "../utils/apiResponse.js";

const publishingService = new PublishingDestinationService(publishingRepository);

export class PublishingDestinationController {
  
  static async listByProject(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      const destinations = await publishingService.getDestinationsByProject(projectId);
      
      return sendSuccess(res, destinations, "Destinations retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const destination = await publishingService.getDestinationById(id);
      
      return sendSuccess(res, destination, "Destination retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId, name, type } = req.body;
      const destination = await publishingService.createDestination(projectId, name, type);
      
      return sendSuccess(res, destination, "Destination created successfully", undefined, 201);
    } catch (error) {
      next(error);
    }
  }
}
