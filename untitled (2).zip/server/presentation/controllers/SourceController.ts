import { Request, Response, NextFunction } from "express";
import { SourceService } from "../../application/services/SourceService";
import { sourceRepository } from "../../infrastructure/database/SourceRepository";
import { sendSuccess } from "../utils/apiResponse.js";

const sourceService = new SourceService(sourceRepository);

export class SourceController {
  
  static async listByProject(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      
      const sources = await sourceService.getSourcesByProject(projectId);
      
      return sendSuccess(res, sources, "Sources retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      const source = await sourceService.getSourceById(id);
      
      return sendSuccess(res, source, "Source retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId, name, type } = req.body;

      const source = await sourceService.createSource(projectId, name, type);
      
      return sendSuccess(res, source, "Source created successfully", undefined, 201);
    } catch (error) {
      next(error);
    }
  }
}
