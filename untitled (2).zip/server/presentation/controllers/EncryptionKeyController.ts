import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class EncryptionKeyController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "create successful");
    } catch (error) {
      next(error);
    }
  }

  static async rotate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "rotate successful");
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "delete successful");
    } catch (error) {
      next(error);
    }
  }

}
