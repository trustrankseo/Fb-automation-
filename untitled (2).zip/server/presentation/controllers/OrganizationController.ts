import { Request, Response, NextFunction } from "express";
import { OrganizationService } from "../../application/services/OrganizationService";
import { organizationRepository } from "../../infrastructure/database/OrganizationRepository";
import { sendSuccess } from "../utils/apiResponse.js";

// DI injection point
const organizationService = new OrganizationService(organizationRepository);

export class OrganizationController {
  
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const orgs = await organizationService.getAllOrganizations();
      return sendSuccess(res, orgs, "Organizations retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const organization = await organizationService.getOrganizationById(id);
      
      return sendSuccess(res, organization, "Organization retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const { name, slug } = req.body;
      const organization = await organizationService.createOrganization(name, slug);
      
      return sendSuccess(res, organization, "Organization created successfully", undefined, 201);
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "Organization updated successfully");
    } catch (error) { next(error); }
  }

  static async partialUpdate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "Organization partially updated successfully");
    } catch (error) { next(error); }
  }

  static async delete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "Organization deleted successfully");
    } catch (error) { next(error); }
  }

  static async updateBranding(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "Organization branding updated successfully");
    } catch (error) { next(error); }
  }

  static async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "Organization settings updated successfully");
    } catch (error) { next(error); }
  }

}
