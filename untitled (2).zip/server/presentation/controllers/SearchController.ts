import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class SearchController {
  static async search(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "search successful");
    } catch (error) {
      next(error);
    }
  }

  static async searchFiles(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "searchFiles successful");
    } catch (error) {
      next(error);
    }
  }

  static async searchProjects(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "searchProjects successful");
    } catch (error) {
      next(error);
    }
  }

  static async searchWorkspaces(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "searchWorkspaces successful");
    } catch (error) {
      next(error);
    }
  }

}
