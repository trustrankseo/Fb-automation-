import { Request, Response, NextFunction } from "express";
import { JobService } from "../../application/services/JobService";
import { jobRepository } from "../../infrastructure/database/JobRepository";
import { sendSuccess } from "../utils/apiResponse.js";
import { aiOrchestrationWorkflow } from "../../ai/workflows/AIOrchestrationWorkflow";
import { JobType } from "../../domain/entities/Job";

const jobService = new JobService(jobRepository);

export class JobController {
  
  static async listByProject(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      const jobs = await jobService.getJobsByProject(projectId);
      
      return sendSuccess(res, jobs, "Jobs retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const job = await jobService.getJobById(id);
      
      return sendSuccess(res, job, "Job retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const { projectId, type, payload } = req.body;
      const job = await jobService.createJob(projectId, type, payload);
      
      // If it's a GENERATE_CLIPS job, kick off the background worker
      if (type === JobType.GENERATE_CLIPS) {
        const transcript = payload?.transcript || "This is a demo transcript about AI and technology. AI is moving so fast right now. You can build incredible things in hours instead of months. It's truly a paradigm shift in software engineering.";
        // Run in background
        setTimeout(() => {
          aiOrchestrationWorkflow.runClipGenerationWorkflow(job.id, transcript).catch(console.error);
        }, 1000);
      }
      
      return sendSuccess(res, job, "Job created successfully", undefined, 201);
    } catch (error) {
      next(error);
    }
  }
}

