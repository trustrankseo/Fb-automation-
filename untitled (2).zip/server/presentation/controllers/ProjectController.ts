import { Request, Response, NextFunction } from "express";
import { ProjectService } from "../../application/services/ProjectService";
import { projectRepository } from "../../infrastructure/database/ProjectRepository";
import { sendSuccess } from "../utils/apiResponse.js";

const projectService = new ProjectService(projectRepository);

export class ProjectController {
  
  static async list(req: Request, res: Response, next: NextFunction) {
    try {
      // In a real app, this comes from the auth middleware
      const organizationId = req.headers["x-organization-id"] as string || "org_default_123";
      
      const projects = await projectService.getProjectsByOrg(organizationId);
      
      return sendSuccess(res, projects, "Projects retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const organizationId = req.headers["x-organization-id"] as string || "org_default_123";

      const project = await projectService.getProjectById(id, organizationId);
      
      return sendSuccess(res, project, "Project retrieved successfully");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const { name, description } = req.body;
      const organizationId = req.headers["x-organization-id"] as string || "org_default_123";

      const project = await projectService.createProject(organizationId, name, description);
      
      return sendSuccess(res, project, "Project created successfully", undefined, 201);
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "update successful"); } catch (error) { next(error); } }
  static async partialUpdate(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "partialUpdate successful"); } catch (error) { next(error); } }
  static async delete(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "delete successful"); } catch (error) { next(error); } }
  static async getMembers(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "getMembers successful"); } catch (error) { next(error); } }
  static async addMember(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "addMember successful"); } catch (error) { next(error); } }
  static async removeMember(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "removeMember successful"); } catch (error) { next(error); } }
  static async getVersions(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "getVersions successful"); } catch (error) { next(error); } }
  static async duplicate(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "duplicate successful"); } catch (error) { next(error); } }
  static async archive(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "archive successful"); } catch (error) { next(error); } }
  static async restore(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "restore successful"); } catch (error) { next(error); } }
  static async bulkArchive(req: Request, res: Response, next: NextFunction) { try { return sendSuccess(res, {}, "bulkArchive successful"); } catch (error) { next(error); } }

}
