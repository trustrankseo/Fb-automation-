import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class ObservabilityController {
  static async getMetrics(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getMetrics successful");
    } catch (error) {
      next(error);
    }
  }

  static async getActivityLogs(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getActivityLogs successful");
    } catch (error) {
      next(error);
    }
  }

  static async getAuditEvents(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAuditEvents successful");
    } catch (error) {
      next(error);
    }
  }

  static async getSystemLogs(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getSystemLogs successful");
    } catch (error) {
      next(error);
    }
  }

}
