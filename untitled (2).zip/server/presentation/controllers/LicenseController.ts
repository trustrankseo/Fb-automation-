import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class LicenseController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getById successful");
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "create successful");
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "update successful");
    } catch (error) {
      next(error);
    }
  }

  static async activate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "activate successful");
    } catch (error) {
      next(error);
    }
  }

  static async deactivate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "deactivate successful");
    } catch (error) {
      next(error);
    }
  }

  static async rotate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "rotate successful");
    } catch (error) {
      next(error);
    }
  }

}
