import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class UsageController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async getStatistics(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getStatistics successful");
    } catch (error) {
      next(error);
    }
  }

  static async getLimits(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getLimits successful");
    } catch (error) {
      next(error);
    }
  }

  static async reset(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "reset successful");
    } catch (error) {
      next(error);
    }
  }

}
