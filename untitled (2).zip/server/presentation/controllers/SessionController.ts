import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class SessionController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "delete successful");
    } catch (error) {
      next(error);
    }
  }

  static async deleteAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "deleteAll successful");
    } catch (error) {
      next(error);
    }
  }

}
