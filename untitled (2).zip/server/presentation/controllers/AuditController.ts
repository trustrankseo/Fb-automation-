import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class AuditController {
  static async getEvents(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getEvents successful");
    } catch (error) {
      next(error);
    }
  }

  static async getEventById(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getEventById successful");
    } catch (error) {
      next(error);
    }
  }

  static async export(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "export successful");
    } catch (error) {
      next(error);
    }
  }

  static async search(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "search successful");
    } catch (error) {
      next(error);
    }
  }

}
