import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class PluginController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getById successful");
    } catch (error) {
      next(error);
    }
  }

  static async install(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "install successful");
    } catch (error) {
      next(error);
    }
  }

  static async enable(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "enable successful");
    } catch (error) {
      next(error);
    }
  }

  static async disable(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "disable successful");
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "update successful");
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "delete successful");
    } catch (error) {
      next(error);
    }
  }

  static async getPermissions(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getPermissions successful");
    } catch (error) {
      next(error);
    }
  }

}
