import { Request, Response, NextFunction } from "express";
import { sendSuccess } from "../utils/apiResponse.js";

export class FileController {
  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getAll successful");
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "getById successful");
    } catch (error) {
      next(error);
    }
  }

  static async upload(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "upload successful");
    } catch (error) {
      next(error);
    }
  }

  static async uploadBulk(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "uploadBulk successful");
    } catch (error) {
      next(error);
    }
  }

  static async partialUpdate(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "partialUpdate successful");
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "delete successful");
    } catch (error) {
      next(error);
    }
  }

  static async copy(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "copy successful");
    } catch (error) {
      next(error);
    }
  }

  static async move(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "move successful");
    } catch (error) {
      next(error);
    }
  }

  static async rename(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "rename successful");
    } catch (error) {
      next(error);
    }
  }

  static async download(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "download successful");
    } catch (error) {
      next(error);
    }
  }

  static async preview(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "preview successful");
    } catch (error) {
      next(error);
    }
  }

  static async share(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "share successful");
    } catch (error) {
      next(error);
    }
  }

  static async favorite(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "favorite successful");
    } catch (error) {
      next(error);
    }
  }

  static async bulkDelete(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "bulkDelete successful");
    } catch (error) {
      next(error);
    }
  }

  static async bulkMove(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "bulkMove successful");
    } catch (error) {
      next(error);
    }
  }

  static async bulkCopy(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, {}, "bulkCopy successful");
    } catch (error) {
      next(error);
    }
  }

}
