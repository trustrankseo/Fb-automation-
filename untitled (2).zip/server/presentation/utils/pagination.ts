export interface PaginationQuery {
  page?: string;
  pageSize?: string;
  sort?: string;
  order?: 'asc' | 'desc';
  search?: string;
  filter?: string;
}

export interface PaginationMeta {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
}

export const getPaginationOptions = (query: PaginationQuery) => {
  const page = parseInt(query.page || '1', 10);
  const pageSize = parseInt(query.pageSize || '10', 10);
  
  return {
    limit: pageSize,
    offset: (page - 1) * pageSize,
    page,
    pageSize,
    sort: query.sort,
    order: query.order || 'asc',
    search: query.search,
    filter: query.filter
  };
};

export const createPaginationMeta = (total: number, page: number, pageSize: number): PaginationMeta => {
  const totalPages = Math.ceil(total / pageSize);
  return {
    page,
    pageSize,
    total,
    totalPages,
    hasNext: page < totalPages,
    hasPrevious: page > 1,
  };
};
