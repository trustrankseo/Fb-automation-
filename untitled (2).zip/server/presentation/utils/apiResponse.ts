import { Response } from 'express';

export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  meta?: any;
  requestId?: string;
  timestamp: string;
}

export interface ApiErrorResponse {
  success: boolean;
  message: string;
  errorCode: string;
  errors?: any[];
  requestId?: string;
  timestamp: string;
}

export const sendSuccess = <T>(
  res: Response,
  data: T,
  message: string = 'Success',
  meta?: any,
  statusCode: number = 200
) => {
  const response: ApiResponse<T> = {
    success: true,
    message,
    data,
    meta,
    requestId: res.locals.requestId,
    timestamp: new Date().toISOString(),
  };
  return res.status(statusCode).json(response);
};

export const sendError = (
  res: Response,
  message: string,
  errorCode: string = 'SYSTEM_001',
  errors?: any[],
  statusCode: number = 500
) => {
  const response: ApiErrorResponse = {
    success: false,
    message,
    errorCode,
    errors,
    requestId: res.locals.requestId,
    timestamp: new Date().toISOString(),
  };
  return res.status(statusCode).json(response);
};
