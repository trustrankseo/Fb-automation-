import { Request, Response, NextFunction } from "express";
import { logger } from "../../config/logger.js";
import { v4 as uuidv4 } from "uuid";

export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const requestId = req.headers["x-request-id"] || uuidv4();
  const correlationId = req.headers["x-correlation-id"] || requestId;
  const start = Date.now();

  res.locals.requestId = requestId;
  res.locals.correlationId = correlationId;

  res.setHeader("Request-ID", requestId as string);
  res.setHeader("Correlation-ID", correlationId as string);
  res.setHeader("API-Version", "v1");

  res.on("finish", () => {
    const duration = Date.now() - start;
    // Audit Logging
    logger.http(JSON.stringify({
      level: "info",
      type: "audit",
      requestId,
      correlationId,
      method: req.method,
      url: req.originalUrl,
      status: res.statusCode,
      duration,
      ip: req.ip,
      user: res.locals.user?.id || "anonymous",
      organization: req.headers["x-organization-id"] || "none",
      timestamp: new Date().toISOString()
    }));
  });

  next();
};
