import { Request, Response, NextFunction } from "express";
import { sendError } from "../utils/apiResponse.js";
import { logger } from "../../config/logger.js";

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  logger.error(`[API Error]: ${err.message}`, { stack: err.stack, requestId: res.locals.requestId });
  
  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  const errorCode = err.errorCode || "SYSTEM_001";
  
  sendError(res, message, errorCode, err.errors, statusCode);
};

export const notFoundHandler = (req: Request, res: Response, next: NextFunction) => {
  sendError(res, `Route ${req.method} ${req.originalUrl} not found`, "SYSTEM_404", undefined, 404);
};

export class ApiError extends Error {
  statusCode: number;
  errorCode: string;
  errors?: any[];

  constructor(statusCode: number, message: string, errorCode: string = "SYSTEM_001", errors?: any[]) {
    super(message);
    this.statusCode = statusCode;
    this.errorCode = errorCode;
    this.errors = errors;
    Object.setPrototypeOf(this, ApiError.prototype);
  }
}
