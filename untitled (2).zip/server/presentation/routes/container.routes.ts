import { Router } from "express";
import { ContainerController } from "../controllers/ContainerController.js";

const router = Router();

router.get("/", ContainerController.getAll);
router.get("/:id", ContainerController.getById);
router.post("/restart", ContainerController.restart);
router.post("/scale", ContainerController.scale);

export default router;
