import { Router } from "express";
import { RoleController } from "../controllers/RoleController.js";

const router = Router();

router.get("/", RoleController.getAll);
router.get("/:id", RoleController.getById);
router.post("/", RoleController.create);
router.put("/:id", RoleController.update);
router.delete("/:id", RoleController.delete);
router.post("/:id/permissions", RoleController.assignPermission);
router.delete("/:id/permissions/:permissionId", RoleController.removePermission);

export default router;
