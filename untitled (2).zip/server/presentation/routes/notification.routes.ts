import { Router } from "express";
import { NotificationController } from "../controllers/NotificationController.js";
import { NotificationTemplateController } from "../controllers/NotificationTemplateController.js";

const router = Router();

// Templates
router.get("/templates", NotificationTemplateController.getAll);
router.post("/templates", NotificationTemplateController.create);
router.put("/templates/:id", NotificationTemplateController.update);
router.delete("/templates/:id", NotificationTemplateController.delete);

// Notifications
router.get("/", NotificationController.getAll);
router.get("/:id", NotificationController.getById);
router.post("/", NotificationController.create);
router.patch("/read-all", NotificationController.markAllAsRead);
router.patch("/:id/read", NotificationController.markAsRead);
router.delete("/:id", NotificationController.delete);

export default router;
