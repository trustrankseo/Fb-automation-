import { Router } from "express";
import { LicenseController } from "../controllers/LicenseController.js";

const router = Router();

router.get("/", LicenseController.getAll);
router.get("/:id", LicenseController.getById);
router.post("/", LicenseController.create);
router.put("/:id", LicenseController.update);
router.post("/:id/activate", LicenseController.activate);
router.post("/:id/deactivate", LicenseController.deactivate);
router.post("/:id/rotate", LicenseController.rotate);

export default router;
