import { Router } from "express";
import { AnalyticsController } from "../controllers/AnalyticsController.js";

const router = Router();

router.get("/overview", AnalyticsController.getOverview);
router.get("/projects", AnalyticsController.getProjects);
router.get("/storage", AnalyticsController.getStorage);
router.get("/downloads", AnalyticsController.getDownloads);
router.get("/users", AnalyticsController.getUsers);
router.get("/ai", AnalyticsController.getAi);
router.get("/workers", AnalyticsController.getWorkers);
router.get("/queues", AnalyticsController.getQueues);

export default router;
