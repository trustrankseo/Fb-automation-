import { Router } from "express";
import { FeatureFlagController } from "../controllers/FeatureFlagController.js";

const router = Router();

router.get("/", FeatureFlagController.getAll);
router.get("/:id", FeatureFlagController.getById);
router.post("/", FeatureFlagController.create);
router.put("/:id", FeatureFlagController.update);
router.delete("/:id", FeatureFlagController.delete);

export default router;
