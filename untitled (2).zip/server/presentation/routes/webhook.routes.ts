import { Router } from "express";
import { WebhookController } from "../controllers/WebhookController.js";

const router = Router();

router.get("/", WebhookController.getAll);
router.post("/", WebhookController.create);
router.put("/:id", WebhookController.update);
router.delete("/:id", WebhookController.delete);
router.post("/:id/test", WebhookController.test);
router.get("/:id/deliveries", WebhookController.getDeliveries);
router.post("/:id/replay", WebhookController.replay);

export default router;
