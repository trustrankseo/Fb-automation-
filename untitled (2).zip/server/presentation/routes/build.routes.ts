import { Router } from "express";
import { BuildController } from "../controllers/BuildController.js";

const router = Router();

router.get("/", BuildController.getAll);
router.get("/:id", BuildController.getById);
router.post("/", BuildController.create);
router.post("/:id/retry", BuildController.retry);
router.post("/:id/cancel", BuildController.cancel);

export default router;
