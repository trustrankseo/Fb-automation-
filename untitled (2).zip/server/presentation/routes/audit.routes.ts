import { Router } from "express";
import { AuditController } from "../controllers/AuditController.js";

const router = Router();

router.get("/events", AuditController.getEvents);
router.get("/events/:id", AuditController.getEventById);
router.get("/export", AuditController.export);
router.get("/search", AuditController.search);

export default router;
