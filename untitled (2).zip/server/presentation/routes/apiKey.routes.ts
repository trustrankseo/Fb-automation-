import { Router } from "express";
import { ApiKeyController } from "../controllers/ApiKeyController.js";

const router = Router();

router.get("/", ApiKeyController.getAll);
router.post("/", ApiKeyController.create);
router.put("/:id", ApiKeyController.update);
router.delete("/:id", ApiKeyController.delete);
router.post("/:id/rotate", ApiKeyController.rotate);

export default router;
