import { Router } from "express";
import { PublishingDestinationController } from "../controllers/PublishingDestinationController";

const router = Router();

router.get("/project/:projectId", PublishingDestinationController.listByProject);
router.get("/:id", PublishingDestinationController.getById);
router.post("/", PublishingDestinationController.create);

export default router;
