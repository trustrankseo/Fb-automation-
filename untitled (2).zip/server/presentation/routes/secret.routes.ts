import { Router } from "express";
import { SecretController } from "../controllers/SecretController.js";

const router = Router();

router.get("/", SecretController.getAll);
router.post("/", SecretController.create);
router.put("/:id", SecretController.update);
router.delete("/:id", SecretController.delete);
router.post("/:id/rotate", SecretController.rotate);

export default router;
