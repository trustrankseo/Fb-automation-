import { Router } from "express";
import { DashboardController } from "../controllers/DashboardController.js";

const router = Router();

router.get("/", DashboardController.getAll);
router.get("/:id", DashboardController.getById);
router.post("/", DashboardController.create);
router.put("/:id", DashboardController.update);
router.delete("/:id", DashboardController.delete);

export default router;
