import { Router } from "express";
import { WorkspaceController } from "../controllers/WorkspaceController.js";

const router = Router();

router.get("/", WorkspaceController.getAll);
router.get("/:id", WorkspaceController.getById);
router.post("/", WorkspaceController.create);
router.put("/:id", WorkspaceController.update);
router.patch("/:id", WorkspaceController.partialUpdate);
router.delete("/:id", WorkspaceController.delete);
router.get("/:id/members", WorkspaceController.getMembers);
router.post("/:id/members", WorkspaceController.addMember);
router.delete("/:id/members/:userId", WorkspaceController.removeMember);

export default router;
