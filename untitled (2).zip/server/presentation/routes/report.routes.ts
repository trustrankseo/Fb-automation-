import { Router } from "express";
import { ReportController } from "../controllers/ReportController.js";

const router = Router();

router.get("/", ReportController.getAll);
router.get("/:id", ReportController.getById);
router.post("/", ReportController.create);
router.delete("/:id", ReportController.delete);
router.post("/:id/generate", ReportController.generate);
router.post("/:id/download", ReportController.download);
router.post("/:id/schedule", ReportController.schedule);

export default router;
