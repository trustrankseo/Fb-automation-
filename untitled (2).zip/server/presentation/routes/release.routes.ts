import { Router } from "express";
import { ReleaseController } from "../controllers/ReleaseController.js";

const router = Router();

router.get("/", ReleaseController.getAll);
router.get("/:id", ReleaseController.getById);
router.post("/", ReleaseController.create);
router.post("/:id/promote", ReleaseController.promote);
router.post("/:id/archive", ReleaseController.archive);

export default router;
