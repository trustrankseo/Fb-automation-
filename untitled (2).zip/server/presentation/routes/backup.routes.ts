import { Router } from "express";
import { BackupController } from "../controllers/BackupController.js";

const router = Router();

router.get("/", BackupController.getAll);
router.get("/:id", BackupController.getById);
router.post("/", BackupController.create);
router.post("/:id/verify", BackupController.verify);
router.post("/:id/restore", BackupController.restore);
router.delete("/:id", BackupController.delete);

export default router;
