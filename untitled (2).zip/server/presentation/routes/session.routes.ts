import { Router } from "express";
import { SessionController } from "../controllers/SessionController.js";

const router = Router();

router.get("/", SessionController.getAll);
router.delete("/", SessionController.deleteAll);
router.delete("/:id", SessionController.delete);

export default router;
