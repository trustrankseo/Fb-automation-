import { Router } from "express";
import { ProjectController } from "../controllers/ProjectController";

const router = Router();

router.get("/", ProjectController.list);
router.get("/:id", ProjectController.getById);
router.post("/", ProjectController.create);


router.put("/:id", ProjectController.update);
router.patch("/:id", ProjectController.partialUpdate);
router.delete("/:id", ProjectController.delete);
router.get("/:id/members", ProjectController.getMembers);
router.post("/:id/members", ProjectController.addMember);
router.delete("/:id/members/:userId", ProjectController.removeMember);
router.get("/:id/versions", ProjectController.getVersions);
router.post("/:id/duplicate", ProjectController.duplicate);
router.post("/:id/archive", ProjectController.archive);
router.post("/:id/restore", ProjectController.restore);
router.post("/bulk-archive", ProjectController.bulkArchive);

export default router;
