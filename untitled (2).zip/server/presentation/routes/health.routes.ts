import { Router } from "express";
import { HealthController } from "../controllers/HealthController.js";

const router = Router();

router.get("/", HealthController.getHealth);
router.get("/database", HealthController.getDatabaseHealth);
router.get("/storage", HealthController.getStorageHealth);
router.get("/queue", HealthController.getQueueHealth);
router.get("/workers", HealthController.getWorkersHealth);
router.get("/integrations", HealthController.getIntegrationsHealth);

export default router;
