import { Router } from "express";
import { FileController } from "../controllers/FileController.js";

const router = Router();

router.get("/", FileController.getAll);
router.get("/:id", FileController.getById);
router.post("/upload", FileController.upload);
router.post("/upload/bulk", FileController.uploadBulk);
router.patch("/:id", FileController.partialUpdate);
router.delete("/:id", FileController.delete);
router.post("/:id/copy", FileController.copy);
router.post("/:id/move", FileController.move);
router.post("/:id/rename", FileController.rename);
router.post("/:id/download", FileController.download);
router.post("/:id/preview", FileController.preview);
router.post("/:id/share", FileController.share);
router.post("/:id/favorite", FileController.favorite);

router.post("/bulk-delete", FileController.bulkDelete);
router.post("/bulk-move", FileController.bulkMove);
router.post("/bulk-copy", FileController.bulkCopy);

export default router;
