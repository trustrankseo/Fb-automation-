import { Router } from "express";
import { UserController } from "../controllers/UserController.js";

const router = Router();

router.get("/", UserController.getAll);
router.get("/:id", UserController.getById);
router.post("/", UserController.create);
router.put("/:id", UserController.update);
router.patch("/:id", UserController.partialUpdate);
router.delete("/:id", UserController.delete);
router.post("/:id/avatar", UserController.updateAvatar);
router.patch("/:id/status", UserController.updateStatus);
router.patch("/:id/preferences", UserController.updatePreferences);
router.post("/:id/roles", UserController.assignRole);
router.delete("/:id/roles/:roleId", UserController.removeRole);

export default router;
