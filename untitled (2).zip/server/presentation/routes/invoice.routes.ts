import { Router } from "express";
import { InvoiceController } from "../controllers/InvoiceController.js";

const router = Router();

router.get("/", InvoiceController.getAll);
router.get("/:id", InvoiceController.getById);
router.post("/", InvoiceController.create);
router.post("/:id/pay", InvoiceController.pay);
router.post("/:id/download", InvoiceController.download);
router.post("/:id/void", InvoiceController.voidInvoice);

export default router;
