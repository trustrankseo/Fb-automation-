import { Router } from "express";
import { ObservabilityController } from "../controllers/ObservabilityController.js";

const router = Router();

router.get("/metrics", ObservabilityController.getMetrics);
router.get("/activity-logs", ObservabilityController.getActivityLogs);
router.get("/audit-events", ObservabilityController.getAuditEvents);
router.get("/system-logs", ObservabilityController.getSystemLogs);

export default router;
