import { Router } from "express";
import { PaymentController } from "../controllers/PaymentController.js";

const router = Router();

router.get("/", PaymentController.getAll);
router.get("/:id", PaymentController.getById);
router.post("/", PaymentController.create);
router.post("/webhook", PaymentController.webhook);
router.post("/refund", PaymentController.refund);

export default router;
