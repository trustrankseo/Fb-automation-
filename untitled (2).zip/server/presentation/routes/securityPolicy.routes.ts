import { Router } from "express";
import { SecurityPolicyController } from "../controllers/SecurityPolicyController.js";

const router = Router();

router.get("/", SecurityPolicyController.getAll);
router.get("/:id", SecurityPolicyController.getById);
router.post("/", SecurityPolicyController.create);
router.put("/:id", SecurityPolicyController.update);
router.delete("/:id", SecurityPolicyController.delete);

export default router;
