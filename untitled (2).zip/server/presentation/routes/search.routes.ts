import { Router } from "express";
import { SearchController } from "../controllers/SearchController.js";

const router = Router();

router.get("/", SearchController.search);
router.get("/files", SearchController.searchFiles);
router.get("/projects", SearchController.searchProjects);
router.get("/workspaces", SearchController.searchWorkspaces);

export default router;
