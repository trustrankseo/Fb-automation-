import { Router } from "express";
import { JobController } from "../controllers/JobController";

const router = Router();

router.get("/project/:projectId", JobController.listByProject);
router.get("/:id", JobController.getById);
router.post("/", JobController.create);

export default router;
