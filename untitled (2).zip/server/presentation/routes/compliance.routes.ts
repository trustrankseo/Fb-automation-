import { Router } from "express";
import { ComplianceController } from "../controllers/ComplianceController.js";

const router = Router();

router.get("/frameworks", ComplianceController.getFrameworks);
router.get("/status", ComplianceController.getStatus);
router.get("/reports", ComplianceController.getReports);
router.post("/scan", ComplianceController.scan);
router.post("/audit", ComplianceController.audit);

export default router;
