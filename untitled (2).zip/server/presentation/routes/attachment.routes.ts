import { Router } from "express";
import { AttachmentController } from "../controllers/AttachmentController.js";

const router = Router();

router.get("/", AttachmentController.getAll);
router.post("/", AttachmentController.create);
router.delete("/:id", AttachmentController.delete);

export default router;
