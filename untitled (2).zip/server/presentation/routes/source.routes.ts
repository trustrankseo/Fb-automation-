import { Router } from "express";
import { SourceController } from "../controllers/SourceController";

const router = Router();

// Assuming routes are mounted like /api/projects/:projectId/sources
// Or flat like /api/sources?projectId=123
// We will mount this under /api/sources and expect projectId in body/params

router.get("/project/:projectId", SourceController.listByProject);
router.get("/:id", SourceController.getById);
router.post("/", SourceController.create);

export default router;
