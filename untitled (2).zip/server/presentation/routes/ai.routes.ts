import { Router } from "express";
import { agentRouter } from "../../application/ai/AIAgentRouter";
import { sendApiResponse } from "../../utils/apiResponse";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

const router = Router();

router.post("/execute", async (req, res, next) => {
  try {
    const { intent, context } = req.body;

    if (!intent) {
      return res.status(400).json({ success: false, message: "Intent is required" });
    }

    // Example context (should come from auth middleware)
    const agentContext = context || {
      userId: "usr_123",
      organizationId: "org_123",
      permissions: ["read:analytics"],
    };

    const result = await agentRouter.route(intent, agentContext);

    // Emit event asynchronously
    await eventBus.publish({
      eventType: "AIRecommendationGenerated",
      eventVersion: "1.0",
      sourceModule: "AIAgentRouter",
      payload: { intent, result },
    });

    sendApiResponse({
      res,
      req,
      message: "AI Agent executed successfully",
      data: result,
    });
  } catch (error) {
    next(error);
  }
});

export default router;
