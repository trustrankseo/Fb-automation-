import { Router } from "express";
import { SystemController } from "../controllers/SystemController.js";

const router = Router();

router.get("/health", SystemController.getHealth);
router.get("/status", SystemController.getStatus);
router.get("/metrics", SystemController.getMetrics);
router.get("/logs", SystemController.getLogs);
router.get("/workers", SystemController.getWorkers);
router.get("/queues", SystemController.getQueues);
router.get("/storage", SystemController.getStorage);


router.get("/configuration", SystemController.getConfiguration);
router.put("/configuration", SystemController.updateConfiguration);
router.get("/environment", SystemController.getEnvironment);
router.get("/services", SystemController.getServices);
router.post("/services/:id/restart", SystemController.restartService);
router.post("/cache/clear", SystemController.clearCache);
router.post("/cache/rebuild", SystemController.rebuildCache);

export default router;
