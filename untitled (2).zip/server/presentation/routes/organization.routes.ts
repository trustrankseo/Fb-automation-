import { Router } from "express";
import { OrganizationController } from "../controllers/OrganizationController";

const router = Router();

router.get("/", OrganizationController.getAll);
router.get("/:id", OrganizationController.getById);
router.post("/", OrganizationController.create);


router.put("/:id", OrganizationController.update);
router.patch("/:id", OrganizationController.partialUpdate);
router.delete("/:id", OrganizationController.delete);
router.patch("/:id/branding", OrganizationController.updateBranding);
router.patch("/:id/settings", OrganizationController.updateSettings);

export default router;
