import { Router } from "express";
import { InfrastructureController } from "../controllers/InfrastructureController.js";

const router = Router();

router.get("/", InfrastructureController.getInfrastructure);
router.get("/services", InfrastructureController.getServices);
router.get("/nodes", InfrastructureController.getNodes);
router.get("/storage", InfrastructureController.getStorage);
router.get("/network", InfrastructureController.getNetwork);
router.post("/refresh", InfrastructureController.refresh);

export default router;
