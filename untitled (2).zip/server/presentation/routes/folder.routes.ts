import { Router } from "express";
import { FolderController } from "../controllers/FolderController.js";

const router = Router();

router.get("/", FolderController.getAll);
router.post("/", FolderController.create);
router.put("/:id", FolderController.update);
router.delete("/:id", FolderController.delete);
router.post("/:id/move", FolderController.move);

export default router;
