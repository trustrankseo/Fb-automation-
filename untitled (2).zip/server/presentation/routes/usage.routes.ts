import { Router } from "express";
import { UsageController } from "../controllers/UsageController.js";

const router = Router();

router.get("/", UsageController.getAll);
router.get("/statistics", UsageController.getStatistics);
router.get("/limits", UsageController.getLimits);
router.post("/reset", UsageController.reset);

export default router;
