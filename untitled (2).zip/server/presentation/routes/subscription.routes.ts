import { Router } from "express";
import { SubscriptionController } from "../controllers/SubscriptionController.js";

const router = Router();

router.get("/", SubscriptionController.getAll);
router.get("/:id", SubscriptionController.getById);
router.post("/", SubscriptionController.create);
router.put("/:id", SubscriptionController.update);
router.delete("/:id", SubscriptionController.delete);
router.post("/:id/cancel", SubscriptionController.cancel);
router.post("/:id/resume", SubscriptionController.resume);
router.post("/:id/upgrade", SubscriptionController.upgrade);
router.post("/:id/downgrade", SubscriptionController.downgrade);

export default router;
