import { Router } from "express";
import { PermissionController } from "../controllers/PermissionController.js";

const router = Router();

router.get("/", PermissionController.getAll);
router.get("/:id", PermissionController.getById);

export default router;
