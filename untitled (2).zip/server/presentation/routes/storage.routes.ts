import { Router } from "express";
import { StorageController } from "../controllers/StorageController.js";

const router = Router();

router.get("/providers", StorageController.getProviders);
router.post("/providers", StorageController.createProvider);
router.put("/providers/:id", StorageController.updateProvider);
router.delete("/providers/:id", StorageController.deleteProvider);
router.get("/statistics", StorageController.getStatistics);
router.get("/usage", StorageController.getUsage);

export default router;
