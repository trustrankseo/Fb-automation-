import { Router } from "express";
import { EnvironmentController } from "../controllers/EnvironmentController.js";

const router = Router();

router.get("/", EnvironmentController.getAll);
router.get("/:id", EnvironmentController.getById);
router.post("/", EnvironmentController.create);
router.put("/:id", EnvironmentController.update);
router.delete("/:id", EnvironmentController.delete);

export default router;
