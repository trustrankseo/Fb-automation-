import { Router } from "express";
import { BillingController } from "../controllers/BillingController.js";

const router = Router();

router.get("/events", BillingController.getEvents);
router.get("/history", BillingController.getHistory);
router.get("/providers", BillingController.getProviders);
router.post("/providers/test", BillingController.testProvider);

export default router;
