import { Router } from "express";
import { EncryptionKeyController } from "../controllers/EncryptionKeyController.js";

const router = Router();

router.get("/", EncryptionKeyController.getAll);
router.post("/", EncryptionKeyController.create);
router.post("/:id/rotate", EncryptionKeyController.rotate);
router.delete("/:id", EncryptionKeyController.delete);

export default router;
