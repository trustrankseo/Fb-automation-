import { Router } from "express";
import { PluginController } from "../controllers/PluginController.js";

const router = Router();

router.get("/", PluginController.getAll);
router.get("/:id", PluginController.getById);
router.post("/install", PluginController.install);
router.post("/:id/enable", PluginController.enable);
router.post("/:id/disable", PluginController.disable);
router.post("/:id/update", PluginController.update);
router.delete("/:id", PluginController.delete);
router.get("/:id/permissions", PluginController.getPermissions);

export default router;
