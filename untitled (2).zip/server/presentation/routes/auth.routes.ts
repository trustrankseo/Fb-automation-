import { Router } from "express";
import { AuthController } from "../controllers/AuthController.js";
import { validateRequest } from "../middlewares/validators/validateRequest.js";
import { LoginSchema, RegisterSchema, ChangePasswordSchema } from "../../application/dtos/AuthDTOs.js";

const router = Router();

router.post("/login", validateRequest(LoginSchema), AuthController.login);
router.post("/logout", AuthController.logout);
router.post("/refresh", AuthController.refresh);
router.post("/register", validateRequest(RegisterSchema), AuthController.register);
router.post("/verify-email", AuthController.verifyEmail);
router.post("/resend-verification", AuthController.resendVerification);
router.post("/forgot-password", AuthController.forgotPassword);
router.post("/reset-password", AuthController.resetPassword);
router.post("/change-password", validateRequest(ChangePasswordSchema), AuthController.changePassword);
router.post("/enable-2fa", AuthController.enable2fa);
router.post("/verify-2fa", AuthController.verify2fa);
router.post("/disable-2fa", AuthController.disable2fa);
router.get("/me", AuthController.getMe);

export default router;
