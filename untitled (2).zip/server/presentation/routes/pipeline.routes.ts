import { Router } from "express";
import { PipelineController } from "../controllers/PipelineController.js";

const router = Router();

router.get("/", PipelineController.getAll);
router.get("/:id", PipelineController.getById);
router.post("/", PipelineController.create);
router.put("/:id", PipelineController.update);
router.delete("/:id", PipelineController.delete);
router.post("/:id/execute", PipelineController.execute);

export default router;
