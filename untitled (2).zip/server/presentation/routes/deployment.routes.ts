import { Router } from "express";
import { DeploymentController } from "../controllers/DeploymentController.js";

const router = Router();

router.get("/", DeploymentController.getAll);
router.get("/history", DeploymentController.getHistory);
router.get("/:id", DeploymentController.getById);
router.post("/", DeploymentController.create);
router.post("/:id/rollback", DeploymentController.rollback);
router.post("/:id/cancel", DeploymentController.cancel);

export default router;
