import { Router } from "express";
import { DisasterRecoveryController } from "../controllers/DisasterRecoveryController.js";

const router = Router();

router.get("/status", DisasterRecoveryController.getStatus);
router.post("/test", DisasterRecoveryController.test);
router.post("/failover", DisasterRecoveryController.failover);
router.post("/failback", DisasterRecoveryController.failback);

export default router;
