import { IAIProvider } from "../../infrastructure/providers/ai/IAIProvider";
import { GeminiProvider } from "../../infrastructure/providers/ai/GeminiProvider";
import { logger } from "../../config/logger";
import { BusinessException } from "../../types/errors";

export interface AgentContext {
  userId?: string;
  organizationId?: string;
  projectId?: string;
  permissions: string[];
}

export abstract class BaseAgent {
  protected provider: IAIProvider;
  
  constructor(provider: IAIProvider) {
    this.provider = provider;
  }

  abstract execute(intent: string, context: AgentContext): Promise<any>;
}

export class AnalyticsAgent extends BaseAgent {
  async execute(intent: string, context: AgentContext): Promise<any> {
    logger.info(`[AnalyticsAgent] Analyzing intent for org: ${context.organizationId}`);
    const prompt = `Analyze the following user request and suggest an analytics workflow. Request: ${intent}`;
    
    const response = await this.provider.generateText(prompt);
    return {
      agent: "AnalyticsAgent",
      recommendation: response.data,
      requiresApproval: false
    };
  }
}

export class AIAgentRouter {
  private provider: IAIProvider;
  private agents: Map<string, BaseAgent> = new Map();

  constructor() {
    this.provider = new GeminiProvider(); // In a real scenario, this is injected
    this.agents.set("analytics", new AnalyticsAgent(this.provider));
  }

  async route(intent: string, context: AgentContext): Promise<any> {
    logger.info(`[AIAgentRouter] Routing intent: ${intent.substring(0, 50)}...`);
    
    // In a real system, the Router would use an LLM to detect the intent category
    // For now, we mock the routing based on keywords
    let selectedAgent = "analytics";

    if (!this.agents.has(selectedAgent)) {
      throw new BusinessException(`No suitable AI Agent found for intent.`);
    }

    const agent = this.agents.get(selectedAgent)!;
    return await agent.execute(intent, context);
  }
}

export const agentRouter = new AIAgentRouter();
