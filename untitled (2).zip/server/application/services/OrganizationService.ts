import { IOrganizationRepository } from "../../domain/repositories/IOrganizationRepository";
import { Organization, OrganizationStatus, SubscriptionPlan } from "../../domain/entities/Organization";
import { BusinessException, NotFoundException, ValidationException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class OrganizationService {
  constructor(private readonly repository: IOrganizationRepository) {}

  async getAllOrganizations(): Promise<Organization[]> {
    return this.repository.findAll();
  }

  async getOrganizationById(id: string): Promise<Organization> {
    const org = await this.repository.findById(id);
    if (!org) {
      throw new NotFoundException("Organization");
    }
    return org;
  }

  async createOrganization(name: string, slug: string): Promise<Organization> {
    // 1. Validation
    if (!name || name.trim() === "") {
      throw new ValidationException("Organization name is required");
    }
    if (!slug || !/^[a-z0-9-]+$/.test(slug)) {
      throw new ValidationException("Invalid slug format. Use lowercase alphanumeric and hyphens.");
    }

    // 2. Check for conflicts
    const existing = await this.repository.findBySlug(slug);
    if (existing) {
      throw new BusinessException(`Organization with slug '${slug}' already exists.`);
    }

    // 3. Create Entity
    const orgData = {
      name: name.trim(),
      slug: slug.toLowerCase(),
      status: OrganizationStatus.ACTIVE,
      subscriptionPlan: SubscriptionPlan.FREE,
    };

    const newOrg = await this.repository.create(orgData);
    logger.info(`Organization created: ${newOrg.id}`, { slug: newOrg.slug });

    // 4. Dispatch Event
    await eventBus.publish({
      eventType: "OrganizationCreated",
      eventVersion: "1.0",
      sourceModule: "OrganizationService",
      organizationId: newOrg.id,
      payload: newOrg,
    });

    return newOrg;
  }
}
