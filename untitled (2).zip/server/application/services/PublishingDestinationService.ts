import { IPublishingDestinationRepository } from "../../domain/repositories/IPublishingDestinationRepository";
import { PublishingDestination, DestinationType, DestinationStatus } from "../../domain/entities/PublishingDestination";
import { BusinessException, NotFoundException, ValidationException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class PublishingDestinationService {
  constructor(private readonly repository: IPublishingDestinationRepository) {}

  async getDestinationById(id: string): Promise<PublishingDestination> {
    const dest = await this.repository.findById(id);
    if (!dest) throw new NotFoundException("PublishingDestination");
    return dest;
  }

  async getDestinationsByProject(projectId: string): Promise<PublishingDestination[]> {
    return this.repository.findByProjectId(projectId);
  }

  async createDestination(projectId: string, name: string, type: DestinationType): Promise<PublishingDestination> {
    if (!name || name.trim() === "") throw new ValidationException("Destination name is required");

    const destData = {
      projectId,
      name: name.trim(),
      type,
      status: DestinationStatus.ACTIVE,
    };

    const newDest = await this.repository.create(destData);
    logger.info(`Publishing Destination created: ${newDest.id}`, { projectId });

    await eventBus.publish({
      eventType: "PublishingDestinationCreated",
      eventVersion: "1.0",
      sourceModule: "PublishingDestinationService",
      projectId,
      payload: newDest,
    });

    return newDest;
  }
}
