import { IProjectRepository } from "../../domain/repositories/IProjectRepository";
import { Project, ProjectStatus } from "../../domain/entities/Project";
import { BusinessException, NotFoundException, ValidationException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class ProjectService {
  constructor(private readonly repository: IProjectRepository) {}

  async getProjectById(id: string, organizationId: string): Promise<Project> {
    const project = await this.repository.findById(id);
    if (!project || project.organizationId !== organizationId) {
      throw new NotFoundException("Project");
    }
    return project;
  }

  async getProjectsByOrg(organizationId: string): Promise<Project[]> {
    return this.repository.findByOrganizationId(organizationId);
  }

  async createProject(organizationId: string, name: string, description: string | null): Promise<Project> {
    if (!name || name.trim() === "") {
      throw new ValidationException("Project name is required");
    }

    const projectData = {
      organizationId,
      name: name.trim(),
      description: description ? description.trim() : null,
      status: ProjectStatus.ACTIVE,
    };

    const newProject = await this.repository.create(projectData);
    logger.info(`Project created: ${newProject.id}`, { organizationId });

    await eventBus.publish({
      eventType: "ProjectCreated",
      eventVersion: "1.0",
      sourceModule: "ProjectService",
      organizationId,
      projectId: newProject.id,
      payload: newProject,
    });

    return newProject;
  }
}
