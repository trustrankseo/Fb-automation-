import { ISourceRepository } from "../../domain/repositories/ISourceRepository";
import { Source, SourceType, SourceStatus } from "../../domain/entities/Source";
import { BusinessException, NotFoundException, ValidationException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class SourceService {
  constructor(private readonly repository: ISourceRepository) {}

  async getSourceById(id: string): Promise<Source> {
    const source = await this.repository.findById(id);
    if (!source) {
      throw new NotFoundException("Source");
    }
    return source;
  }

  async getSourcesByProject(projectId: string): Promise<Source[]> {
    return this.repository.findByProjectId(projectId);
  }

  async createSource(projectId: string, name: string, type: SourceType): Promise<Source> {
    if (!name || name.trim() === "") {
      throw new ValidationException("Source name is required");
    }

    const sourceData = {
      projectId,
      name: name.trim(),
      type,
      status: SourceStatus.ACTIVE, // Normally would be PENDING_CONNECTION
    };

    const newSource = await this.repository.create(sourceData);
    logger.info(`Source created: ${newSource.id}`, { projectId });

    await eventBus.publish({
      eventType: "SourceCreated",
      eventVersion: "1.0",
      sourceModule: "SourceService",
      projectId,
      payload: newSource,
    });

    return newSource;
  }
}
