import { IJobRepository } from "../../domain/repositories/IJobRepository";
import { Job, JobType, JobStatus } from "../../domain/entities/Job";
import { NotFoundException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class JobService {
  constructor(private readonly repository: IJobRepository) {}

  async getJobById(id: string): Promise<Job> {
    const job = await this.repository.findById(id);
    if (!job) throw new NotFoundException("Job");
    return job;
  }

  async getJobsByProject(projectId: string): Promise<Job[]> {
    return this.repository.findByProjectId(projectId);
  }

  async createJob(projectId: string, type: JobType, payload: Record<string, any>): Promise<Job> {
    const jobData = {
      projectId,
      type,
      payload,
      status: JobStatus.PENDING,
      progress: 0,
    };

    const newJob = await this.repository.create(jobData);
    logger.info(`Job created: ${newJob.id}`, { type, projectId });

    await eventBus.publish({
      eventType: "JobCreated",
      eventVersion: "1.0",
      sourceModule: "JobService",
      projectId,
      payload: newJob,
    });

    return newJob;
  }

  async updateJobProgress(id: string, progress: number): Promise<void> {
    await this.repository.update(id, { progress });
  }

  async completeJob(id: string, result: Record<string, any>): Promise<void> {
    const job = await this.repository.update(id, { 
      status: JobStatus.COMPLETED, 
      progress: 100, 
      result 
    });
    
    if (job) {
      await eventBus.publish({
        eventType: "JobCompleted",
        eventVersion: "1.0",
        sourceModule: "JobService",
        projectId: job.projectId,
        payload: job,
      });
    }
  }

  async failJob(id: string, error: string): Promise<void> {
    const job = await this.repository.update(id, { 
      status: JobStatus.FAILED, 
      error 
    });
    
    if (job) {
      await eventBus.publish({
        eventType: "JobFailed",
        eventVersion: "1.0",
        sourceModule: "JobService",
        projectId: job.projectId,
        payload: job,
      });
    }
  }
}
