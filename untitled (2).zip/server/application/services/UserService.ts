import { IUserRepository } from "../../domain/repositories/IUserRepository";
import { User, UserRole } from "../../domain/entities/User";
import { BusinessException, NotFoundException, ValidationException } from "../../types/errors";
import { logger } from "../../config/logger";
import { eventBus } from "../../infrastructure/eventBus/EventBus";

export class UserService {
  constructor(private readonly repository: IUserRepository) {}

  async getUserById(id: string): Promise<User> {
    const user = await this.repository.findById(id);
    if (!user) throw new NotFoundException("User");
    return user;
  }

  async getUsersByOrganization(organizationId: string): Promise<User[]> {
    return this.repository.findByOrganizationId(organizationId);
  }

  async inviteUser(organizationId: string, email: string, fullName: string, role: UserRole): Promise<User> {
    if (!email || !email.includes("@")) throw new ValidationException("A valid email is required");

    const existing = await this.repository.findByEmail(email);
    if (existing) {
      if (existing.organizationId === organizationId) {
        throw new BusinessException("User is already in this organization.");
      } else {
        throw new BusinessException("User email is registered to another organization.");
      }
    }

    const userData = {
      organizationId,
      email: email.toLowerCase(),
      fullName: fullName.trim(),
      role,
      isActive: true, // Assuming auto-accept for this demo
    };

    const newUser = await this.repository.create(userData);
    logger.info(`User invited/created: ${newUser.id}`, { organizationId, email });

    await eventBus.publish({
      eventType: "UserInvited",
      eventVersion: "1.0",
      sourceModule: "UserService",
      organizationId,
      userId: newUser.id,
      payload: newUser,
    });

    return newUser;
  }
}
