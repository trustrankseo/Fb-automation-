import { z } from "zod";

export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, "Password is required"),
  deviceInfo: z.string().optional(),
  rememberMe: z.boolean().optional().default(false)
});

export const RegisterSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, "Password is required")
    
    
    
    ,
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  organizationName: z.string().min(2)
});

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(1, "Password is required")
});
