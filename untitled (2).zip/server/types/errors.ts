export enum ErrorSeverity {
  INFO = "INFO",
  WARNING = "WARNING",
  ERROR = "ERROR",
  CRITICAL = "CRITICAL",
  FATAL = "FATAL",
}

export enum ErrorCode {
  VALIDATION_ERROR = "VALIDATION_ERROR",
  UNAUTHORIZED = "UNAUTHORIZED",
  FORBIDDEN = "FORBIDDEN",
  NOT_FOUND = "NOT_FOUND",
  CONFLICT = "CONFLICT",
  RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED",
  INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR",
  SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE",
  BAD_REQUEST = "BAD_REQUEST",
}

export abstract class BaseException extends Error {
  public readonly code: ErrorCode;
  public readonly severity: ErrorSeverity;
  public readonly statusCode: number;
  public readonly details: any[];
  public readonly isOperational: boolean;

  constructor(
    message: string,
    code: ErrorCode,
    severity: ErrorSeverity,
    statusCode: number,
    details: any[] = [],
    isOperational: boolean = true
  ) {
    super(message);
    this.code = code;
    this.severity = severity;
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ApplicationException extends BaseException {
  constructor(message: string, details: any[] = []) {
    super(message, ErrorCode.INTERNAL_SERVER_ERROR, ErrorSeverity.ERROR, 500, details);
  }
}

export class BusinessException extends BaseException {
  constructor(message: string, code: ErrorCode = ErrorCode.CONFLICT, details: any[] = []) {
    super(message, code, ErrorSeverity.WARNING, 409, details);
  }
}

export class ValidationException extends BaseException {
  constructor(message: string, details: any[] = []) {
    super(message, ErrorCode.VALIDATION_ERROR, ErrorSeverity.INFO, 422, details);
  }
}

export class PermissionException extends BaseException {
  constructor(message: string = "Access denied") {
    super(message, ErrorCode.FORBIDDEN, ErrorSeverity.WARNING, 403);
  }
}

export class AuthenticationException extends BaseException {
  constructor(message: string = "Unauthorized") {
    super(message, ErrorCode.UNAUTHORIZED, ErrorSeverity.WARNING, 401);
  }
}

export class NotFoundException extends BaseException {
  constructor(resource: string = "Resource") {
    super(`${resource} not found`, ErrorCode.NOT_FOUND, ErrorSeverity.INFO, 404);
  }
}

export class InfrastructureException extends BaseException {
  constructor(message: string, details: any[] = []) {
    super(message, ErrorCode.SERVICE_UNAVAILABLE, ErrorSeverity.CRITICAL, 503, details);
  }
}
