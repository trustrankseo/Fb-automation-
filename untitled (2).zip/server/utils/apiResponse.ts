import { Response, Request } from "express";

interface ApiResponseOptions {
  res: Response;
  req: Request;
  message: string;
  data?: any;
  meta?: any;
  statusCode?: number;
  errorCode?: string;
  errors?: any[];
}

export const sendApiResponse = ({
  res,
  req,
  message,
  data,
  meta,
  statusCode = 200,
  errorCode,
  errors,
}: ApiResponseOptions) => {
  const requestId = res.locals.requestId || req.headers["x-request-id"] || req.headers["X-Request-ID"] || "";
  const success = statusCode >= 200 && statusCode < 300;

  if (success) {
    return res.status(statusCode).json({
      success: true,
      message,
      data: data || {},
      meta: meta || {},
      requestId,
      timestamp: new Date().toISOString(),
    });
  } else {
    return res.status(statusCode).json({
      success: false,
      message,
      errorCode: errorCode || "SYSTEM_001",
      errors: errors || [],
      requestId,
      timestamp: new Date().toISOString(),
    });
  }
};
