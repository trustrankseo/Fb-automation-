import { describe, it, expect } from 'vitest';
import request from 'supertest';
import express from 'express';
import authRoutes from '../presentation/routes/auth.routes.js';

const app = express();
app.use(express.json());
app.use('/api/v1/auth', authRoutes);

describe('Auth API', () => {
  it('should return invalid credentials for empty login', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({});
    // The validation middleware will catch this or controller
    expect(res.status).toBe(422); // Because of validation
  });
});
