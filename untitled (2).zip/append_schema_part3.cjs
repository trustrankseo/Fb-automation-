const fs = require('fs');

const schemaAdditions = `

export const downloadSources = pgTable("download_sources", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  baseUrl: text("base_url"),
  authenticationType: varchar("authentication_type", { length: 50 }),
  rateLimit: integer("rate_limit"),
  supportsVideo: boolean("supports_video").default(false),
  supportsImage: boolean("supports_image").default(false),
  supportsAudio: boolean("supports_audio").default(false),
  supportsMetadata: boolean("supports_metadata").default(false),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('dsource_org_idx').on(t.organizationId),
  index('dsource_ptype_idx').on(t.providerType),
  index('dsource_status_idx').on(t.status)
]);

export const downloadJobs = pgTable("download_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  requestedBy: uuid("requested_by").references(() => users.id, { onDelete: 'set null' }),
  sourceId: uuid("source_id").references(() => downloadSources.id, { onDelete: 'set null' }),
  queueId: varchar("queue_id", { length: 255 }),
  workerId: varchar("worker_id", { length: 255 }),
  downloadUrl: text("download_url").notNull(),
  mediaType: varchar("media_type", { length: 50 }),
  quality: varchar("quality", { length: 50 }),
  priority: integer("priority").default(0),
  retryCount: integer("retry_count").default(0),
  maxRetries: integer("max_retries").default(3),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  failedAt: timestamp("failed_at", { withTimezone: true }),
  processingTimeMs: integer("processing_time_ms"),
  failureReason: text("failure_reason"),
  ...commonColumns
}, (t) => [
  index('djob_org_idx').on(t.organizationId),
  index('djob_project_idx').on(t.projectId),
  index('djob_worker_idx').on(t.workerId),
  index('djob_status_idx').on(t.status),
  index('djob_priority_idx').on(t.priority),
  index('djob_created_idx').on(t.createdAt)
]);

export const downloadedAssets = pgTable("downloaded_assets", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  downloadJobId: uuid("download_job_id").references(() => downloadJobs.id, { onDelete: 'set null' }),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'set null' }),
  providerAssetId: varchar("provider_asset_id", { length: 255 }),
  title: text("title"),
  description: text("description"),
  author: varchar("author", { length: 255 }),
  license: varchar("license", { length: 255 }),
  sourceUrl: text("source_url"),
  thumbnailUrl: text("thumbnail_url"),
  previewUrl: text("preview_url"),
  duration: integer("duration"),
  width: integer("width"),
  height: integer("height"),
  fps: integer("fps"),
  codec: varchar("codec", { length: 50 }),
  bitrate: integer("bitrate"),
  language: varchar("language", { length: 50 }),
  checksum: varchar("checksum", { length: 255 }),
  ...commonColumns
}, (t) => [
  index('dasset_org_idx').on(t.organizationId),
  index('dasset_project_idx').on(t.projectId),
  index('dasset_job_idx').on(t.downloadJobId),
  index('dasset_checksum_idx').on(t.checksum)
]);

export const mediaProcessingJobs = pgTable("media_processing_jobs", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  workerId: varchar("worker_id", { length: 255 }),
  operation: varchar("operation", { length: 100 }),
  inputFormat: varchar("input_format", { length: 50 }),
  outputFormat: varchar("output_format", { length: 50 }),
  resolution: varchar("resolution", { length: 50 }),
  processingEngine: varchar("processing_engine", { length: 100 }),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  durationMs: integer("duration_ms"),
  errorMessage: text("error_message"),
  ...commonColumns
}, (t) => [
  index('mpjob_org_idx').on(t.organizationId),
  index('mpjob_project_idx').on(t.projectId),
  index('mpjob_worker_idx').on(t.workerId),
  index('mpjob_operation_idx').on(t.operation),
  index('mpjob_status_idx').on(t.status)
]);

export const storageObjects = pgTable("storage_objects", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'set null' }),
  provider: varchar("provider", { length: 100 }),
  bucket: varchar("bucket", { length: 255 }),
  region: varchar("region", { length: 100 }),
  storageKey: text("storage_key").notNull(),
  objectUrl: text("object_url"),
  publicUrl: text("public_url"),
  encrypted: boolean("encrypted").default(false),
  compressed: boolean("compressed").default(false),
  replicationStatus: varchar("replication_status", { length: 50 }),
  checksum: varchar("checksum", { length: 255 }),
  storageClass: varchar("storage_class", { length: 100 }),
  sizeBytes: bigint("size_bytes", { mode: 'number' }),
  ...commonColumns
}, (t) => [
  index('sobj_provider_idx').on(t.provider),
  index('sobj_bucket_idx').on(t.bucket),
  unique('sobj_storage_key_unq').on(t.storageKey)
]);

export const thumbnails = pgTable("thumbnails", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  width: integer("width"),
  height: integer("height"),
  format: varchar("format", { length: 50 }),
  storageObjectId: uuid("storage_object_id").references(() => storageObjects.id, { onDelete: 'set null' }),
  generatedBy: varchar("generated_by", { length: 100 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('thumb_file_idx').on(t.fileId)
]);

export const mediaVersions = pgTable("media_versions", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  fileId: uuid("file_id").references(() => files.id, { onDelete: 'cascade' }).notNull(),
  versionNumber: integer("version_number").notNull(),
  parentVersion: integer("parent_version"),
  editor: varchar("editor", { length: 255 }),
  changeSummary: text("change_summary"),
  storageObjectId: uuid("storage_object_id").references(() => storageObjects.id, { onDelete: 'set null' }),
  checksum: varchar("checksum", { length: 255 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (t) => [
  index('mver_file_idx').on(t.fileId),
  index('mver_version_idx').on(t.versionNumber)
]);

export const storageProviders = pgTable("storage_providers", {
  id: uuid("id").primaryKey(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: 'cascade' }).notNull(),
  providerName: varchar("provider_name", { length: 255 }).notNull(),
  providerType: varchar("provider_type", { length: 100 }),
  endpoint: text("endpoint"),
  region: varchar("region", { length: 100 }),
  defaultBucket: varchar("default_bucket", { length: 255 }),
  encryptionEnabled: boolean("encryption_enabled").default(false),
  compressionEnabled: boolean("compression_enabled").default(false),
  configuration: jsonb("configuration").default({}),
  ...commonColumns
}, (t) => [
  index('sprov_name_idx').on(t.providerName),
  index('sprov_org_idx').on(t.organizationId)
]);

`;

fs.appendFileSync('server/infrastructure/database/schema.ts', schemaAdditions);

console.log('Schema part 3 appended.');
